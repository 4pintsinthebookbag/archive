#pragma once

#include "../game/classes/GameStructs.hpp"
#include <vector>
#include <map>
#include "classes/GameStructs.hpp"



namespace atomic {
    namespace roblox {

        struct PlayerObject final {
            std::string Name;
            std::string PlayerName;
            atomic::roblox::instance_t inst = {};
            // intellect::roblox::instance_t Instance;
        };

        struct PlayerObjectComparator {
            bool operator()(const PlayerObject& lhs, const PlayerObject& rhs) const {
                return lhs.Name < rhs.Name;
            }
        };

        namespace sdk {
            extern std::map<PlayerObject, std::vector<PlayerObject>, PlayerObjectComparator> Players;
            void Update();
           // instance_t Find(const std::vector<std::string>& BodyParts, const std::string& Target);
            instance_t Find(std::vector<atomic::roblox::PlayerObject> BodyParts, std::string Target);
            void HookUpdate();
        }
    }
}
