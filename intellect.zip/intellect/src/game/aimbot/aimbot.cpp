

#include "aimbot.hpp"
#include <random>
#include <Windows.h>
#include <thread>
#include "../Variables/Variables.hpp"
#include "../src/base/xorstr/xorstr.hpp"
#include <iostream>
#include <tuple>
#include <mutex>
#include <atomic>
#include <chrono>

#define _DEBUG(str) printf("%s\n", str);
std::random_device rd;
std::mt19937 rng(rd());

std::atomic<bool> loop_control(true);
std::atomic<bool> loop_running(true);
std::atomic<bool> stop_aimbot(false);
std::chrono::time_point<std::chrono::steady_clock> last_iteration_time;
std::mutex loop_mutex;
std::thread aimbot_thread;

float calc_dist(atomic::roblox::vector2_t a, atomic::roblox::vector2_t b) {
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

float calc_dist_vec3(atomic::roblox::vector3_t a, atomic::roblox::vector3_t b) {
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y) + (a.z - b.z) * (a.z - b.z));
}

atomic::roblox::vector3_t to_vector3(float a, float b, float c) {
    return { a, b, c };
}

atomic::roblox::vector3_t calc_vel(atomic::roblox::instance_t body_part) {
    auto start = std::chrono::high_resolution_clock::now();

    atomic::roblox::vector3_t old_pos = body_part.get_part_pos();
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
    atomic::roblox::vector3_t current_pos = body_part.get_part_pos();

    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<float> elapsed_seconds = end - start;

    atomic::roblox::vector3_t velocity = (current_pos - old_pos);

    return velocity;
}

void ClipMouse(bool clip)
{
    if (clip)
    {
        RECT window_rect;
        GetWindowRect(Variables::window_handle, &window_rect);
        ClipCursor(&window_rect);
    }
    else
    {
        ClipCursor(NULL);
    }
}


void click() {
    INPUT input;
    input.type = INPUT_MOUSE;
    input.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
    SendInput(1, &input, sizeof(input));
    input.mi.dwFlags = MOUSEEVENTF_LEFTUP;
    SendInput(1, &input, sizeof(input));
}


static atomic::roblox::vector3_t lerp_vector3(const atomic::roblox::vector3_t& a, const atomic::roblox::vector3_t& b, float t)
{
    return {
        a.x + (b.x - a.x) * t,
        a.y + (b.y - a.y) * t,
        a.z + (b.z - a.z) * t
    };
}

static atomic::roblox::matrix3_t lerp_matrix3(const atomic::roblox::matrix3_t& a, const atomic::roblox::matrix3_t& b, float t)
{
    atomic::roblox::matrix3_t result{};
    for (int i = 0; i < 9; ++i) {
        result.data[i] = a.data[i] + (b.data[i] - a.data[i]) * t;
    }
    return result;
}


static atomic::roblox::vector3_t normalize(const atomic::roblox::vector3_t& vec) {
    float length = sqrt(vec.x * vec.x + vec.y * vec.y + vec.z * vec.z);
    if (length != 0) {
        return { vec.x / length, vec.y / length, vec.z / length };
    }
    else {
        // dont divide by zero silly
        return vec;
    }
}

// cross product
static atomic::roblox::vector3_t crossProduct(const atomic::roblox::vector3_t& vec1, const atomic::roblox::vector3_t& vec2) {
    return {
        vec1.y * vec2.z - vec1.z * vec2.y,
        vec1.z * vec2.x - vec1.x * vec2.z,
        vec1.x * vec2.y - vec1.y * vec2.x
    };
}

static atomic::roblox::matrix3_t LookAtToMatrix(const atomic::roblox::vector3_t& cameraPosition, const atomic::roblox::vector3_t& targetPosition) {
    atomic::roblox::vector3_t forward = normalize(atomic::roblox::vector3_t{ (targetPosition.x - cameraPosition.x), (targetPosition.y - cameraPosition.y), (targetPosition.z - cameraPosition.z) }); // Calculate the forward direction
    atomic::roblox::vector3_t right = normalize(crossProduct({ 0, 1, 0 }, forward)); // Calculate the right direction
    atomic::roblox::vector3_t up = crossProduct(forward, right); // Calculate the up direction

    // Construct the transformation matrix
    atomic::roblox::matrix3_t lookAtMatrix{};
    lookAtMatrix.data[0] = (right.x * -1);  lookAtMatrix.data[1] = up.x;  lookAtMatrix.data[2] = -forward.x;
    lookAtMatrix.data[3] = right.y;  lookAtMatrix.data[4] = up.y;  lookAtMatrix.data[5] = -forward.y;
    lookAtMatrix.data[6] = (right.z * -1);  lookAtMatrix.data[7] = up.z;  lookAtMatrix.data[8] = -forward.z;

    return lookAtMatrix;
}



void run(atomic::roblox::instance_t player, atomic::roblox::vector3_t resolved_velocity, atomic::roblox::vector3_t Characterpos) {
    POINT cursor_point;
    GetCursorPos(&cursor_point);
    ScreenToClient(Variables::window_handle, &cursor_point);

    atomic::roblox::vector3_t part_pos_3d;


    auto players = Variables::players;

    auto dimensions = Variables::visualengine.get_dimensions();
    auto view_matrix = Variables::visualengine.get_view_matrix();
    auto local_player = Variables::LocalPlayer;
    float smoothness = ((101 - Variables::smoothness) / 100);
    atomic::roblox::instance_t workspace = Variables::workspace;
    atomic::roblox::instance_t camera = workspace.get_camera();

    atomic::roblox::vector3_t camera_position = camera.get_camera_pos();
    atomic::roblox::matrix3_t camera_rotation = camera.get_camera_rotation();

    if (Variables::prediction) {
        atomic::roblox::vector3_t velocity = Variables::resolver ? resolved_velocity : player.get_part_velocity();
        atomic::roblox::vector3_t target_pos = player.get_part_pos();

        float prediction_x = Variables::separate_predictions ? Variables::prediction_x : Variables::main_prediction;
        float prediction_y = Variables::separate_predictions ? Variables::prediction_y : Variables::main_prediction;
        float prediction_z = Variables::separate_predictions ? Variables::prediction_x : Variables::main_prediction;

        if (Variables::distpred) {
            if (local_player.self != 0) {
                auto local_character = local_player.get_model_instance();
                auto local_hrp = local_character.find_first_child("HumanoidRootPart");

                if (local_hrp.self != 0) {
                    atomic::roblox::vector3_t player_pos = local_hrp.get_part_pos();

                    float dist_from_plr = calc_dist_vec3(player_pos, target_pos);

                    if (dist_from_plr < Variables::CloseDistance) {
                        prediction_x = Variables::separate_predictions ? Variables::close_prediction_x : Variables::main_close_prediction;
                        prediction_y = Variables::separate_predictions ? Variables::close_prediction_y : Variables::main_close_prediction;
                        prediction_z = Variables::separate_predictions ? Variables::close_prediction_x : Variables::main_close_prediction;
                    }
                    else if (dist_from_plr < Variables::MidDistance) {
                        prediction_x = Variables::separate_predictions ? Variables::mid_prediction_x : Variables::main_mid_prediction;
                        prediction_y = Variables::separate_predictions ? Variables::mid_prediction_y : Variables::main_mid_prediction;
                        prediction_z = Variables::separate_predictions ? Variables::mid_prediction_x : Variables::main_mid_prediction;
                    }
                    else {
                        prediction_x = Variables::separate_predictions ? Variables::far_prediction_x : Variables::main_far_prediction;
                        prediction_y = Variables::separate_predictions ? Variables::far_prediction_y : Variables::main_far_prediction;
                        prediction_z = Variables::separate_predictions ? Variables::far_prediction_x : Variables::main_far_prediction;
                    }
                }
            }
        }

        atomic::roblox::vector3_t velocity_vector;

        if (Variables::prediction_method == 0)
            velocity_vector = { velocity.x / prediction_x, velocity.y / prediction_y, velocity.z / prediction_z };
        else
            velocity_vector = { velocity.x * prediction_x, velocity.y * prediction_y, velocity.z * prediction_z };

        part_pos_3d = target_pos + velocity_vector;
    }
    else {
        part_pos_3d = player.get_part_pos();
    }

    auto part_pos = atomic::roblox::world_to_screen(part_pos_3d, dimensions, view_matrix);

    if (part_pos.x == -1)
        return;

    float dist = calc_dist(part_pos, { static_cast<float>(cursor_point.x), static_cast<float>(cursor_point.y) });

    atomic::roblox::vector2_t relative = { 0, 0 };

    if (Variables::shake) {
        if (Variables::shaketype == 0) {
            int shake_range_x = static_cast<int>(Variables::shake_x * 10);
            int shake_range_y = static_cast<int>(Variables::shake_y * 10);

            auto shake_x = (rand() & shake_range_x - (shake_range_x / 2));
            auto shake_y = (rand() & shake_range_y - (shake_range_y / 2));

            relative.x = (part_pos.x - cursor_point.x + shake_x) * Variables::sensitivity / Variables::smoothness_x;
            relative.y = (part_pos.y - cursor_point.y + shake_y) * Variables::sensitivity / Variables::smoothness_y;
        }
        else if (Variables::shaketype == 0) {
            int shake_range = static_cast<int>(Variables::shake_value * 10);
            auto shake = (rand() & shake_range - (shake_range / 2));

            relative.x = (part_pos.x - cursor_point.x + shake_range) * Variables::sensitivity / Variables::smoothness_x;
            relative.y = (part_pos.y - cursor_point.y + shake_range) * Variables::sensitivity / Variables::smoothness_y;
        }
    }
    else {
        relative.x = (part_pos.x - cursor_point.x) * Variables::sensitivity / Variables::smoothness_x;
        relative.y = (part_pos.y - cursor_point.y) * Variables::sensitivity / Variables::smoothness_y;
    }

    if (relative.x == -1 || relative.y == -1)
        return;

    float dist_to_deadzone = calc_dist({ static_cast<float>(cursor_point.x), static_cast<float>(cursor_point.y) },
        { static_cast<float>(cursor_point.x) + relative.x,
          static_cast<float>(cursor_point.y) + relative.y });

    if (Variables::deadzone && dist_to_deadzone <= Variables::deadzone_value)
        return;


    if (!Variables::disable_outside_fov || dist <= Variables::fov) {
        switch (Variables::aimtype)
        {
        case 0: {
            static float current_dx = 0.0f;
            static float current_dy = 0.0f;

            current_dx += (relative.x - current_dx) * smoothness;
            current_dy += (relative.y - current_dy) * smoothness;

            INPUT input{};
            input.mi.time = 0;
            input.type = INPUT_MOUSE;
            input.mi.mouseData = 0;
            input.mi.dx = static_cast<LONG>(current_dx);
            input.mi.dy = static_cast<LONG>(current_dy);
            input.mi.dwFlags = MOUSEEVENTF_MOVE;
            SendInput(1, &input, sizeof(input));
            break;
        }
        case 1:
            atomic::roblox::matrix3_t hit_matrix = LookAtToMatrix(camera_position, part_pos_3d);
            atomic::roblox::matrix3_t relative_matrix = lerp_matrix3(camera_rotation, hit_matrix, smoothness);
            camera.write_camera_rotation(relative_matrix);
            break;
      /*  case 2: {
            static float current_dx = 0.0f;
            static float current_dy = 0.0f;

            current_dx += (relative.x - current_dx) * smoothness;
            current_dy += (relative.y - current_dy) * smoothness;

            INPUT input{};
            input.mi.time = 0;
            input.type = INPUT_MOUSE;
            input.mi.mouseData = 0;
            input.mi.dx = static_cast<LONG>(current_dx);
            input.mi.dy = static_cast<LONG>(current_dy);
            input.mi.dwFlags = MOUSEEVENTF_MOVE;
            SendInput(1, &input, sizeof(input));

            if (!Variables::aimbotkey.enabled) {
                ClipMouse(false);
            }

            if (Variables::aimbotkey.enabled) {
            ClipMouse(true);
            }

            break;
        }*/
            // not fixed fully but free aim ^^
        }
    }
}

void atomic::roblox::hook_flickbot() {
    atomic::roblox::instance_t _saved_target;
    atomic::roblox::instance_t _target;
    atomic::roblox::instance_t _body_part;

    bool _locked;

    atomic::roblox::vector3_t velocity = {};

    std::thread velocity_calculation([&]() {
        while (true) {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));

            if (!Variables::flickbot || Variables::resolver == false || _target.self == 0)
                continue;

            atomic::roblox::instance_t _character = _target.get_model_instance();

            if (_character.self == 0)
                continue;

            atomic::roblox::instance_t _root_part = _character.find_first_child("HumanoidRootPart");

            if (_root_part.self == 0)
                continue;

            velocity = calc_vel(_root_part);
        }
        });

    while (true) {
        if (Variables::flickbot) {
            if (Variables::is_focused) {
                Variables::flickbotkey.update();
                vector3_t lastpos = vector3_t(3, 3, 3);
                if (Variables::flickbotkey.enabled) {
                    if (Variables::negro && _locked && _saved_target.self != 0 && Variables::saved_player.self != 0) {
                        _body_part = _saved_target;
                        _target = Variables::saved_player;
                        lastpos = Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").get_part_pos();
                    }
                    else {
                        auto [body_part, closest_player] = atomic::roblox::get_closest_player_to_cursor();
                        _target = closest_player;
                        _body_part = body_part;
                    }

                    if (_body_part.self != 0 && _body_part.get_part_pos().y > 0.1f) {
                        if (Variables::saved_player.self != 0 && Variables::healthcheck) {
                            auto character = Variables::saved_player.get_model_instance();
                            auto humanoid = character.find_first_child("Humanoid");
                        }

                        if (Variables::saved_player.self != 0 && Variables::knock_check) {
                            auto character = Variables::saved_player.get_model_instance();
                            auto humanoid = character.find_first_child("Humanoid");
                        }

                        run(_body_part, velocity, lastpos);
                        _saved_target = _body_part;

                        _locked = true;
                    }
                    else
                        _locked = false;
                }
                else {
                    _locked = false;
                    _body_part = {};
                }
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

void atomic::roblox::initTrigger() {
    while (true) {
        if (Variables::triggerbot) {
            Variables::triggerbotkey.update();
            if (Variables::aimbotkey.enabled && Variables::triggerbotkey.enabled && Variables::triggerbot) {
                INPUT input = { 0 };
                input.type = INPUT_MOUSE;
                input.mi.dwFlags = MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP;
                SendInput(1, &input, sizeof(INPUT));
                Sleep(Variables::triggerbot_delay_ms);
            }
        }
    }
}

void atomic::roblox::watchdog() {
    while (true) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        auto now = std::chrono::steady_clock::now();

        {
            std::lock_guard<std::mutex> guard(loop_mutex);
            if (loop_running && std::chrono::duration_cast<std::chrono::seconds>(now - last_iteration_time).count() > 2) {
                std::cout << "[Watchdog] -> Loop seems to be stuck. Restarting aimbot..." << std::endl;

                stop_aimbot = true;

                loop_control = false;
                std::this_thread::sleep_for(std::chrono::milliseconds(500));
                loop_control = true;
                last_iteration_time = now;

                if (aimbot_thread.joinable()) {
                    aimbot_thread.join();
                }

                stop_aimbot = false;
                aimbot_thread = std::thread([]() {
                    atomic::roblox::hook_aimbot();
                    });

                std::cout << "[Watchdog] -> Aimbot restarted." << std::endl;
            }
        }
    }
}



void atomic::roblox::hook_aimbot() {
    atomic::roblox::instance_t _saved_target;
    atomic::roblox::instance_t _target;
    atomic::roblox::instance_t _body_part;
    bool focus = false;
    bool _locked;
    atomic::roblox::vector3_t velocity = {};

    loop_running = true;

    std::thread velocity_calculation([&]() {
        while (!stop_aimbot) {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));

            if (!Variables::aimbot || Variables::resolver == false || _target.self == 0)
                continue;

            atomic::roblox::instance_t _character = _target.get_model_instance();

            if (_character.self == 0)
                continue;

            atomic::roblox::instance_t _root_part = _character.find_first_child("HumanoidRootPart");

            if (_root_part.self == 0)
                continue;

            velocity = calc_vel(_root_part);
        }
        });

    while (!stop_aimbot) {
        while (loop_control) {
            {
                std::lock_guard<std::mutex> guard(loop_mutex);
                last_iteration_time = std::chrono::steady_clock::now();
            }

            if (Variables::aimbot) {
                if (Variables::is_focused) {
                    Variables::aimbotkey.update();
                    vector3_t lastpos = vector3_t(3, 3, 3);

                    if (Variables::aimbotkey.enabled) {
                        if (!focus && Variables::negro && _locked && _saved_target.self != 0 && Variables::saved_player.self != 0) {
                            _body_part = _saved_target;
                            _target = Variables::saved_player;
                        }
                        else {
                            if (!focus) {
                                focus = true;
                                auto [body_part, closest_player] = atomic::roblox::get_closest_player_to_cursor();
                                _target = closest_player;
                                _body_part = body_part;
                            }
                        }

                        if (_body_part.self != 0 && _body_part.get_part_pos().y > 0.1f) {
                            if (Variables::autoresolve) {
                                atomic::roblox::vector3_t current_vel = _body_part.get_part_velocity();
                                float velocity_magnitude = sqrt((current_vel.x * current_vel.x) + (current_vel.y * current_vel.y) + (current_vel.z * current_vel.z));

                                bool velocity_exceeds_threshold = std::abs(current_vel.x) > Variables::velocity_threshold ||
                                    std::abs(current_vel.y) > Variables::velocity_threshold ||
                                    std::abs(current_vel.z) > Variables::velocity_threshold;

                                Variables::resolver = velocity_exceeds_threshold;
                            }

                            if (Variables::saved_player.self != 0 && Variables::healthcheck) {
                                auto character = Variables::saved_player;
                                auto humanoid = character.find_first_child("Humanoid");
                            }

                            if (Variables::saved_player.self != 0 && Variables::knock_check) {
                                auto character = Variables::saved_player.get_model_instance();
                                auto humanoid = character.find_first_child("Humanoid");
                            }

                            if (focus) {
                                run(_body_part, velocity, lastpos);
                            }

                            _saved_target = _body_part;
                            Variables::saved_player = _target;
                            _locked = true;
                        }
                        else {
                            Variables::saved_player = {};
                            _target = {};
                            _body_part = {};
                            _locked = false;
                            focus = false;
                        }
                    }
                    else {
                        Variables::saved_player = {};
                        _target = {};
                        _body_part = {};
                        _locked = false;
                        focus = false;
                    }
                }
                if (Variables::aimtype == 0) // mouse
                {
                    std::this_thread::sleep_for(std::chrono::milliseconds(1));
                }
                else if (Variables::aimtype == 1) // cam
                {
                    std::this_thread::sleep_for(std::chrono::milliseconds(-1));
                }

                else if (Variables::aimtype == 2) // cam
                {
                    std::this_thread::sleep_for(std::chrono::milliseconds(5));
                }
            }
        }

        loop_control = true;
    }

    loop_running = false;
}
