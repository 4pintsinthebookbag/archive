#pragma once

#include "../classes/GameStructs.hpp"
#include <thread>

namespace atomic
{
	namespace roblox
	{

		atomic::roblox::vector2_t get_relative_player_to_pos(atomic::roblox::vector2_t closest_player);
		void hook_flickbot();
		void watchdog();
		void hook_magicbullet();
		void initTrigger();
		void hook_aimbot();
	}
}