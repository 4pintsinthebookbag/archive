#pragma once

#include "../classes/GameStructs.hpp"

#include <cstdint>
#include "../../base/overlay/ckeybind/keybind.hpp"
#include "../../base/overlay/imgui/TextEditor.h"
#include "unordered_set"
#include <set>

struct Variables
{
	static bool is_focused;
	static HWND window_handle;

	static atomic::roblox::instance_t datamodel;
	static atomic::roblox::instance_t visualengine;
	static atomic::roblox::instance_t players;
	static atomic::roblox::instance_t placeid;
	static atomic::roblox::instance_t saved_player;
	static atomic::roblox::instance_t targetinstance;
	static atomic::roblox::instance_t playerslocation;
	static atomic::roblox::instance_t ESPPlayers;
	static atomic::roblox::instance_t workspace;
	static std::string localplayername;
	static std::string selectedplayer;


	static std::set<std::string> whitelistedPlayers; // Declaration

	static std::set<std::string> aimwhitelistedPlayers; // Declaration
	static bool threeCircle;

	static HWND backgroundyes;

	static bool spectatelocked;

	static bool cframedh;
	static bool Fly;
	static bool cframehc;
	static bool aimassist;
	static bool skeleton;

	static bool esp;
	static bool dotesp;
	static bool box;
	static bool masterswitch;
	static bool outline;
	static bool wallbang;
	static bool filledbox;
	static bool trigger_prediction;
	static bool distance_esp;
	static bool rainbowbox;
	static bool local_box;
	static bool fov_filled;
	static bool deadzone_fov_filled;
	static bool outlinefov;
	static bool name_esp;
	static bool datentime;
	static bool tracers;
	static bool bezier;
	static float lenght;
	static float thickness;
	static float gap;
	static float skeleton_thickness;
	static bool healthinfo;
	static bool healthbar;
	static bool chams;
	static bool orbit;
	static bool head_dot;
	static bool healthinfox;
	static bool negro;
	static bool visualisetarget;
	static float head_dot_color[3];
	static float box_color[3];
	static float sonar_color[3];
	static float deadzone_color[3];
	static float deadzone_fill_color[3];
	static float name_color[3];
	static float fov_fill_color[3];
	static float fov_color[3];
	static float fill_color[3];
	static float tracers_color[3];
	static float skeleton_color[3];
	static float dot_color[3];

	static bool autoload;
	static bool shake;
	static bool aimbot;
	static bool triggerbot;
	static bool stabilizer;
	static bool deadzone;
	static bool targetmark;
	static bool targetbox;
	static bool show_deadzone;
	static bool sticky_aim;
	static bool cframe;
	static bool resolver;
	static bool autopred;
	static bool watermark;
	static bool crosshair;
	static int prediction_type;
	static float prediction_value;
	static int orbitspeed;
	static int orbitoffset;
	static int orbitradius;
	static float velocity_threshold;
	static bool autoresolve;
	static bool prediction;
	static bool distpred;


	static bool vsync;
	static bool streamproof;
	static bool rainbowmode;
	static float trigger_prediction_y;
	static float camerafov;
	static float trigger_prediction_x;
	static bool useless;
	static bool useless2;
	static bool useless3;

	static float bounce_frequency;
	static float bounce_decay;



	static float elactic_frequency;
	static float elactic_decay;
	static atomic::roblox::instance_t LocalPlayer;
	static float cframespeed;




	static float decay;
	static float flickspeed;
	static float flyspeed;
	static atomic::roblox::instance_t RealPlayer;

	static float time_since_start;
	static int threadtype_trigger;
	static int smooth_type;
	static bool rainbowfov;
	static bool rainbowfovfilled;
	static bool autologin;

	static std::string game;

	static int aimpart;
	static int boxtype;
	static int shaketype;
	static int fovtype;
	static int head_dot_type;
	static int fillboxtype;
	static int threadtype;
	static int trigger_bot_dist;
	static int x_offset;
	static int y_offset;

	static int max_dist;

	static float smoothness_x;
	static float smoothness_y;

	static float stabilizer_x;
	static float stabilizer_y;

	static float prediction_x;
	static bool friendlynotifier;
	static bool radar;
	static float prediction_y;
	static bool hitnotification;
	static bool hitsound;
	static int hitsound_type;

	static float CloseDistance;
	static float MidDistance;

	static float close_prediction_x;
	static float close_prediction_y;


	static float mid_prediction_x;
	static float mid_prediction_y;


	static float far_prediction_x;
	static float far_prediction_y;




	static float shake_value;
	static float shake_x;
	static float shake_y;
	static int autoclickerinterval;
	static bool autoclicker;

	static float range;
	static float range_mult;

	static bool show_auth;
	static bool transparent;
	static bool lowerbottom;
	static float sensitivity;
	static int fov;
	static int deadzone_value;
	static bool fov_on;
	static bool disable_outside_fov;
	static bool autoshot;
	static bool healthcheck;
	static bool knock_check;
	static bool team_check;
	static bool team_check_esp;
	static bool flickbot;
	static bool autoshoot;
	static float trigger_range;
	static int aimbot_range;
	static bool aimbot_range_enable;
	static int triggerbot_delay_ms;
	static bool smoothness;


	// character modifications

	static bool walkspeed_enable;
	static bool jumppower_enable;
	static bool hipheight_enable;
	static float hipheight;


	static bool camera_zoom;
	static bool armorbar;
	static float zoom;



	static bool separate_predictions;
	static int prediction_method;
	static int cframetype;

	static float main_prediction;
	static float main_close_prediction;
	static float main_mid_prediction;
	static float main_far_prediction;

	static bool macro;
	static bool character_modification;
	static float walksspeed;
	static float jumppower;
	static int macro_mode;
	static float y_axis;
	static int aimtype;
	static bool threadcrash;
	static bool sonar;
	static float sonar_expansion_rate;

	//static bool visualiselocked;
	static CKeybind panickey;

	static CKeybind macrokey;
	static CKeybind cspeedkey;
	static CKeybind aimbotkey;
	static CKeybind flykey;
	static CKeybind triggerbotkey;
	static CKeybind flickbotkey;
	static CKeybind aimassistkey;
};