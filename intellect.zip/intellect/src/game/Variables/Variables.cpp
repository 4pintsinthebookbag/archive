#include "Variables.hpp"
bool Variables::is_focused = false;
HWND Variables::window_handle{};

atomic::roblox::instance_t Variables::datamodel{};
atomic::roblox::instance_t Variables::players{};
atomic::roblox::instance_t Variables::visualengine{};
atomic::roblox::instance_t Variables::placeid{};
atomic::roblox::instance_t Variables::playerslocation{};
atomic::roblox::instance_t Variables::ESPPlayers{};
atomic::roblox::instance_t Variables::saved_player{};
atomic::roblox::instance_t Variables::LocalPlayer{};

atomic::roblox::instance_t Variables::workspace{};
//atomic::roblox::instance_t Variables::camera{};
//atomic::roblox::instance_t Variables::pf{};


bool Variables::trigger_prediction = false;
std::set<std::string> Variables::whitelistedPlayers;
std::set<std::string> Variables::aimwhitelistedPlayers;

std::string Variables::localplayername = "???";
std::string Variables::selectedplayer = "";


atomic::roblox::instance_t Variables::targetinstance{};

bool Variables::sticky_aim = true;


bool Variables::cframedh = false;
bool Variables::chams = false;
bool Variables::cframehc = false;
bool Variables::cframe = false;
bool Variables::Fly = false;
bool Variables::skeleton = false;
bool Variables::aimassist = false;
float Variables::cframespeed = 1;
float Variables::flyspeed = 1;
float Variables::skeleton_thickness = 0.4f;

bool Variables::esp = false;
bool Variables::dotesp = false;
bool Variables::spectatelocked = false;
bool Variables::box = false;
bool Variables::filledbox = false;
bool Variables::outline = false;
bool Variables::distance_esp = false;
bool Variables::local_box = false;
bool Variables::rainbowbox = false;
bool Variables::name_esp = false;
bool Variables::tracers = false;
bool Variables::healthinfo = false;
bool Variables::healthbar = false;
bool Variables::fov_filled = false;
bool Variables::outlinefov = false;
bool Variables::deadzone_fov_filled = false;
bool Variables::head_dot = false;
bool Variables::visualisetarget = false;
bool Variables::healthinfox = false;

bool Variables::bezier = false;
bool Variables::autoshoot = false;

bool Variables::lowerbottom = false;
bool Variables::transparent = false;

bool Variables::targetmark = false;
bool Variables::targetbox = false;
bool Variables::negro = false;
bool Variables::autoload = false;
bool Variables::aimbot_range_enable = false;
bool Variables::wallbang = false;



//

bool Variables::walkspeed_enable = false;
bool Variables::jumppower_enable = false;
bool Variables::hipheight_enable = false;

float Variables::hipheight = 10;
float Variables::camerafov = 70;

float Variables::trigger_range = 50.00f;
int Variables::aimbot_range = 50.00;


int Variables::triggerbot_delay_ms = 1;



float Variables::head_dot_color[3] = { 255, 255, 255 };

float Variables::box_color[3] = { 75, 85, 75 }; // love da ethic color :3
float Variables::deadzone_color[3] = { 255, 255, 255 };
float Variables::deadzone_fill_color[3] = { 255, 255, 255 };
float Variables::fill_color[3] = { 255, 255, 255 };
float Variables::fov_fill_color[3] = { 255, 255, 255 };
float Variables::fov_color[3] = { 0, 0, 0 };
float Variables::name_color[3] = { 255, 255, 255 };
float Variables::tracers_color[3] = { 255, 255, 255 };
float Variables::sonar_color[3] = { 255, 255, 255 };
float Variables::skeleton_color[3] = { 255, 255, 255 };
float Variables::dot_color[3] = { 255, 255, 255 };
bool Variables::datentime = false;
bool Variables::prediction = false;
bool Variables::orbit = false;


bool Variables::distpred = false;

bool Variables::stabilizer = false;
bool Variables::vsync = true;
bool Variables::watermark = true;
bool Variables::deadzone = false;
bool Variables::show_deadzone = false;
bool Variables::streamproof = false;
bool Variables::aimbot = false;
bool Variables::autologin = false;
bool Variables::shake = false;
bool Variables::triggerbot = false;
bool Variables::resolver = false;
bool Variables::autopred = false;

bool Variables::useless = false;
bool Variables::useless2 = false;
bool Variables::useless3 = false;


bool Variables::rainbowfov = false;

bool Variables::rainbowmode = false;





bool Variables::rainbowfovfilled = false;

std::string Variables::game = "Universal";


int Variables::aimpart = 2;

int Variables::fovtype = 0;
int Variables::threadtype = 0;
int Variables::threadtype_trigger = 0;
int Variables::boxtype = 0;
int Variables::shaketype = 0;
int Variables::head_dot_type = 0;
int Variables::smooth_type = 0;
float Variables::time_since_start = 0.0f;

float Variables::decay = 0.05f;


int Variables::orbitspeed = 4;
int Variables::orbitradius = 2;
int Variables::orbitoffset = 2;



float Variables::flickspeed = 0.1f;

float Variables::elactic_frequency = 2.0f;
float Variables::elactic_decay = 0.2f;

float Variables::bounce_frequency = 0.5f;
float Variables::bounce_decay = 0.05f;

int Variables::fillboxtype = 0;

int Variables::x_offset = 0;
int Variables::y_offset = 0;

int Variables::max_dist = 10000;

int Variables::trigger_bot_dist = 10000;

float Variables::smoothness_x = 1;
float Variables::smoothness_y = 1;

float Variables::MidDistance = 50.0f;

float Variables::CloseDistance = 20.0f;
bool Variables::hitnotification = false;


int Variables::aimtype = 1;
float Variables::stabilizer_x = 0;
float Variables::stabilizer_y = 0;

float Variables::trigger_prediction_x = 0.15;
float Variables::trigger_prediction_y = 0.15;

float Variables::shake_value = 5;
float Variables::shake_x = 5;
float Variables::shake_y = 5;


int Variables::autoclickerinterval = 100;

bool Variables::autoclicker;

float Variables::range = 0;
float Variables::range_mult = 0;

float Variables::sensitivity = 1.0f;
float Variables::velocity_threshold = 40.0;

//bool Variables::visualiselocked = false;



bool Variables::camera_zoom = false;
float Variables::zoom = 128.0;

int Variables::fov = 100;
int Variables::deadzone_value = 50;

bool Variables::fov_on = false;
bool Variables::disable_outside_fov = false;
bool Variables::show_auth = false;
bool Variables::autoresolve = false;


float Variables::lenght = 39.0f;
float Variables::thickness = 2.0f;

float Variables::gap = 10.0f;

int Variables::prediction_type = 0;
bool Variables::hitsound = false;
int Variables::hitsound_type = 0;
int Variables::cframetype = 1;
bool Variables::friendlynotifier = false;
bool Variables::radar = false;
float Variables::prediction_value = 0.165;

bool Variables::flickbot = false;
bool Variables::crosshair = false;
bool Variables::healthcheck = false;
bool Variables::knock_check = false;
bool Variables::team_check = false;
bool Variables::team_check_esp = false;
bool Variables::threeCircle = false;
bool Variables::smoothness = false;

bool Variables::separate_predictions = true;
int Variables::prediction_method = 0;

float Variables::prediction_x = 3;
float Variables::prediction_y = 3;

float Variables::close_prediction_x = 0.15;
float Variables::close_prediction_y = 0.15;

float Variables::mid_prediction_x = 0.15;
float Variables::mid_prediction_y = 0.15;

float Variables::far_prediction_x = 0.15;
float Variables::far_prediction_y = 0.15;

float Variables::walksspeed = 16;
float Variables::jumppower = 50.0;
bool Variables::character_modification = false;
bool Variables::masterswitch = true;
float Variables::main_prediction = 0.15;
bool Variables::armorbar = false;
float Variables::main_close_prediction = 0.15;
float Variables::main_mid_prediction = 0.15;
bool Variables::threadcrash = false;
float Variables::main_far_prediction = 0.15;
float Variables::y_axis = 4.7f;
bool Variables::macro = false;
int Variables::macro_mode = 0;

bool Variables::sonar = false;
float Variables::sonar_expansion_rate = 0.5f;

//int Variables::aimbotkey = 0;

//CKeybind Variables::autoclickerkey{ "autoclickerkey" };

CKeybind Variables::panickey{ "panickey" };

CKeybind Variables::macrokey{ "macrokey" };
CKeybind Variables::aimbotkey{ "aimkey" };
CKeybind Variables::cspeedkey{ "speedkey" };
CKeybind Variables::flykey{ "flykey" };
CKeybind Variables::flickbotkey{ "flickkey" };
CKeybind Variables::triggerbotkey{ "triggerkey" };
CKeybind Variables::aimassistkey{ "aimkey2" };