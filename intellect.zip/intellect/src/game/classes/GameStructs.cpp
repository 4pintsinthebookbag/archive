#include "GameStructs.hpp"

#include "../../base/datamodel/datamodel.hpp"
#include "../../base/overlay/overlay.hpp"
#include "../Variables/Variables.hpp"
#include "../aimbot/aimbot.hpp"
#include "../esp/esp.hpp"
#include "../../base/xorstr/xorstr.hpp"
#include "../../base/json/json.hpp"
#pragma comment(lib, "libcurl.lib")
#include <fstream>
#include <cstdlib>
#include "../../base/overlay/overlay.hpp"

#include <windows.h>
#include <iostream>
#include <thread>
#include "mapper/raw_driver.hpp"
#include "mapper/driver_data.hpp"
#include "mapper/driver.hpp"
//#include <mapper/test/include/intel_driver.hpp>
//#include <mapper/test/include/kdmapper.hpp>      
//#include <mapper/driver_data.hpp>
//#include <game/driver/driver_impl.hpp>
#include <game/threads/threads.hpp>
#include <hacks/hacks.hpp>
#include <cstdlib>
#include <ctime>
#include <game/sdk.h>

std::string readstring(std::uint64_t address);
std::string readstring2(std::uint64_t string);

#define TaskSchedPtrAddr 0x64B6FB8


size_t WriteCallback(void* contents, size_t size, size_t nmemb, std::string* output) {
	size_t totalSize = size * nmemb;
	output->append(static_cast<char*>(contents), totalSize);
	return totalSize;
}

float calculate_distance(atomic::roblox::vector2_t a, atomic::roblox::vector2_t b) {
	return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

uint64_t get_render_view() {
	printf("[DEBUG] Entering GetDataModel()\n");

	uintptr_t scheduler = read<uintptr_t>(mem::find_image() + TaskSchedPtrAddr);
	if (!scheduler)
	{
		printf("Failed to get scheduler addy!");
	}


	uintptr_t jobStart = read<uintptr_t>(scheduler + 0x1D0);
	uintptr_t jobEnd = read<uintptr_t>(scheduler + 0x1D8);

	if (!jobStart || !jobEnd || jobStart >= jobEnd) return 0;

	for (uintptr_t job = jobStart; job < jobEnd; job += 0x10) {
		uintptr_t jobAddress = read<uintptr_t>(job);

		if (!jobAddress) continue;

		std::string jobName = readstring(jobAddress + 0x18); //offset found at  https://discord.gg/uJkp3tVY5C


		if (jobName == "RenderJob") {
			auto RenderView = read<uintptr_t>(jobAddress + 0x218);
			auto visual_engine = read<atomic::roblox::instance_t>(RenderView + 0x10);
			auto fakeDataModel = read<uint64_t>(RenderView + 0x120);

			auto realDataModel = static_cast<atomic::roblox::instance_t>(read<std::uint64_t>(fakeDataModel + atomic::offsets::FakeDataModelToRealDataModel));
			realDataModel;

			return jobAddress;
		}
	}
	printf("[DEBUG] No RenderJob found\n");
	return 0;
}

#include <windows.h>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <numbers>
#include <mapper/test/include/kdmapper.hpp>

#pragma comment(lib, "user32.lib")

//BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam) {
//	int length = GetWindowTextLengthA(hwnd);
//	if (length == 0) {
//		return TRUE;
//	}
//
//	std::vector<char> title(length + 1);
//	GetWindowTextA(hwnd, title.data(), length + 1);
//
//	std::string titleStr(title.begin(), title.end());
//
//	if (titleStr.find(XorStr("PID:")) != std::string::npos) {
//		MessageBoxA(NULL, XorStr("we appreciate your efforts"), XorStr("heo, dovyl"), MB_ICONERROR);
//		exit(0);
//	}
//
//	if (titleStr.find(XorStr("[Elevated]")) != std::string::npos) {
//		MessageBoxA(NULL, XorStr("we appreciate your efforts"), XorStr("heo, dovyl"), MB_ICONERROR);
//		exit(0);
//	}
//
//	if (titleStr.find(XorStr("Thread:")) != std::string::npos) {
//		MessageBoxA(NULL, XorStr("we appreciate your efforts"), XorStr("heo, dovyl"), MB_ICONERROR);
//		exit(0);
//	}
//
//	if (titleStr.find(XorStr("Module:")) != std::string::npos) {
//		MessageBoxA(NULL, XorStr("we appreciate your efforts"), XorStr("heo, dovyl"), MB_ICONERROR);
//		exit(0);
//	}
//
//	if (titleStr.find(XorStr("Main Thread")) != std::string::npos) {
//		MessageBoxA(NULL, XorStr("we appreciate your efforts"), XorStr("heo, dovyl"), MB_ICONERROR);
//		exit(0);
//	}
//
//	if (titleStr.find(XorStr("IDA -")) != std::string::npos) {
//		MessageBoxA(NULL, XorStr("we appreciate your efforts"), XorStr("heo, dovyl"), MB_ICONERROR);
//		exit(0);
//	}
//
//	return TRUE;
//}

void atomic::roblox::reinitializeComponents() {
	auto render_job = get_render_view(); // ������ �������

	if (!render_job) {
		printf("Failed to find RenderJob!\n");
		return;
	}

	auto render_view = read<uintptr_t>(render_job + 0x218);
	auto visualengine = read<atomic::roblox::instance_t>(render_view + 0x10);
	if (!visualengine.self) {
		MessageBox(NULL, XorStr("Failed to get visual engine, please run the cheat as administrator!\n"), XorStr("atomic"), MB_OK | MB_ICONERROR);
		return;
	}
	Variables::visualengine = visualengine;

	//std::cout << std::hex << "DATA::RBX::DataModel -> 0x" << get_render_view() << std::endl;
	auto game_ptr = read<std::uint64_t>(get_render_view() + 0x118);
	auto game = static_cast<atomic::roblox::instance_t>(read<std::uint64_t>(game_ptr + game_ptr));
	if (!game.self) {
		MessageBox(NULL, XorStr("Error 103\n"), XorStr("atomic"), MB_OK | MB_ICONERROR);
		return;
	}
	Variables::datamodel = game;

	auto players = game.find_first_child(XorStr("Players"));
	if (!players.self) {
		MessageBox(NULL, XorStr("Error 102\n"), XorStr("atomic"), MB_OK | MB_ICONERROR);
		return;
	}
	Variables::players = players;
	//std::cout << "did trollage";

	Variables::visualengine = visualengine;





}



static bool driverLoaded = false;

bool atomic::roblox::init()
{
	HANDLE iqvw64e_device_handle = intel_driver::Load();

	if (!iqvw64e_device_handle || iqvw64e_device_handle == INVALID_HANDLE_VALUE) {
	//	logger.LogNormal("Driver handle failed."); //driver
		return -1;
	}

	if (!kdmapper::MapDriver(iqvw64e_device_handle, RawData)) {
		intel_driver::Unload(iqvw64e_device_handle);
		return -1;
	}

	intel_driver::Unload(iqvw64e_device_handle);

	if (!mem::find_driver()) {
		printf(XorStr("[+] Driver is not loaded.\n"));
		//logger.LogNormal("Driver is not loaded.");

		for (;;);
		return false;
	}

	mem::process_id = mem::find_process(XorStr("RobloxPlayerBeta.exe"));
	if (!mem::process_id) {
		printf(XorStr("[+] Roblox cannot be found, please open it or reinstall.\n"));
	//	logger.LogNormal("Unable to find Roblox process.");

		for (;;);
		return false;
	}

	// more protection, basically just anti debug
	//EnumWindows(EnumWindowsProc, 0);


	printf(XorStr("[initialization.cpp] connecting to moduel\n"));
	Sleep(10);

	std::vector<std::uint8_t> drv_buffer(driverlol, driversex + sizeof(driversex));

	if (!drv_buffer.size())
	{
		std::perror(XorStr("[GameStructs.cpp] invalid size\n"));

		return -1;
	}

//	physmeme::drv_image image(drv_buffer);


	//if (!physmeme::load_drv())
	//{
	//	MessageBox(NULL, XorStr("Error 103"), XorStr(":3"), MB_OK | MB_ICONWARNING);

	//	return -1;
	//}

//	physmeme::kernel_ctx kernel_ctx;

	//const auto drv_timestamp = util::get_file_header((void*)driverlol)->TimeDateStamp;
	//const auto _get_export_name = [&](const char* base, const char* name)
	//	{
	//		return reinterpret_cast<std::uintptr_t>(util::get_kernel_export(base, name));
	//	};

	//image.fix_imports(_get_export_name);
	//logger.LogNormal("Driver imports fixed.");

	//image.map();

	//logger.LogNormal("Driver mapped.");


	//const auto pool_base = kernel_ctx.allocate_pool(image.size(), NonPagedPool);
	//image.relocate(pool_base);
	//kernel_ctx.write_kernel(pool_base, image.data(), image.size());
	//auto entry_point = reinterpret_cast<std::uintptr_t>(pool_base) + image.entry_point();

	//auto result = kernel_ctx.syscall<DRIVER_INITIALIZE>
	//	(
	//		reinterpret_cast<void*>(entry_point),
	//		reinterpret_cast<std::uintptr_t>(pool_base),
	//		image.size()
	//	);

	////std::printf(XorStr("[+] entry returned: 0x%p\n"), result);

	//kernel_ctx.zero_kernel_memory(pool_base, image.header_size());





	if (!mem::find_driver())
	{
		MessageBox(NULL, XorStr("Driver is not loaded"), XorStr(""), MB_OK | MB_ICONWARNING);
		//logger.LogNormal("Post-mapping verification failed. Driver not found.");

		return false;
	}
	//logger.LogNormal("Driver mapping and verification completed successfully.");

	mem::process_id = mem::find_process(XorStr("RobloxPlayerBeta.exe"));
	if (!mem::process_id)
	{
		printf(XorStr("[initialization.cpp] roblox is not initialized\n"));
		//logger.LogNormal("Roblox is not initialized");

		return false;
	}



	Variables::window_handle = FindWindowA(NULL, XorStr("Roblox"));

	auto render_job = get_render_view();
	if (!render_job) {
		printf("[ERROR] Failed to get render job!\n");
		return false;
	}

	auto render_view = read<std::uint64_t>(render_job + 0x218);
	auto visual_engine = read<atomic::roblox::instance_t>(render_view + 0x10);
	auto game_ptr = read<std::uint64_t>(render_view + 0x120);
	auto game = static_cast<atomic::roblox::instance_t>(read<std::uint64_t>(game_ptr + atomic::offsets::FakeDataModelToRealDataModel));
	Variables::datamodel = game;
	auto players = game.find_first_child(XorStr("Players"));
	auto Workspace = game.find_first_child("Workspace");

	Variables::workspace = Workspace;

	Variables::players = players;

	std::string localplayername;

//	std::uintptr_t currentid = Variables::datamodel.get_gameid();

	Variables::playerslocation = Variables::workspace;
	//Variables::ESPPlayers = Variables::datamodel.find_first_child("Players");

	localplayername = Variables::players.get_local_player().name();
	Variables::localplayername = localplayername;

	Variables::visualengine = visual_engine;

	std::string teamname;

	std::cout << "Welcome, " << localplayername;

	atomic::roblox::instance_t team = players.get_local_player().get_team();

	if (team.self)
	{
		teamname = team.name();
	}
	else
	{
		teamname = XorStr("none");
	}

	auto placeid = static_cast<atomic::roblox::instance_t>(atomic::utils::datamodel::get_place_id());

	if (!placeid.self)

		Variables::placeid = placeid;

	Variables::LocalPlayer = players.get_local_player();

	std::thread(atomic::roblox::hookhacks).detach(); // workspace games
	printf(XorStr("[hacks.cpp] initalized exploits \n"));

	std::thread(atomic::roblox::hook_aimbot).detach();
	printf(XorStr("[aimbot.cpp] initalized aimbot \n"));

	//std::thread(atomic::roblox::trigger_hook).detach();
	//std::thread(atomic::roblox::watchdog).detach();

	thread_running = true;

	std::thread funcThread(updateThread);
	HANDLE threadHandle = funcThread.native_handle();
	funcThread.detach();

	std::thread monitorThreadInstance(monitorThread, std::ref(funcThread), std::ref(threadHandle));
	monitorThreadInstance.detach();

	std::thread(atomic::roblox::hook_flickbot).detach();
	printf(XorStr("[humanoid.cpp] initalized cache entities \n"));


	// triggerbot thread
	std::thread trigger_thread([&]() {
		while (true) {
			try {
				atomic::roblox::initTrigger();
			}
			catch (...) {
				atomic::roblox::initTrigger();
			}
		}
		});

	trigger_thread.detach();

	int_fast64_t currentid = Variables::datamodel.get_gameid();

	if (currentid == 17625359962) {
		std::cout << "[AimBot] RIVALS found" << std::endl;
		Variables::players = Variables::datamodel.find_first_child("Players - Client");
	}
	static bool ogdahood;
	if (currentid == 6134176644) { // og da hood
		if (!ogdahood) {
			std::cout << "[players] og da hood found." << std::endl;
			Variables::playerslocation = Variables::workspace.find_first_child("Players");
			ogdahood = true;
		}
	}

	static bool suvivalgame;
	if (currentid == 11156779721) { // survivalgame
		if (!suvivalgame) {
			std::cout << "[players] Survival Game Found." << std::endl;
			Variables::playerslocation = Variables::workspace;
			suvivalgame = true;
		}
	}

	static bool dahood;
	if (currentid == 2788229376) { // da hood (real)
		if (!dahood) {
			std::cout << "[players] da hood found." << std::endl;
			Variables::playerslocation = Variables::workspace.find_first_child("Players");
			dahood = true;
		}
	}

	static bool delhoodaim;
	if (currentid == 6145884111) { // del hood
		if (!delhoodaim) {
			std::cout << "[players] del hood found." << std::endl;
			Variables::playerslocation = Variables::workspace.find_first_child("Players");
			delhoodaim = true;
		}
	}

	static bool dahills;
	if (currentid == 18126537775) { // dahills
		if (!dahills) {
			std::cout << "[players] da hills found." << std::endl;
			Variables::playerslocation = Variables::workspace.find_first_child("Players");
			dahills = true;
		}
	}

	static bool dastrike;
	if (currentid == 15186202290) { // dastrike
		if (!dastrike) {
			std::cout << "[players] da strike found." << std::endl;
			Variables::playerslocation = Variables::workspace;
			dastrike = true;
		}
	}

	static bool operationssiege;
	if (currentid == 13997018456) { // operations siege
		if (!operationssiege) {
			std::cout << "[players] operations siege found." << std::endl;
			Variables::playerslocation = Variables::workspace.find_first_child("Players");
			operationssiege = true;
		}
	}

	static bool dadownhill;
	if (currentid == 17403265390) { // da downhill
		if (!dadownhill) {
			std::cout << "[players] da downhill found." << std::endl;
			Variables::playerslocation = Variables::workspace.find_first_child("Players");
			dadownhill = true;
		}
	}

	static bool flamehood;
	if (currentid == 15644861772) { // flamehood
		if (!flamehood) {
			std::cout << "[players] flame hood found." << std::endl;
			Variables::playerslocation = Variables::workspace.find_first_child("Players");
			flamehood = true;
		}
	}


	static bool hoodcustom;
	if (currentid == 9825515356) { // hood custom
		if (!hoodcustom) {
			std::cout << "[players] hood customs found" << std::endl;
			Variables::playerslocation = Variables::workspace.find_first_child("Players").find_first_child("Characters");
			hoodcustom = true;
		}
	}

	static bool arsenal;
	if (currentid == 286090429) { // arsenal
		if (!arsenal) {
			std::cout << "[players] arsenal found" << std::endl;
			Variables::playerslocation = Variables::workspace;
			arsenal = true;
		}
	}

	static bool yenohood;
	if (currentid == 17344804827) { // yeno hood
		if (!yenohood) {
			std::cout << "[players] yeno hood found." << std::endl;
			Variables::playerslocation = Variables::workspace.find_first_child("Players");
			yenohood = true;
		}
	}

	static bool deadline;
	static bool deadlines;

	if (currentid == 1315961587) { // deadline
		if (!deadline) {
			std::cout << "[players] deadline found" << std::endl;
			Variables::playerslocation = Variables::workspace.find_first_child("characters");
			deadline = true;
			deadlines = true;
		}
	}

	if (currentid != 1315961587) {
		deadlines = false;
	}

	static bool baseplate;

	if (currentid == 1430993116) { // a literal baseplate
		if (!baseplate) {
			std::cout << "[players] a literal baseplate found" << std::endl;
			Variables::playerslocation = Variables::workspace;
			baseplate = true;
		}
	}

	if (currentid == 17625359962) { // RIVALS (workspace, camlock support)
			std::cout << "[Workspace] 'RIVALS' found" << std::endl;
			Variables::workspace = Variables::datamodel.find_first_child("Workspace - Client");
	}

	else if (currentid == 0)
	{
		Sleep(1000);
	}

	//std::thread(atomic::roblox::hook_trigger).detach();
	//td::thread(atomic::roblox::hook_macro).detach();
	std::thread(atomic::utils::overlay::render).detach();

	std::thread(atomic::roblox::sdk::HookUpdate).detach(); // 4 chams :3

	std::cout << "[initialization.cpp] attached \n";
	//logger.LogNormal("init completed successfully.");

	Sleep(3000);

	ShowWindow(GetConsoleWindow(), SW_HIDE);
	std::cout << std::endl;

	while (true)
	{




		std::this_thread::sleep_for(std::chrono::milliseconds(1));


		// Sleep(0.0002);




		Variables::is_focused = GetForegroundWindow() == Variables::window_handle;


		if (FindWindowA(0, XorStr("Roblox")) == NULL) {
			//physmeme::unload_drv();
			exit(0);
		}






	}


	return true;
}

atomic::roblox::vector2_t atomic::roblox::world_to_screen(atomic::roblox::vector3_t world, atomic::roblox::vector2_t dimensions, atomic::roblox::matrix4_t viewmatrix)
{
	atomic::roblox::quaternion quaternion;

	quaternion.x = (world.x * viewmatrix.data[0]) + (world.y * viewmatrix.data[1]) + (world.z * viewmatrix.data[2]) + viewmatrix.data[3];
	quaternion.y = (world.x * viewmatrix.data[4]) + (world.y * viewmatrix.data[5]) + (world.z * viewmatrix.data[6]) + viewmatrix.data[7];
	quaternion.z = (world.x * viewmatrix.data[8]) + (world.y * viewmatrix.data[9]) + (world.z * viewmatrix.data[10]) + viewmatrix.data[11];
	quaternion.w = (world.x * viewmatrix.data[12]) + (world.y * viewmatrix.data[13]) + (world.z * viewmatrix.data[14]) + viewmatrix.data[15];

	if (quaternion.w < -0.01)
		return { -1, -1 };

	float inv_w = 1.0f / quaternion.w;
	vector3_t ndc;
	ndc.x = quaternion.x * inv_w;
	ndc.y = quaternion.y * inv_w;
	ndc.z = quaternion.z * inv_w;

	atomic::roblox::vector2_t screenPos = {
		(dimensions.x / 2 * ndc.x) + (dimensions.x / 2),
		-(dimensions.y / 2 * ndc.y) + (dimensions.y / 2)
	};

	if (screenPos.x < 0 || screenPos.x > dimensions.x || screenPos.y < 0 || screenPos.y > dimensions.y)
		return { -1, -1 };

	return screenPos;
}

atomic::roblox::vector2_t atomic::roblox::world_to_screen2(atomic::roblox::vector3_t pos, atomic::roblox::vector2_t dimensions, atomic::roblox::matrix4_t viewmatrix)
{
	atomic::roblox::quaternion quater;
	quater.x = pos.x * viewmatrix.data[0] + pos.y * viewmatrix.data[1] + pos.z * viewmatrix.data[2] + viewmatrix.data[3];
	quater.y = pos.x * viewmatrix.data[4] + pos.y * viewmatrix.data[5] + pos.z * viewmatrix.data[6] + viewmatrix.data[7];
	quater.z = pos.x * viewmatrix.data[8] + pos.y * viewmatrix.data[9] + pos.z * viewmatrix.data[10] + viewmatrix.data[11];
	quater.w = pos.x * viewmatrix.data[12] + pos.y * viewmatrix.data[13] + pos.z * viewmatrix.data[14] + viewmatrix.data[15];

	if (quater.w < 0.1f) {
		return { -1, -1 };
	}

	atomic::roblox::vector3_t ndc;
	ndc.x = quater.x / quater.w;
	ndc.y = quater.y / quater.w;
	ndc.z = quater.z / quater.w;

	atomic::roblox::vector2_t screen;
	screen.x = (dimensions.x / 2 * ndc.x) + (dimensions.x / 2);
	screen.y = -(dimensions.y / 2 * ndc.y) + (dimensions.y / 2);
	return screen;
}




std::tuple<atomic::roblox::instance_t, atomic::roblox::instance_t> atomic::roblox::get_closest_player_to_cursor() {
	POINT cursor_point;
	GetCursorPos(&cursor_point);
	ScreenToClient(FindWindowA(0, ("Roblox")), &cursor_point);

	atomic::roblox::vector2_t cursor = {
		static_cast<float>(cursor_point.x),
		static_cast<float>(cursor_point.y)
	};

	srand(static_cast<unsigned int>(time(nullptr)));

	////////////////////////////////////////////////////////////
	auto players = Variables::players;


	atomic::roblox::instance_t closest_player;
	atomic::roblox::instance_t _body_part;
	float min_dist = 9e9;

	auto dimensions = Variables::visualengine.get_dimensions();
	auto view_matrix = Variables::visualengine.get_view_matrix();
	auto local_player = players.get_local_player();

	for (auto& player : players.children()) {
		std::string player_name = player.name();

		if (player.self == local_player.self || Variables::aimwhitelistedPlayers.find(player_name) != Variables::aimwhitelistedPlayers.end())
			continue;

		auto character = player.get_model_instance();
		if (!character.self)
			continue;

		auto humanoid = character.find_first_child("Humanoid");
		if (!humanoid.self)
			continue;

		auto team = player.get_team();
		if (Variables::team_check && (team.self == local_player.get_team().self))
			continue;

		if (Variables::knock_check && humanoid.get_health() <= 3)
			continue;

		atomic::roblox::instance_t body_part;
        int randompart = rand() % 19;
		switch (Variables::aimpart) {
		case 0:

			
				switch (randompart) {
				case 0:
					body_part = character.find_first_child("Head");
					break;
				case 1:
					body_part = character.find_first_child("UpperTorso");
					break;
				case 2:
					body_part = character.find_first_child("HumanoidRootPart");
					break;
				case 3:
					body_part = character.find_first_child("LowerTorso");
					break;
				case 4:
					body_part = character.find_first_child("LeftUpperArm");
					break;
				case 5:
					body_part = character.find_first_child("LeftLowerArm");
					break;
				case 6:
					body_part = character.find_first_child("LeftHand");
					break;
				case 7:
					body_part = character.find_first_child("RightUpperArm");
					break;
				case 8:
					body_part = character.find_first_child("RightLowerArm");
					break;
				case 9:
					body_part = character.find_first_child("RightHand");
					break;
				case 10:
					body_part = character.find_first_child("LeftUpperLeg");
					break;
				case 11:
					body_part = character.find_first_child("LeftLowerLeg");
					break;
				case 12:
					body_part = character.find_first_child("LeftFoot");
					break;
				case 13:
					body_part = character.find_first_child("RightUpperLeg");
					break;
				case 14:
					body_part = character.find_first_child("RightLowerLeg");
					break;
				case 15:
					body_part = character.find_first_child("RightFoot");
					break;
				case 16:
					body_part = character.find_first_child("HumanoidRootPart");
					break;
				case 17:
					body_part = character.find_first_child("Head");
					break;
				case 18:
					body_part = character.find_first_child("UpperTorso");
					break;
				case 19:
					body_part = character.find_first_child("LowerTorso");
					break;
				}
				break;

		case 1:
			body_part = character.find_first_child("Head");
			break;
		case 2:
			body_part = character.find_first_child("UpperTorso");
			break;
		case 3:
			body_part = character.find_first_child("HumanoidRootPart");
			break;
		case 4:
			body_part = character.find_first_child("LowerTorso");
			break;
		case 5:
			body_part = character.find_first_child("Torso");
			break;
		}

		if (!body_part.self)
			continue;

		auto part_pos_screen = atomic::roblox::world_to_screen(body_part.get_part_pos(), dimensions, view_matrix);
		float dist = calculate_distance(part_pos_screen, cursor);


		if ((!Variables::disable_outside_fov || dist < Variables::fov) && (min_dist > dist)) {
			closest_player = player;
			min_dist = dist;
			_body_part = body_part;
		}
	}

	return { _body_part, closest_player };
}







std::string readstring(std::uint64_t address)
{
	std::string string;
	char character = 0;
	int char_size = sizeof(character);
	int offset = 0;

	string.reserve(204);

	while (offset < 200)
	{
		character = read<char>(address + offset);

		if (character == 0)
			break;

		offset += char_size;
		string.push_back(character);
	}

	return string;
}

std::string readstring2(std::uint64_t string)
{
	const auto length = read<int>(string + 0x18);

	if (length >= 16u)
	{
		const auto New = read<std::uint64_t>(string);
		return readstring(New);
	}
	else
	{
		const auto Name = readstring(string);
		return Name;
	}
}

std::string atomic::roblox::instance_t::name()
{
	const auto ptr = read<std::uint64_t>(this->self + atomic::offsets::name);

	if (ptr)
		return readstring2(ptr);

	return XorStr("???");
}

std::string atomic::roblox::instance_t::class_name()
{
	const auto ptr = read<std::uint64_t>(this->self + atomic::offsets::classname);

	if (ptr)
		return readstring2(ptr + 0x8);

	return XorStr("???_classname");
}

std::vector<atomic::roblox::instance_t> atomic::roblox::instance_t::children()
{
	std::vector<atomic::roblox::instance_t> container;

	if (!this->self)
		return container;

	auto start = read<std::uint64_t>(this->self + atomic::offsets::children);

	if (!start)
		return container;

	auto end = read<std::uint64_t>(start + offsets::size);

	for (auto instances = read<std::uint64_t>(start); instances != end; instances += 16)
		container.emplace_back(read<atomic::roblox::instance_t>(instances));

	return container;
}


atomic::roblox::matrix3_t atomic::roblox::instance_t::get_camera_rotation()
{
	auto camera_rotation = read<atomic::roblox::matrix3_t>(this->self + atomic::offsets::camera_rotation);
	return camera_rotation;
}

void atomic::roblox::instance_t::write_camera_rotation(atomic::roblox::matrix3_t Rotation)
{
	write<atomic::roblox::matrix3_t>(this->self + atomic::offsets::camera_rotation, Rotation);
}



atomic::roblox::instance_t atomic::roblox::instance_t::get_camera()
{
	auto camera = read<atomic::roblox::instance_t>(this->self + offsets::camera);
	return camera;
}

atomic::roblox::instance_t atomic::roblox::instance_t::find_first_child(std::string child)
{
	atomic::roblox::instance_t ret;

	for (auto& object : this->children())
	{
		if (object.name() == child)
		{
			ret = static_cast<atomic::roblox::instance_t>(object);
			break;
		}
	}

	return ret;
}

int atomic::roblox::instance_t::readplayers(std::uint64_t address) {
	return read<int>(address);
}

float atomic::roblox::instance_t::get_ping()
{
	float ping = read<float>(this->self + 0x3F8);
	return ping * 2000;
}

atomic::roblox::matrix3_t atomic::roblox::instance_t::get_part_rotation()
{
	auto primitive = read<std::uint64_t>(this->self + atomic::offsets::primitive);
	return read<atomic::roblox::matrix3_t>(primitive + atomic::offsets::rotation);
}


atomic::roblox::instance_t atomic::roblox::instance_t::get_local_player()
{
	auto local_player = read<atomic::roblox::instance_t>(this->self + atomic::offsets::local_player);
	return local_player;
}

atomic::roblox::instance_t atomic::roblox::instance_t::Spectate(std::string stringhere) {
	atomic::roblox::instance_t dis;
	write<std::uint64_t>(Variables::workspace.find_first_child("Camera").self + 0xC0, Variables::players.find_first_child(stringhere).get_model_instance().find_first_child("Head").self);
	return dis;
}

atomic::roblox::instance_t atomic::roblox::instance_t::UnSpectate() {
	atomic::roblox::instance_t wtv;
	write<std::uint64_t>(Variables::workspace.find_first_child("Camera").self + 0xC0, Variables::players.get_local_player().get_model_instance().find_first_child("Humanoid").self);
	return wtv;
}

atomic::roblox::instance_t atomic::roblox::instance_t::get_model_instance()
{
	auto character = read<atomic::roblox::instance_t>(this->self + atomic::offsets::model_instance);
	return character;
}

atomic::roblox::vector2_t atomic::roblox::instance_t::get_dimensions()
{
	auto dimensions = read<atomic::roblox::vector2_t>(this->self + offsets::dimensions);
	return dimensions;
}

atomic::roblox::matrix4_t atomic::roblox::instance_t::get_view_matrix()
{
	auto dimensions = read<atomic::roblox::matrix4_t>(this->self + offsets::viewmatrix);
	return dimensions;
}

atomic::roblox::vector3_t atomic::roblox::instance_t::get_camera_pos()
{
	auto camera_pos = read<atomic::roblox::vector3_t>(this->self + offsets::camera_pos);
	return camera_pos;
}

atomic::roblox::vector3_t atomic::roblox::instance_t::get_part_pos()
{
	vector3_t res{};

	auto primitive = read<std::uint64_t>(this->self + offsets::primitive);

	if (!primitive)
		return res;

	res = read<atomic::roblox::vector3_t>(primitive + offsets::position);
	return res;
}


atomic::roblox::vector3_t atomic::roblox::instance_t::set_part_pos(vector3_t arghere)
{
	vector3_t res{};

	auto primitive = read<std::uint64_t>(this->self + offsets::primitive);

	if (!primitive)
		return res;

	int count = 0;
	while (true) {

		count = count + 1;
		write<atomic::roblox::vector3_t>(primitive + offsets::position, arghere);
		if (count == 10000) {
			break;
		}

	}
	res = write<atomic::roblox::vector3_t>(primitive + offsets::position, arghere);
	return res;
}


atomic::roblox::vector3_t atomic::roblox::instance_t::set_part_pos_loop(vector3_t arghere)
{
	vector3_t res{};

	auto primitive = read<std::uint64_t>(this->self + offsets::primitive);

	if (!primitive)
		return res;

	res = write<atomic::roblox::vector3_t>(primitive + offsets::position, arghere);
	return res;
}

atomic::roblox::vector3_t atomic::roblox::instance_t::SetCurrentPartPos(atomic::roblox::vector3_t pos)
{
	vector3_t res{};

	auto primitive = read<std::uint64_t>(this->self + offsets::primitive);

	if (!primitive)
		return res;

	res = write<atomic::roblox::vector3_t>(primitive + offsets::position, pos);
	return res;
}

atomic::roblox::vector3_t atomic::roblox::instance_t::get_part_velocity()
{
	vector3_t res{};

	auto primitive = read<std::uint64_t>(this->self + offsets::primitive);

	if (!primitive)
		return res;

	res = read<atomic::roblox::vector3_t>(primitive + offsets::velocity);
	return res;
}

union convertion
{
	std::uint64_t hex;
	float f;
} conv;

float atomic::roblox::instance_t::get_health()
{
	auto one = read<std::uint64_t>(this->self + 0x184);
	auto two = read<std::uint64_t>(read<std::uint64_t>(this->self + 0x184));

	conv.hex = one ^ two;
	return conv.f;
}

float atomic::roblox::instance_t::get_max_health()
{
	auto one = read<std::uint64_t>(this->self + 0x1A4);
	auto two = read<std::uint64_t>(read<std::uint64_t>(this->self + 0x1A4));

	conv.hex = one ^ two;
	return conv.f;
}


atomic::roblox::instance_t atomic::roblox::instance_t::get_cframe()
{
	auto players = Variables::players;

	atomic::roblox::instance_t closest_player;

	int min_dist = 9e9;
	std::string teamname;

	auto localplayer = players.get_local_player();
	auto localplayer_team = localplayer.get_team();

	auto dimensions = Variables::visualengine.get_dimensions();
	auto viewmatrix = Variables::visualengine.get_view_matrix();

	for (auto player : players.children())
	{
		auto character = player.get_model_instance();

		auto getcframe = read<atomic::roblox::instance_t>(this->self + 0x11c);


	}

}


atomic::roblox::instance_t atomic::roblox::instance_t::get_team()
{
	auto getteam = read<atomic::roblox::instance_t>(this->self + atomic::offsets::team);
	return getteam;
}

std::uintptr_t atomic::roblox::instance_t::get_gameid()
{
	uint8_t buffer[8]; // int64 is 8 bytes
	int_fast64_t value = 0;

	mem::read_physical(reinterpret_cast<PVOID>(this->self + 0x168), buffer, sizeof(buffer));
	memcpy(&value, buffer, sizeof(value)); // possible detection here, oh well.

	return value;
}


//int atomic::roblox::instance_t::get_armor() {
//
//	int armor = read<int>(this->self + atomic::offsets::armor);
//	return armor;
//}

void atomic::roblox::instance_t::set_humanoid_walkspeed(float value)
{
	auto humanoid_instance = this->get_local_player().get_model_instance().find_first_child("Humanoid");




	if (humanoid_instance.self) {
		write<float>(humanoid_instance.self + 0x1B0, value);
		write<float>(humanoid_instance.self + atomic::offsets::walkspeed, value);
	}
}



void atomic::roblox::instance_t::set_humanoid_jumppower(float value)
{
	auto humanoid_instance = this->get_local_player().get_model_instance().find_first_child("Humanoid");




	if (humanoid_instance.self) {
		write<float>(humanoid_instance.self + 0x190, value);
		write<float>(humanoid_instance.self + atomic::offsets::jumppower, value);
	}
}

atomic::roblox::cframe_t atomic::roblox::instance_t::set_part_cframe(atomic::roblox::cframe_t cf)
{
	cframe_t res{};

	auto primitive = read<std::uint64_t>(this->self + offsets::primitive);

	if (!primitive)
		return res;

	res = write<atomic::roblox::cframe_t>(primitive + 0x11C, cf);
	return res;
}

atomic::roblox::cframe_t atomic::roblox::instance_t::get_part_cframe()
{
	atomic::roblox::cframe_t res{};

	auto primitive = read<std::uint64_t>(this->self + offsets::primitive);

	if (!primitive)
		return res;

	res = read<atomic::roblox::cframe_t>(primitive + 0x11C);
	return res;
}

void atomic::roblox::instance_t::set_humanoid_fov(float value)
{
	auto workspace = Variables::workspace;
	auto camera = workspace.get_camera();

	Variables::camerafov * 200 / std::numbers::pi_v<float>;

	write<float>(camera.self + 0x138, Variables::camerafov); // write to FOV offset !
}