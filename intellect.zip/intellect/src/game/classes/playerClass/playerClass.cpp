#include "playerClass.h"
#include <iterator>
#include <algorithm>
#include <mutex>

std::vector<Player> playerList;