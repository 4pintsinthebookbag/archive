#pragma once
#include <vector>

#include "../src/game/classes/GameStructs.hpp"
#include "../src/game/Variables/Variables.hpp"
#include <mutex>



class Player {
public:
    atomic::roblox::instance_t playerInstance;
    atomic::roblox::instance_t headInstance;
    atomic::roblox::instance_t hrpInstance;
    atomic::roblox::instance_t humanoid;
    atomic::roblox::instance_t modelinstance;
    atomic::roblox::vector2_t hrpPos2d;
    atomic::roblox::instance_t armorpath;
    atomic::roblox::instance_t humanoidInstance;
    atomic::roblox::instance_t leftupperarm;
    atomic::roblox::instance_t rightupperarm;
    atomic::roblox::instance_t leftelbow;
    atomic::roblox::instance_t rightelbow;
    atomic::roblox::instance_t lefthand;
    atomic::roblox::instance_t righthand;
    atomic::roblox::instance_t leftleg;
    atomic::roblox::instance_t rightleg;

    // atomic::roblox::matrix3_t hrpRotation;
    Player() :
        playerInstance(),
        headInstance(),
        armorpath(),
        hrpInstance(),
        humanoid(),
        //    hrpRotation(),
        hrpPos2d(),
        modelinstance()

    {}

    bool operator==(const Player& other) const {
        return playerInstance == other.playerInstance;
    }
};

extern std::vector<Player> playerList;