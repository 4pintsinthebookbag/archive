#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace atomic {
    namespace offsets
    {
        constexpr std::uint32_t RenderToEngine = 0x10;
        constexpr std::uint32_t RenderToFakeDataModel = 0x120;
        constexpr std::uint32_t FakeDataModelToRealDataModel = 0x1b8;
        constexpr std::uint32_t size = 0x8;
        constexpr std::uint32_t name = 0x78;
        constexpr std::uint32_t displayname = 0x118;
        constexpr std::uint32_t children = 0x80;
        constexpr std::uint32_t parent = 0x60;
        constexpr std::uint32_t local_player = 0x128;
        constexpr std::uint32_t model_instance = 0x2E8;
        constexpr std::uint32_t primitive = 0x170;
        constexpr std::uint32_t position = 0x140;
        constexpr std::uint32_t dimensions = 0x740;
        constexpr std::uint32_t viewmatrix = 0x4D0;
        constexpr std::uint32_t classname = 0x18;
        constexpr std::uint32_t health = 0x19C;
        constexpr std::uint32_t max_health = 0x1BC;
        constexpr std::uint32_t walkspeed = 0x1D8;
        //constexpr std::uint32_t jumpspeed = 0x1B8;
        constexpr std::uint32_t team = 0x218;
        constexpr std::uint32_t gameid = 0x198;
        constexpr std::uint32_t velocity = 0x14C;
        constexpr std::uint32_t camera_pos = 0x124;
        constexpr std::uint32_t camera = 0x3F8;
        constexpr std::uint32_t camera_rotation = 0x100;
        constexpr std::uint32_t walkspeed_a = 0x1D8;
        constexpr std::uint32_t walkspeed_b = 0x3A8;
        //constexpr std::uint32_t armor = 0xC0;
        constexpr std::uint32_t jumppower = 0x1B8;
        constexpr std::uint32_t hipheight = 0x1A8;
        constexpr std::uint32_t ping = 0xD0;
        //constexpr std::uint32_t datamodel = 0x198;
        constexpr std::uint32_t humanoid_instance = 0x60;
        constexpr std::uint32_t rotation = 0x124;

    }

    namespace roblox
    {
        bool init();
        void reinitializeComponents();
        void AddNotification(const std::string& text, float duration = 1.0f, int type = 1);


        struct vector2_t final {

            float x, y;

            vector2_t operator+(const vector2_t& rhs) const {
                return { x + rhs.x, y + rhs.y };
            }

            vector2_t operator-(const vector2_t& rhs) const {
                return { x - rhs.x, y - rhs.y };
            }

            vector2_t operator*(float scalar) const {
                return { x * scalar, y * scalar };
            }

            vector2_t& operator+=(const vector2_t& rhs) {
                x += rhs.x;
                y += rhs.y;
                return *this;
            }

            vector2_t& operator-=(const vector2_t& rhs) {
                x -= rhs.x;
                y -= rhs.y;
                return *this;
            }

        };
        struct vector3_t final {

            float x, y, z;

            vector3_t operator+(const vector3_t& rhs) const {
                return { x + rhs.x, y + rhs.y, z + rhs.z };
            }

            vector3_t operator-(const vector3_t& rhs) const {
                return { x - rhs.x, y - rhs.y, z - rhs.z };
            }

            vector3_t operator*(float scalar) const {
                return { x * scalar, y * scalar, z * scalar };
            }

            vector3_t operator/(const vector3_t& rhs) const {
                return { x / rhs.x, y / rhs.y, z / rhs.z };
            }

            vector3_t& operator+=(const vector3_t& rhs) {
                x += rhs.x;
                y += rhs.y;
                z += rhs.z;
                return *this;
            }

            vector3_t& operator-=(const vector3_t& rhs) {
                x -= rhs.x;
                y -= rhs.y;
                z -= rhs.z;
                return *this;
            }


            vector3_t operator/(float scalar) const {
                return { x / scalar, y / scalar, z / scalar };
            }



            float distance(const atomic::roblox::vector3_t& b) {
                return sqrtf(pow((x - b.x), 2) + pow((y - b.y), 2) + pow((z - b.z), 2));
            }
        };


        struct quaternion final { float x, y, z, w; };
        struct matrix4_t final { float data[16]; };
        struct matrix3_t final { float data[9]; };
        // cframe nigga shit
        struct cframe_t
        {
            vector3_t right_vector = { 1, 0, 0 };
            vector3_t up_vector = { 0, 1, 0 };
            vector3_t back_vector = { 0, 0, 1 };
            vector3_t position = { 0, 0, 0 };

            cframe_t() = default;
            cframe_t(vector3_t position) : position{ position } {}
            cframe_t(vector3_t right_vector, vector3_t up_vector, vector3_t back_vector, vector3_t position) : right_vector{ right_vector }, up_vector{ up_vector }, back_vector{ back_vector }, position{ position } {}

        public:
            void look_at_locked(vector3_t point) noexcept // NOTE: Y DIRECTION IS LOCKED
            {
               // vector3_t look_vector = (this->position - point).normalize() * vector3_t { 1, 0, 1 }; // simulate as if aligned with y axis
               // vector3_t right_vector = vector3_t{ 0, 1, 0 }.cross(look_vector); // this is a must since I need a 90* angle still
                vector3_t up_vector = { 0, 1, 0 }; // since we've simulated as if y was on same level, no point to do this cross calculation

                this->right_vector = right_vector;
                this->up_vector = up_vector;
          //      this->back_vector = look_vector * vector3_t{ -1, -1, -1 };
            }

            cframe_t look_at(vector3_t point) noexcept
            {
              //  vector3_t look_vector = (position - point).normalize() * vector3_t { -1, -1, -1 };
              //  vector3_t right_vector = vector3_t(0, 1, 0).cross(look_vector);
                //vector3_t up_vector = look_vector.cross(right_vector);

            //   return cframe_t{ right_vector, up_vector, look_vector, this->position };
            }

            auto operator*(cframe_t cframe) const noexcept
            {
                cframe_t ret;

                ret.right_vector =
                {
                    right_vector.x * cframe.right_vector.x + right_vector.y * cframe.up_vector.x + right_vector.z * cframe.back_vector.x,
                    right_vector.x * cframe.right_vector.y + right_vector.y * cframe.up_vector.y + right_vector.z * cframe.back_vector.y,
                    right_vector.x * cframe.right_vector.z + right_vector.y * cframe.up_vector.z + right_vector.z * cframe.back_vector.z
                };
                ret.up_vector =
                {
                    up_vector.x * cframe.right_vector.x + up_vector.y * cframe.up_vector.x + up_vector.z * cframe.back_vector.x,
                    up_vector.x * cframe.right_vector.y + up_vector.y * cframe.up_vector.y + up_vector.z * cframe.back_vector.y,
                    up_vector.x * cframe.right_vector.z + up_vector.y * cframe.up_vector.z + up_vector.z * cframe.back_vector.z
                };
                ret.back_vector =
                {
                    back_vector.x * cframe.right_vector.x + back_vector.y * cframe.up_vector.x + back_vector.z * cframe.back_vector.x,
                    back_vector.x * cframe.right_vector.y + back_vector.y * cframe.up_vector.y + back_vector.z * cframe.back_vector.y,
                    back_vector.x * cframe.right_vector.z + back_vector.y * cframe.up_vector.z + back_vector.z * cframe.back_vector.z
                };
                ret.position =
                {
                    right_vector.x * cframe.position.x + right_vector.y * cframe.position.y + right_vector.z * cframe.position.z + position.x,
                    up_vector.x * cframe.position.x + up_vector.y * cframe.position.y + up_vector.z * cframe.position.z + position.y,
                    back_vector.x * cframe.position.x + back_vector.y * cframe.position.y + back_vector.z * cframe.position.z + position.z
                };

                return ret;
            }

            auto operator*(vector3_t vec) const noexcept
            {
                vector3_t ret;

                ret.x = right_vector.x * vec.x + right_vector.y * vec.y + right_vector.z * vec.z + position.x;
                ret.y = up_vector.x * vec.x + up_vector.y * vec.y + up_vector.z * vec.z + position.y;
                ret.z = back_vector.x * vec.x + back_vector.y * vec.y + back_vector.z * vec.z + position.z;

                return ret;
            }
        };

        struct HumanoidRootPart {
            char pad_0[0x11C];
            atomic::roblox::matrix3_t rotation;
            atomic::roblox::vector3_t position;
            atomic::roblox::vector3_t velocity;
        };

        class instance_t final
        {
        public:

            std::uint64_t self;

            std::string name();
            std::string class_name();
            std::vector<atomic::roblox::instance_t> children();
            atomic::roblox::instance_t find_first_child(std::string child);
            int_fast64_t GetGameId();

            int readplayers(std::uint64_t address);

            atomic::roblox::instance_t get_local_player();
            atomic::roblox::instance_t Spectate(std::string stringhere);
            atomic::roblox::instance_t UnSpectate();
            atomic::roblox::matrix3_t get_part_rotation();

            atomic::roblox::instance_t get_model_instance();
            atomic::roblox::instance_t get_team();
            std::uintptr_t get_gameid();
            atomic::roblox::instance_t get_workspace();
            int get_armor();
            atomic::roblox::instance_t get_current_camera();
            void SetWalkspeed(float value);
            atomic::roblox::instance_t get_camera();

            atomic::roblox::vector2_t get_dimensions();
            atomic::roblox::matrix4_t get_view_matrix();
            atomic::roblox::vector3_t get_camera_pos();
            atomic::roblox::vector3_t get_part_pos();
            atomic::roblox::vector3_t set_part_pos(vector3_t arghere);
            atomic::roblox::vector3_t set_part_pos_loop(vector3_t arghere);
            atomic::roblox::vector3_t SetCurrentPartPos(atomic::roblox::vector3_t pos);
            atomic::roblox::vector3_t get_part_velocity();
            atomic::roblox::vector3_t get_hipHeight();
            atomic::roblox::matrix3_t get_camera_rotation();
            void write_camera_rotation(atomic::roblox::matrix3_t Rotation);

            void set_humanoid_fov(float value);
            atomic::roblox::cframe_t set_part_cframe(atomic::roblox::cframe_t cf);
            atomic::roblox::cframe_t get_part_cframe();
            void set_humanoid_hipheight(float value);
            void set_humanoid_jumppower(float value);


            float get_health();
            float get_max_health();

            atomic::roblox::instance_t get_cframe();

            void set_humanoid_walkspeed(float value);

            float get_ping();

            bool operator==(const instance_t& other) const {
                return this->self == other.self;
            }

        };

        atomic::roblox::vector2_t world_to_screen(atomic::roblox::vector3_t world, atomic::roblox::vector2_t dimensions, atomic::roblox::matrix4_t viewmatrix);
        atomic::roblox::vector2_t world_to_screen2(atomic::roblox::vector3_t pos, atomic::roblox::vector2_t dimensions, atomic::roblox::matrix4_t viewmatrix);
        std::tuple<atomic::roblox::instance_t, atomic::roblox::instance_t> get_closest_player_to_cursor();
       // std::tuple<atomic::roblox::instance_t, atomic::roblox::instance_t> get_closest_player_to_cursor();
    }
}


atomic::roblox::HumanoidRootPart readVector(std::uint64_t address);


struct PlayerObject final {
    std::string Name;
    std::string PlayerName;
    atomic::roblox::instance_t Instance;
};