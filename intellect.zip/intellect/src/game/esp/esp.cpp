#include "esp.hpp"

#include "../../base/overlay/imgui/imgui.h"
#include "../Variables/Variables.hpp"

#include <Windows.h>

#include "../src/game/classes/playerClass/playerClass.h"
#include <thread>
#include <iostream>
#include <game/sdk.h>
float calc_dist_3d(atomic::roblox::vector3_t first, atomic::roblox::vector3_t sec)
{
    return sqrt((first.x - sec.x) * (first.x - sec.x) + (first.y - sec.y) * (first.y - sec.y) + (first.z - sec.z) * (first.z - sec.z));
}

atomic::roblox::vector3_t vector_sub(atomic::roblox::vector3_t one, atomic::roblox::vector3_t two)
{
    return { one.x - two.x, one.y - two.y, one.z - two.z };
}

float vector3_mag(atomic::roblox::vector3_t vector)
{
    return sqrtf((vector.x * vector.y) + (vector.y * vector.y) + (vector.z * vector.z));
}



float calc_dist_vec3_op(atomic::roblox::vector3_t a, atomic::roblox::vector3_t b) {
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y) + (a.z - b.z) * (a.z - b.z));
}

namespace vector_ops {
    float distance(const atomic::roblox::vector3_t& a, const atomic::roblox::vector3_t& b) {
        return sqrtf((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y) + (a.z - b.z) * (a.z - b.z));
    }

    atomic::roblox::vector3_t subtract(const atomic::roblox::vector3_t& a, const atomic::roblox::vector3_t& b) {
        return { a.x - b.x, a.y - b.y, a.z - b.z };
    }

    float magnitude(const atomic::roblox::vector3_t& v) {
        return sqrtf(v.x * v.x + v.y * v.y + v.z * v.z);
    }
}


static atomic::roblox::vector3_t crossProduct(const atomic::roblox::vector3_t& vec1, const atomic::roblox::vector3_t& vec2) {
    return {
        vec1.y * vec2.z - vec1.z * vec2.y,
        vec1.z * vec2.x - vec1.x * vec2.z,
        vec1.x * vec2.y - vec1.y * vec2.x
    };
}

static atomic::roblox::vector3_t add_vector3(const atomic::roblox::vector3_t& first, const atomic::roblox::vector3_t& second)
{
    return { first.x + second.x, first.y + second.y, first.z + second.z };
}

static std::vector<atomic::roblox::vector3_t> GetCorners(const atomic::roblox::vector3_t& partCF, const atomic::roblox::vector3_t& partSize) {
    std::vector<atomic::roblox::vector3_t> corners;

    for (int X = -1; X <= 1; X += 2) {
        for (int Y = -1; Y <= 1; Y += 2) {
            for (int Z = -1; Z <= 1; Z += 2) {
                atomic::roblox::vector3_t cornerPosition = {
                    partCF.x + partSize.x * X,
                    partCF.y + partSize.y * Y,
                    partCF.z + partSize.z * Z
                };
                corners.push_back(cornerPosition);
            }
        }
    }

    return corners;
}

atomic::roblox::vector3_t getLocalPlayerPosition() {
    if (!playerList.empty()) {
        return playerList.front().hrpInstance.get_part_pos();
    }
    return { 0.0f, 0.0f, 0.0f };
}

ImVec2 V2Convert(atomic::roblox::vector2_t v2)
{
    return ImVec2(v2.x, v2.y);
}


static atomic::roblox::vector3_t normalize(const atomic::roblox::vector3_t& vec) {
    float length = sqrt(vec.x * vec.x + vec.y * vec.y + vec.z * vec.z);
    if (length != 0) {
        return { vec.x / length, vec.y / length, vec.z / length };
    }
    else {
        return vec;
    }
}

static atomic::roblox::vector3_t multiply_vector3_by(const atomic::roblox::vector3_t& first, float value) {
    return { first.x * value, first.y * value, first.z * value };
}

static float dotProduct(const atomic::roblox::vector3_t& vec1, const atomic::roblox::vector3_t& vec2) {
    return vec1.x * vec2.x + vec1.y * vec2.y + vec1.z * vec2.z;
}

static atomic::roblox::vector3_t vector_add(atomic::roblox::vector3_t one, atomic::roblox::vector3_t two) {
    return { one.x + two.x, one.y + two.y, one.z + two.z };
}

inline float DEG2RAD(float degrees) {
    return degrees * static_cast<float>(M_PI) / 180.0f;
}

inline float RAD2DEG(float radians) {
    return radians * 180.0f / static_cast<float>(M_PI);
}

HWND GetRobloxWindowHandle() {
    return FindWindowA(NULL, "Roblox");
}
long long currentTimeMillis() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
}

long long lastRadarUpdate = 0;


void DrawRadar() {
    static float angle = 0.0f;
    angle = fmodf(angle + 0.05f, 6.28319f);

    auto localPlayer = Variables::players.get_local_player();
    if (!localPlayer.self) return;

    auto localPlayerCharacter = localPlayer.get_model_instance();
    if (!localPlayerCharacter.self) return;

    auto localPlayerPos = localPlayerCharacter.find_first_child("HumanoidRootPart").get_part_pos();

    const ImVec2 radarCenter(150, 150);
    const float radarSize = 150.0f;
    const float maxRadarRange = 200.0f;
    const float dotSize = 3.0f;
    const float cornerRadius = 15.0f;
    const ImU32 backgroundColor = IM_COL32(50, 50, 50, 128);
    const ImU32 outlineColor = IM_COL32(128, 0, 128, 255);
    const ImU32 lineColor = IM_COL32(0, 255, 0, 255);
    const ImU32 textColor = IM_COL32_WHITE;
    const ImVec2 halfRadarSize(radarSize * 0.5f, radarSize * 0.5f);
    const ImVec2 radarTopLeft = radarCenter - halfRadarSize;
    const ImVec2 radarBottomRight = radarCenter + halfRadarSize;

    auto drawList = ImGui::GetBackgroundDrawList();
    drawList->AddRectFilled(radarTopLeft, radarBottomRight, backgroundColor, cornerRadius);
    drawList->AddRect(radarTopLeft, radarBottomRight, outlineColor, cornerRadius);

    ImVec2 endPoint(cosf(angle) * halfRadarSize.x, sinf(angle) * halfRadarSize.y);
    drawList->AddLine(radarCenter, radarCenter + endPoint, lineColor, 1.0f);

    const float textOffset = 10.0f;
    drawList->AddText(radarCenter + ImVec2(-textOffset, -radarSize * 0.5f - 20), textColor, "N");
    drawList->AddText(radarCenter + ImVec2(radarSize * 0.5f + 5, -textOffset), textColor, "E");
    drawList->AddText(radarCenter + ImVec2(-textOffset, radarSize * 0.5f + 5), textColor, "S");
    drawList->AddText(radarCenter + ImVec2(-radarSize * 0.5f - 20, -textOffset), textColor, "W");

    for (auto& player : Variables::players.children()) {
        if (player.self == localPlayer.self || !player.get_model_instance().self) continue;

        auto playerPos = player.get_model_instance().find_first_child("HumanoidRootPart").get_part_pos();
        ImVec2 delta = ImVec2(playerPos.x - localPlayerPos.x, playerPos.z - localPlayerPos.z);
        float distance = sqrtf(delta.x * delta.x + delta.y * delta.y);

        if (distance <= maxRadarRange) {
            ImVec2 radarDotPos = ImVec2((delta.x / maxRadarRange) * halfRadarSize.x, (delta.y / maxRadarRange) * halfRadarSize.y);
            radarDotPos = radarCenter + radarDotPos - ImVec2(dotSize * 0.5f, dotSize * 0.5f);

            bool isEnemy = Variables::team_check ? player.get_team().self != localPlayer.get_team().self : true;
            ImU32 color = isEnemy ? IM_COL32(255, 0, 0, 255) : IM_COL32(0, 255, 0, 255);
            drawList->AddCircleFilled(radarDotPos, dotSize, color);
        }
    }

    drawList->AddCircleFilled(radarCenter, dotSize, IM_COL32(0, 0, 255, 255));
}


void crosshair() {
    static float angle = 0.0f;
    angle += 1.0f;
    if (angle > 360.0f) angle -= 360.0f;

    POINT cursor_pos;
    GetCursorPos(&cursor_pos);
    HWND hwndRoblox = FindWindowA(0, "Roblox");
    ScreenToClient(hwndRoblox, &cursor_pos);

    ImVec2 center = ImVec2(static_cast<float>(cursor_pos.x), static_cast<float>(cursor_pos.y));
    float length = Variables::lenght;
    float gap = Variables::gap;
    float segmentLength = (length - gap) / 2.0f;
    float thickness = Variables::thickness;
    ImU32 color = IM_COL32(255, 255, 255, 255);

    float radAngle = DEG2RAD(angle);

    for (int i = 0; i < 2; i++) {
        float offsetAngle = i * DEG2RAD(90.0f);

        ImVec2 segmentStart1(center.x + cosf(radAngle + offsetAngle) * gap / 2.0f, center.y + sinf(radAngle + offsetAngle) * gap / 2.0f);
        ImVec2 segmentEnd1(center.x + cosf(radAngle + offsetAngle) * (gap / 2.0f + segmentLength), center.y + sinf(radAngle + offsetAngle) * (gap / 2.0f + segmentLength));

        ImVec2 segmentStart2(center.x - cosf(radAngle + offsetAngle) * gap / 2.0f, center.y - sinf(radAngle + offsetAngle) * gap / 2.0f);
        ImVec2 segmentEnd2(center.x - cosf(radAngle + offsetAngle) * (gap / 2.0f + segmentLength), center.y - sinf(radAngle + offsetAngle) * (gap / 2.0f + segmentLength));

        ImGui::GetBackgroundDrawList()->AddLine(segmentStart1, segmentEnd1, color, thickness);
        ImGui::GetBackgroundDrawList()->AddLine(segmentStart2, segmentEnd2, color, thickness);
    }
}




void DrawEsp(int X, int Y, int W, int H) {
    auto draw = ImGui::GetBackgroundDrawList();
    float lineT = 1.0f;
    float outlinatomickness = 2.0f;

    float lineW = (W / 8);
    float lineH = (H / 6);

    if (Variables::rainbowmode) {
        for (int i = 0; i < 8; ++i) {
            ImVec4 color = ImVec4(
                std::sin(0.2f * ImGui::GetTime() + i * 0.3f) * 0.5f + 0.5f,
                std::sin(0.6f * ImGui::GetTime() + i * 0.6f) * 0.5f + 0.5f,
                std::sin(0.3f * ImGui::GetTime() + i * 0.4f) * 0.5f + 0.5f,
                1.0f
            );

            draw->AddLine(ImVec2(X, Y), ImVec2(X, Y + lineH), ImGui::ColorConvertFloat4ToU32(color), lineT);
            draw->AddLine(ImVec2(X, Y), ImVec2(X + lineW, Y), ImGui::ColorConvertFloat4ToU32(color), lineT);
            draw->AddLine(ImVec2(X + W - lineW, Y), ImVec2(X + W, Y), ImGui::ColorConvertFloat4ToU32(color), lineT);
            draw->AddLine(ImVec2(X + W, Y), ImVec2(X + W, Y + lineH), ImGui::ColorConvertFloat4ToU32(color), lineT);
            draw->AddLine(ImVec2(X, Y + H - lineH), ImVec2(X, Y + H), ImGui::ColorConvertFloat4ToU32(color), lineT);
            draw->AddLine(ImVec2(X, Y + H), ImVec2(X + lineW, Y + H), ImGui::ColorConvertFloat4ToU32(color), lineT);
            draw->AddLine(ImVec2(X + W - lineW, Y + H), ImVec2(X + W, Y + H), ImGui::ColorConvertFloat4ToU32(color), lineT);
            draw->AddLine(ImVec2(X + W, Y + H - lineH), ImVec2(X + W, Y + H), ImGui::ColorConvertFloat4ToU32(color), lineT);
        }
    }
    else {
        ImVec4 color = ImVec4(Variables::box_color[0], Variables::box_color[1], Variables::box_color[2], 1.0f);
        ImU32 outlineColor = IM_COL32(0, 0, 0, 255);


        if (Variables::outline) {
            draw->AddLine(ImVec2(X, Y), ImVec2(X, Y + lineH), outlineColor, lineT + outlinatomickness);
            draw->AddLine(ImVec2(X, Y), ImVec2(X + lineW, Y), outlineColor, lineT + outlinatomickness);
            draw->AddLine(ImVec2(X + W - lineW, Y), ImVec2(X + W, Y), outlineColor, lineT + outlinatomickness);
            draw->AddLine(ImVec2(X + W, Y), ImVec2(X + W, Y + lineH), outlineColor, lineT + outlinatomickness);
            draw->AddLine(ImVec2(X, Y + H - lineH), ImVec2(X, Y + H), outlineColor, lineT + outlinatomickness);
            draw->AddLine(ImVec2(X, Y + H), ImVec2(X + lineW, Y + H), outlineColor, lineT + outlinatomickness);
            draw->AddLine(ImVec2(X + W - lineW, Y + H), ImVec2(X + W, Y + H), outlineColor, lineT + outlinatomickness);
            draw->AddLine(ImVec2(X + W, Y + H - lineH), ImVec2(X + W, Y + H), outlineColor, lineT + outlinatomickness);

        }



        draw->AddLine(ImVec2(X, Y), ImVec2(X, Y + lineH), ImGui::ColorConvertFloat4ToU32(color), lineT);
        draw->AddLine(ImVec2(X, Y), ImVec2(X + lineW, Y), ImGui::ColorConvertFloat4ToU32(color), lineT);
        draw->AddLine(ImVec2(X + W - lineW, Y), ImVec2(X + W, Y), ImGui::ColorConvertFloat4ToU32(color), lineT);
        draw->AddLine(ImVec2(X + W, Y), ImVec2(X + W, Y + lineH), ImGui::ColorConvertFloat4ToU32(color), lineT);
        draw->AddLine(ImVec2(X, Y + H - lineH), ImVec2(X, Y + H), ImGui::ColorConvertFloat4ToU32(color), lineT);
        draw->AddLine(ImVec2(X, Y + H), ImVec2(X + lineW, Y + H), ImGui::ColorConvertFloat4ToU32(color), lineT);
        draw->AddLine(ImVec2(X + W - lineW, Y + H), ImVec2(X + W, Y + H), ImGui::ColorConvertFloat4ToU32(color), lineT);
        draw->AddLine(ImVec2(X + W, Y + H - lineH), ImVec2(X + W, Y + H), ImGui::ColorConvertFloat4ToU32(color), lineT);
    }
}


void DrawDistance(ImDrawList* drawList, ImVec2 pos, const std::string& text, ImU32 color) {
    drawList->AddText(pos, color, text.c_str());
}


void threeDCirlce(const atomic::roblox::vector3_t& position, float baseRadius, int segments, float thickness) {
    auto dimensions = Variables::visualengine.get_dimensions();
    auto viewmatrix = Variables::visualengine.get_view_matrix();
    auto drawList = ImGui::GetBackgroundDrawList();
    float currentTime = ImGui::GetTime();

    float radius = baseRadius * 1.5f;

    float pulsingRadius = radius + sin(currentTime) * 0.2f * radius;

    for (int i = 0; i <= segments; i++) {
        float hue = fmod(currentTime * 0.1f + (float)i / segments, 1.0f);
        ImVec4 color = ImColor::HSV(hue, 1.0f, 1.0f, 1.0f);

        float theta = 2.0f * M_PI * i / segments;
        float nextTheta = 2.0f * M_PI * (i + 1) / segments;

        atomic::roblox::vector3_t pointOnCircle = {
            position.x + pulsingRadius * cos(theta),
            position.y,
            position.z + pulsingRadius * sin(theta)
        };
        atomic::roblox::vector3_t nextPointOnCircle = {
            position.x + pulsingRadius * cos(nextTheta),
            position.y,
            position.z + pulsingRadius * sin(nextTheta)
        };

        auto screenPoint = atomic::roblox::world_to_screen(pointOnCircle, dimensions, viewmatrix);
        auto nextScreenPoint = atomic::roblox::world_to_screen(nextPointOnCircle, dimensions, viewmatrix);

        if (screenPoint.x != -1 && screenPoint.y != -1 && nextScreenPoint.x != -1 && nextScreenPoint.y != -1) {
            drawList->AddLine(ImVec2(screenPoint.x, screenPoint.y), ImVec2(nextScreenPoint.x, nextScreenPoint.y), ImGui::ColorConvertFloat4ToU32(color), thickness);
        }
    }

    float fillOpacity = 0.6f;
    for (float r = pulsingRadius; r > 0; r -= pulsingRadius / 15) {
        float fillHue = fmod(currentTime * 0.1f, 1.0f);
        ImVec4 fillColor = ImColor::HSV(fillHue, 0.5f, 1.0f, fillOpacity);

        for (int i = 0; i <= segments; i++) {
            float theta = 2.0f * M_PI * i / segments;
            float nextTheta = 2.0f * M_PI * (i + 1) / segments;

            atomic::roblox::vector3_t pointOnCircle = {
                position.x + r * cos(theta),
                position.y,
                position.z + r * sin(theta)
            };
            atomic::roblox::vector3_t nextPointOnCircle = {
                position.x + r * cos(nextTheta),
                position.y,
                position.z + r * sin(nextTheta)
            };

            auto screenPoint = atomic::roblox::world_to_screen(pointOnCircle, dimensions, viewmatrix);
            auto nextScreenPoint = atomic::roblox::world_to_screen(nextPointOnCircle, dimensions, viewmatrix);

            if (screenPoint.x != -1 && screenPoint.y != -1 && nextScreenPoint.x != -1 && nextScreenPoint.y != -1) {
                drawList->AddLine(ImVec2(screenPoint.x, screenPoint.y), ImVec2(nextScreenPoint.x, nextScreenPoint.y), ImGui::ColorConvertFloat4ToU32(fillColor), thickness);
            }
        }
        fillOpacity *= 0.95f;
    }
}

void Anim_circle(float r, bool filled, bool rainbow, bool toMouse, int sides) {
    auto& io = ImGui::GetIO();

    POINT cursor_pos;
    GetCursorPos(&cursor_pos);
    ScreenToClient(FindWindowA(0, "Roblox"), &cursor_pos);
    ImVec2 center = toMouse ? ImVec2(cursor_pos.x, cursor_pos.y) : ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f);
    auto drawList = ImGui::GetBackgroundDrawList();

    for (int i = 0; i < sides; ++i) {
        auto pos = center;
        float angle = (i / static_cast<float>(sides)) * 2 * M_PI;
        auto lastPos = ImVec2(pos.x + cos(angle) * r, pos.y + sin(angle) * r);
        auto nextPos = ImVec2(pos.x + cos(angle + 2 * M_PI / sides) * r, pos.y + sin(angle + 2 * M_PI / sides) * r);

        ImU32 currentColor = rainbow ? ImGui::ColorConvertFloat4ToU32(ImColor::HSV((fmod(ImGui::GetTime(), 5.0f) / 5.0f - i / static_cast<float>(sides)) + 1.0f, 0.5f, 1.0f)) : IM_COL32(255, 255, 255, 255);

        ImU32 fillCol = filled ? ImGui::ColorConvertFloat4ToU32({ ImGui::ColorConvertU32ToFloat4(currentColor).x, ImGui::ColorConvertU32ToFloat4(currentColor).y, ImGui::ColorConvertU32ToFloat4(currentColor).z, 0.2f }) : 0;

        if (filled) {
            ImVec2 triangle[3] = { lastPos, nextPos, center };
            drawList->AddConvexPolyFilled(triangle, 3, fillCol);
        }

        drawList->AddLine(lastPos, nextPos, IM_COL32(0, 0, 0, 255), 4.f);
        drawList->AddLine(lastPos, nextPos, currentColor, 2.f);
    }
}



void RenderatomicwingText(const char* text, const ImVec4& color, float atomicwSize, ImVec2 position, ImDrawList* drawList) {
    ImVec2 drawPos = position;

    drawList->AddText(drawPos, ImGui::ColorConvertFloat4ToU32(color), text);
    for (float i = 0; i < 360; i += 45) {
        float dx = cosf(i) * atomicwSize;
        float dy = sinf(i) * atomicwSize;
        drawList->AddText(drawPos + ImVec2(dx, dy), IM_COL32_BLACK_TRANS, text);
    }

    drawList->AddText(drawPos, ImGui::ColorConvertFloat4ToU32(color), text);
}


ImU32 RainbowColor(float time, float offset, int alpha) {
    const float rainbow_speed = 0.5f;
    float hue = fmodf(time * rainbow_speed + offset, 1.0f);
    ImVec4 color;
    ImGui::ColorConvertHSVtoRGB(hue, 1.0f, 1.0f, color.x, color.y, color.z);
    return IM_COL32(int(color.x * 255), int(color.y * 255), int(color.z * 255), alpha);
}


ImVec4 color = ImVec4(Variables::box_color[0], Variables::box_color[1], Variables::box_color[2], 1.0f);

void atomic::roblox::hook_esp()
{



    auto players = Variables::players;
    roblox::instance_t localplayer = players.get_local_player();
    roblox::instance_t localplayer_team = localplayer.get_team();
    auto saved_character = Variables::saved_player;
    auto draw = ImGui::GetBackgroundDrawList();

    POINT cursor_pos;
    GetCursorPos(&cursor_pos);
    ScreenToClient(FindWindowA(0, "Roblox"), &cursor_pos);

    //atomic::roblox::vector3_t camerapos = Variables::visualengine.get_camera_pos();


    if (Variables::crosshair) {

        crosshair();

    }

    if (Variables::radar) {

        DrawRadar();
    }



    if (Variables::fov_on) {

        POINT cursor_pos;
        GetCursorPos(&cursor_pos);
        ScreenToClient(FindWindowA(0, "Roblox"), &cursor_pos);
        ImVec2 center = ImVec2(cursor_pos.x, cursor_pos.y);






        if (Variables::fovtype == 0) {
            ImColor black_outline_color(0, 0, 0);
            ImVec4 color = ImVec4(Variables::fov_color[0], Variables::fov_color[1], Variables::fov_color[2], 1.0f);
            ImVec4 fovfill_color = ImVec4(Variables::fov_fill_color[0], Variables::fov_fill_color[1], Variables::fov_fill_color[2], 0.4f);




            static float sonar_radius = Variables::fov * 0.5;
            static float sonar_opacity = 1.0f;

            sonar_radius += Variables::sonar_expansion_rate;

            sonar_opacity = 1.0f - (sonar_radius - Variables::fov * 0.5) / (Variables::fov - Variables::fov * 0.5);

            if (sonar_radius >= Variables::fov) {
                sonar_radius = Variables::fov * 0.5;
                sonar_opacity = 1.0f;
            }

            ImVec4 sonar_color = ImVec4(Variables::fov_color[0], Variables::fov_color[1], Variables::fov_color[2], sonar_opacity);
            draw->AddCircle(center, sonar_radius, ImGui::ColorConvertFloat4ToU32(sonar_color), 12, 1.0f);
            //draw->AddCircle(center, Variables::fov, ImGui::ColorConvertFloat4ToU32(color), 12, 1.0f);
            draw->AddCircle(center, Variables::fov + 1.0f, black_outline_color, 12, 1.0f);
            draw->AddCircle(center, Variables::fov - 1.0f, black_outline_color, 12, 1.0f);
            //if (Variables::sonar) {

            //}

            if (Variables::fov_filled) {
                draw->AddCircleFilled(center, Variables::fov - 1.5f, ImGui::ColorConvertFloat4ToU32(fovfill_color), 64);
            }
        }
        else if (Variables::fovtype == 1) {

            Anim_circle(Variables::fov + 1.0f, Variables::rainbowfovfilled, true, true, 64);
        }
    }


    float currentTime = ImGui::GetTime();


    if (Variables::show_deadzone)
    {
        ImColor fill_color(0, 0, 0, 51);
        ImColor black_outline_color(0, 0, 0);

        ImVec4 color = ImVec4(Variables::deadzone_color[0], Variables::deadzone_color[1], Variables::deadzone_color[2], 1.0f);

        ImVec4 colors = ImVec4(Variables::deadzone_fill_color[0], Variables::deadzone_fill_color[1], Variables::deadzone_fill_color[2], 0.4f);

        draw->AddCircle(ImVec2(cursor_pos.x, cursor_pos.y), Variables::deadzone_value + 1.0f, black_outline_color, 64, 1.0f);
        draw->AddCircle(ImVec2(cursor_pos.x, cursor_pos.y), Variables::deadzone_value, ImGui::ColorConvertFloat4ToU32(color), 64, 1.0f);
        draw->AddCircle(ImVec2(cursor_pos.x, cursor_pos.y), Variables::deadzone_value - 1.0f, black_outline_color, 64, 1.0f);
        if (Variables::deadzone_fov_filled) {
            draw->AddCircleFilled(ImVec2(cursor_pos.x, cursor_pos.y), Variables::fov - 1.5f, ImGui::ColorConvertFloat4ToU32(colors), 64);
        }
    }




    //if (Variables::visualisetarget && !Variables::esp) {

    //    auto dimensions = Variables::visualengine.get_dimensions();
    //    auto viewmatrix = Variables::visualengine.get_view_matrix();

    //    auto character = Variables::saved_player.get_model_instance();
    //    if (character.self)
    //    {
    //        auto humanoid = character.find_first_child("Humanoid");
    //        auto head = character.find_first_child("Head");

    //        if (humanoid.self && head.self)
    //        {
    //            auto head_position_3d = head.get_part_pos();
    //            auto camerapos = Variables::visualengine.get_camera_pos();

    //            auto head_position = atomic::roblox::world_to_screen(vector_sub(head_position_3d, { 0, 2, 0 }), dimensions, viewmatrix);
    //            auto leg_pos = atomic::roblox::world_to_screen(vector_sub(head_position_3d, { 0, 5, 0 }), dimensions, viewmatrix);

    //            auto hrp_pos = humanoid.get_part_pos();
    //            auto headPosY = static_cast<float>(hrp_pos.y + 2.5);
    //            auto legPosY = static_cast<float>(hrp_pos.y - 3.5);
    //            auto top = atomic::roblox::world_to_screen({ static_cast<float>(hrp_pos.x), headPosY, static_cast<float>(hrp_pos.z) }, dimensions, viewmatrix);
    //            auto bottom = atomic::roblox::world_to_screen({ static_cast<float>(hrp_pos.x), legPosY, static_cast<float>(hrp_pos.z) }, dimensions, viewmatrix);

    //            if (leg_pos.x != -1)
    //            {
    //                float height = head_position.y - leg_pos.y;
    //                float width = height / 1.6f;


    //                if (Variables::visualisetarget && Variables::box)
    //                {
    //                    ImVec4 color = ImVec4(Variables::box_color[0], Variables::box_color[1], Variables::box_color[2], 1.0f);

    //                    float outline_offset = 0.1f;

    //                    ImVec4 fill_color = ImVec4(Variables::fill_color[0], Variables::fill_color[1], Variables::fill_color[2], 0.3f);
    //                    ImColor black_outline_color(0, 0, 0);
    //                    ImColor white_outline_color(255, 255, 255);

    //                    switch (Variables::boxtype)
    //                    {
    //                    case 0:
    //                        if (Variables::filledbox) {
    //                            draw->AddRectFilled(ImVec2(leg_pos.x - (width / 1.3f) - outline_offset, leg_pos.y - outline_offset), ImVec2(head_position.x + width + outline_offset, head_position.y + height + outline_offset), ImGui::ColorConvertFloat4ToU32(fill_color));
    //                        }
    //                        draw->AddRect(ImVec2(leg_pos.x - (width / 1.3f), leg_pos.y), ImVec2(head_position.x + width, head_position.y + height), ImGui::ColorConvertFloat4ToU32(color));
    //                        if (Variables::outline) {
    //                            draw->AddRect(ImVec2(leg_pos.x - (width / 1.3f) - outline_offset - 1.5, leg_pos.y - outline_offset - 1.5), ImVec2(head_position.x + width + outline_offset + 1.5, head_position.y + height + outline_offset + 1.5), black_outline_color);
    //                            draw->AddRect(ImVec2(leg_pos.x - (width / 1.3f) - outline_offset + 1.5, leg_pos.y - outline_offset + 1.5), ImVec2(head_position.x + width + outline_offset - 1.5, head_position.y + height + outline_offset - 1.5), black_outline_color);
    //                        }
    //                        if (Variables::rainbowbox) {
    //                            float rainbow_width = (head_position.x + width + outline_offset) - (leg_pos.x - (width / 1.3f) - outline_offset);
    //                            float rainbow_height = (head_position.y + height + outline_offset) - (leg_pos.y - outline_offset);

    //                            ImU32 col_top_left = IM_COL32(231, 0, 0, 80);
    //                            ImU32 col_top_right = IM_COL32(255, 241, 0, 80);
    //                            ImU32 col_bottom_right = IM_COL32(0, 129, 31, 80);
    //                            ImU32 col_bottom_left = IM_COL32(0, 70, 173, 80);

    //                            draw->AddRectFilledMultiColor(
    //                                ImVec2(leg_pos.x - (width / 1.3f) - outline_offset, leg_pos.y - outline_offset),
    //                                ImVec2(leg_pos.x - (width / 1.3f) - outline_offset + rainbow_width, leg_pos.y - outline_offset + rainbow_height),
    //                                col_top_left,
    //                                col_top_right,
    //                                col_bottom_right,
    //                                col_bottom_left
    //                            );
    //                        }
    //                        break;
    //                    case 1:
    //                        if (Variables::visualisetarget && Variables::filledbox) {
    //                            draw->AddRectFilled(ImVec2(leg_pos.x - (width / 1.3f) - outline_offset, leg_pos.y - outline_offset), ImVec2(head_position.x + width + outline_offset, head_position.y + height + outline_offset), ImGui::ColorConvertFloat4ToU32(fill_color));
    //                        }

    //                        if (Variables::visualisetarget && Variables::rainbowbox) {
    //                            float rainbow_width = (head_position.x + width + outline_offset) - (leg_pos.x - (width / 1.3f) - outline_offset);
    //                            float rainbow_height = (head_position.y + height + outline_offset) - (leg_pos.y - outline_offset);

    //                            ImVec2 rect_min = ImVec2(leg_pos.x - (width / 1.3f) - outline_offset, leg_pos.y - outline_offset);
    //                            ImVec2 rect_max = ImVec2(leg_pos.x - (width / 1.3f) - outline_offset + rainbow_width, leg_pos.y - outline_offset + rainbow_height);

    //                            float time = ImGui::GetTime();
    //                            ImU32 col_top_left = RainbowColor(time, 0.0f, 80);
    //                            ImU32 col_top_right = RainbowColor(time, 0.25f, 80);
    //                            ImU32 col_bottom_right = RainbowColor(time, 0.5f, 80);
    //                            ImU32 col_bottom_left = RainbowColor(time, 0.75f, 80);

    //                            draw->AddRectFilledMultiColor(rect_min, rect_max,
    //                                col_top_left,
    //                                col_top_right,
    //                                col_bottom_right,
    //                                col_bottom_left);
    //                        }

    //                        DrawEsp(leg_pos.x - (width / 1.3f), leg_pos.y, head_position.x + width - leg_pos.x + (width / 1.3f), head_position.y + height - leg_pos.y);
    //                        break;
    //                    }
    //                }






    //                if (Variables::threeCircle) {
    //                    auto character = Variables::saved_player.get_model_instance();
    //                    if (character.self) {
    //                        auto humanoidRootPart = character.find_first_child("HumanoidRootPart");
    //                        if (humanoidRootPart.self) {
    //                            auto basePosition = humanoidRootPart.get_part_pos();

    //                            basePosition.y -= -10.0f;

    //                            threeDCirlce(basePosition, 2.0f, 36, 1.0f);
    //                        }
    //                    }
    //                }


    //                //  DrawEsp(leg_pos.x - (width / 1.3f), leg_pos.y, head_position.x + width - leg_pos.x + (width / 1.3f), head_position.y + height - leg_pos.y);





    //                if (Variables::visualisetarget && Variables::tracers)
    //                {
    //                    ImVec4 color = ImVec4(Variables::tracers_color[0], Variables::tracers_color[1], Variables::tracers_color[2], 1.0f);
    //                    draw->AddLine(ImVec2(head_position.x, head_position.y), ImVec2(static_cast<float>(cursor_pos.x), static_cast<float>(cursor_pos.y)), ImGui::ColorConvertFloat4ToU32(color));
    //                }



    //                if (Variables::visualisetarget && Variables::head_dot) {
    //                    auto head_positionx = atomic::roblox::world_to_screen(head_position_3d, dimensions, viewmatrix);
    //                    ImVec4 dot_color = ImVec4(Variables::head_dot_color[0], Variables::head_dot_color[1], Variables::head_dot_color[2], 1.0f);
    //                    ImVec2 head_dot_pos = ImVec2(head_positionx.x, head_positionx.y);
    //                    float dot_size = 6.0f;

    //                    if (Variables::head_dot_type == 0) {
    //                        draw->AddCircle(head_dot_pos, dot_size, ImGui::ColorConvertFloat4ToU32(dot_color), 16);
    //                    }
    //                    if (Variables::head_dot_type == 1) {
    //                        dot_color.w = 0.5f;
    //                        draw->AddCircleFilled(head_dot_pos, dot_size, ImGui::ColorConvertFloat4ToU32(dot_color), 16);
    //                    }
    //                }



    //                if (Variables::name_esp)
    //                {
    //                    std::string playerName = Variables::saved_player.name();

    //                    auto character = Variables::saved_player.get_model_instance();
    //                    auto humanoid = character.find_first_child("Humanoid");
    //                    if (humanoid.self)
    //                    {
    //                        auto head = character.find_first_child("Head");
    //                        if (head.self)
    //                        {
    //                            auto head_pos = atomic::roblox::world_to_screen(head.get_part_pos(), dimensions, viewmatrix);

    //                            ImVec2 namePos = ImVec2(head_pos.x - ImGui::CalcTextSize(playerName.c_str()).x / 2, head_pos.y - 20);

    //                            draw->AddText(namePos + ImVec2(-1, -1), ImColor(0, 0, 0, 255), playerName.c_str());
    //                            draw->AddText(namePos + ImVec2(1, -1), ImColor(0, 0, 0, 255), playerName.c_str());
    //                            draw->AddText(namePos + ImVec2(-1, 1), ImColor(0, 0, 0, 255), playerName.c_str());
    //                            draw->AddText(namePos + ImVec2(1, 1), ImColor(0, 0, 0, 255), playerName.c_str());

    //                            ImVec4 color(Variables::name_color[0], Variables::name_color[1], Variables::name_color[2], 1.0f);
    //                            draw->AddText(namePos, ImGui::ColorConvertFloat4ToU32(color), playerName.c_str());
    //                        }
    //                    }
    //                }


    //                auto localplayer = Variables::players.get_local_player();

    //                auto local_character = localplayer.get_model_instance();
    //                auto local_hrp = local_character.find_first_child("HumanoidRootPart");
    //                atomic::roblox::vector3_t player_pos = local_hrp.get_part_pos();

    //                float dist_from_plr = calc_dist_vec3_op(player_pos, hrp_pos);


    //                if (Variables::visualisetarget && Variables::distance_esp) {

    //                    std::string distanceText = std::to_string(static_cast<int>(dist_from_plr)) + "m";
    //                    DrawDistance(draw, ImVec2(bottom.x - width / 2, bottom.y + 20), distanceText, IM_COL32_WHITE);

    //                }

    //                auto distance_position = atomic::roblox::world_to_screen(vector_sub(head_position_3d, { -0.25, 5.3, 0 }), dimensions, viewmatrix);


    //                if (Variables::visualisetarget && Variables::healthinfo)
    //                {
    //                    float health = humanoid.get_health();
    //                    int healthPercentage = static_cast<int>((health / humanoid.get_max_health()) * 100);

    //                    ImVec4 healthColor;

    //                    if (healthPercentage <= 100)
    //                        healthColor = ImColor(66, 245, 164);
    //                    else if (healthPercentage <= 90)
    //                        healthColor = ImColor(66, 245, 111);
    //                    else if (healthPercentage <= 70)
    //                        healthColor = ImColor(239, 245, 66);
    //                    else if (healthPercentage <= 60)
    //                        healthColor = ImColor(245, 215, 66);
    //                    else if (healthPercentage <= 50)
    //                        healthColor = ImColor(245, 176, 66);
    //                    else if (healthPercentage <= 40)
    //                        healthColor = ImColor(245, 150, 66);
    //                    else if (healthPercentage <= 30)
    //                        healthColor = ImColor(245, 123, 66);
    //                    else if (healthPercentage <= 20)
    //                        healthColor = ImColor(245, 102, 66);
    //                    else if (healthPercentage <= 10)
    //                        healthColor = ImColor(245, 66, 66);

    //                    std::string text = std::to_string(healthPercentage) + "%";

    //                    draw->AddText(ImVec2(head_position.x - width / 2, head_position.y + height + 2) + ImVec2(-1, -1), ImColor(0, 0, 0), text.c_str());
    //                    draw->AddText(ImVec2(head_position.x - width / 2, head_position.y + height + 2) + ImVec2(1, -1), ImColor(0, 0, 0), text.c_str());
    //                    draw->AddText(ImVec2(head_position.x - width / 2, head_position.y + height + 2) + ImVec2(-1, 1), ImColor(0, 0, 0), text.c_str());
    //                    draw->AddText(ImVec2(head_position.x - width / 2, head_position.y + height + 2) + ImVec2(1, 1), ImColor(0, 0, 0), text.c_str());

    //                    draw->AddText(ImVec2(head_position.x - width / 2, head_position.y + height + 2), (ImColor)healthColor, text.c_str());
    //                }
    //            }
    //        }
    //    }
    //}





    if (Variables::esp && !Variables::visualisetarget)
    {



        auto dimensions = Variables::visualengine.get_dimensions();
        auto viewmatrix = Variables::visualengine.get_view_matrix();
        auto localplayer = Variables::LocalPlayer;
        //    auto PlayerList2 = atomic::roblox::sdk::Players;

        //    for (const auto& playerPair : PlayerList2) {
        {
            for (auto& player : playerList) {

                //       auto player2 = playerPair.first;
                 //      auto bodyParts = playerPair.second;

                    //   auto humanoidrootpart = atomic::roblox::sdk::Find(bodyParts, "HumanoidRootPart");
                    //   if (!humanoidrootpart.self)
                        //   continue;

                    //   auto humanoid = atomic::roblox::sdk::Find(bodyParts, "Humanoid");
                    //   if (!humanoid.self)
                     //      continue;

                   ////   auto head = atomic::roblox::sdk::Find(bodyParts, "Head");
                    //   if (!head.self)
                     //      continue;

                auto humanoidrootpart = player.hrpInstance;
                auto head = player.headInstance;
                auto humanoid = player.humanoidInstance;

                atomic::roblox::vector3_t hrp_pos = humanoidrootpart.get_part_pos();
                atomic::roblox::vector3_t head_pos = head.get_part_pos();
                //    float headPosY = static_cast<float>(hrp_pos.y + 2.5);
                  //  float legPosY = static_cast<float>(hrp_pos.y - 3.5);


                atomic::roblox::matrix3_t humanoidRootPart_rotation_matrix = humanoidrootpart.get_part_rotation();
                atomic::roblox::vector3_t humanoidRootPart_rotation = { -humanoidRootPart_rotation_matrix.data[2] / 100, -humanoidRootPart_rotation_matrix.data[5] / 100, -humanoidRootPart_rotation_matrix.data[8] / 100 };
                atomic::roblox::vector3_t look_position_3D = vector_add(hrp_pos, humanoidRootPart_rotation);
                atomic::roblox::vector3_t look_direction = normalize(humanoidRootPart_rotation);
                atomic::roblox::vector3_t side_vector1 = crossProduct({ 0.0f, 1.0f, 0.0f }, look_direction);
                atomic::roblox::vector3_t side_vector2 = crossProduct(look_direction, side_vector1);


                player.hrpPos2d = roblox::world_to_screen(hrp_pos, dimensions, viewmatrix);
                atomic::roblox::vector2_t legPos = roblox::world_to_screen(vector_sub(hrp_pos, { 0.0f, 3.0f, 0.0f }), dimensions, viewmatrix);
                auto leg_pos = atomic::roblox::world_to_screen(vector_sub(hrp_pos, { 0, 5, 0 }), dimensions, viewmatrix);

                atomic::roblox::vector2_t headPos = roblox::world_to_screen(vector_add(hrp_pos, { 0.0f, 1.5f, 0.0f }), dimensions, viewmatrix);
                float headPosY = static_cast<float>(hrp_pos.y + 2.5);
                float legPosY = static_cast<float>(hrp_pos.y - 3.5);
                atomic::roblox::vector2_t top = roblox::world_to_screen({ static_cast<float>(hrp_pos.x), headPosY, static_cast<float>(hrp_pos.z) }, dimensions, viewmatrix);
                atomic::roblox::vector2_t bottom = roblox::world_to_screen({ static_cast<float>(hrp_pos.x), legPosY, static_cast<float>(hrp_pos.z) }, dimensions, viewmatrix);
                float height = (headPos.y - legPos.y) / 2.4;
                float width = height / 1.6f;

                float dynamicheight = 5.3f;
                float dynamicwidth = 2.9f;
                if (height < -70 or height > 50)
                    continue;

                ;

                if (hrp_pos.x == 0 && hrp_pos.y == 0 && hrp_pos.z == 0)
                    continue;

                if (hrp_pos.x == getLocalPlayerPosition().x && hrp_pos.y == getLocalPlayerPosition().y && hrp_pos.z == getLocalPlayerPosition().z && !Variables::local_box)
                    continue;

                auto team = player.playerInstance.get_team();
                if (Variables::team_check && (team.self == localplayer.get_team().self))
                    continue;



                if (Variables::tracers)
                {
                    ImVec4 color = ImVec4(Variables::tracers_color[0], Variables::tracers_color[1], Variables::tracers_color[2], 1.0f);
                    draw->AddLine(ImVec2(headPos.x, headPos.y), ImVec2(static_cast<float>(cursor_pos.x), static_cast<float>(cursor_pos.y)), ImGui::ColorConvertFloat4ToU32(color));
                }
                if (Variables::skeleton)
                {
                    ImVec4 skeletonColor = ImVec4(Variables::skeleton_color[0], Variables::skeleton_color[1], Variables::skeleton_color[2], 1.0f);
                    float skeletonThickness = 0.5f;

                    auto head_pos = world_to_screen2(head.get_part_pos(), dimensions, viewmatrix);
                    auto spine_top = humanoidrootpart;
                    auto torso_pos = world_to_screen2(spine_top.get_part_pos(), dimensions, viewmatrix);
                    auto left_shoulder = player.leftupperarm;
                    auto right_shoulder = player.rightupperarm;
                    auto left_elbow = player.leftelbow;
                    auto right_elbow = player.rightelbow;
                    auto left_hand = player.lefthand;
                    auto right_hand = player.righthand;
                    auto left_leg = player.leftleg;
                    auto right_leg = player.rightleg;

                    // if (character.Get_Name() == "Torso") continue; // doesnt work

                    auto leftArm_pos = world_to_screen2(left_shoulder.get_part_pos(), dimensions, viewmatrix);
                    auto rightArm_pos = world_to_screen2(right_shoulder.get_part_pos(), dimensions, viewmatrix);
                    auto leftElbow_pos = world_to_screen2(left_elbow.get_part_pos(), dimensions, viewmatrix);
                    auto rightElbow_pos = world_to_screen2(right_elbow.get_part_pos(), dimensions, viewmatrix);
                    auto leftHand_pos = world_to_screen2(left_hand.get_part_pos(), dimensions, viewmatrix);
                    auto rightHand_pos = world_to_screen2(right_hand.get_part_pos(), dimensions, viewmatrix);
                    auto leftLeg_pos = world_to_screen2(left_leg.get_part_pos(), dimensions, viewmatrix);
                    auto rightLeg_pos = world_to_screen2(right_leg.get_part_pos(), dimensions, viewmatrix);

                    if (!head.self || !spine_top.self || !left_shoulder.self || !right_shoulder.self || !left_elbow.self || !right_elbow.self || !left_hand.self || !right_hand.self || !left_leg.self || !right_leg.self)
                    {
                        continue;
                    }

                    if (right_leg.self) {
                        if (left_leg.self) {
                            if (spine_top.self) {
                                if (left_shoulder.self) {
                                    // torso to limbs
                                    draw->AddLine(ImVec2(torso_pos.x, torso_pos.y), ImVec2(leftLeg_pos.x, leftLeg_pos.y), ImGui::ColorConvertFloat4ToU32(skeletonColor), skeletonThickness);
                                    draw->AddLine(ImVec2(torso_pos.x, torso_pos.y), ImVec2(rightLeg_pos.x, rightLeg_pos.y), ImGui::ColorConvertFloat4ToU32(skeletonColor), skeletonThickness);
                                    draw->AddLine(ImVec2(torso_pos.x, torso_pos.y), ImVec2(leftArm_pos.x, leftArm_pos.y), ImGui::ColorConvertFloat4ToU32(skeletonColor), skeletonThickness);
                                    draw->AddLine(ImVec2(torso_pos.x, torso_pos.y), ImVec2(rightArm_pos.x, rightArm_pos.y), ImGui::ColorConvertFloat4ToU32(skeletonColor), skeletonThickness);
                                    draw->AddLine(ImVec2(leftArm_pos.x, leftArm_pos.y), ImVec2(leftElbow_pos.x, leftElbow_pos.y), ImGui::ColorConvertFloat4ToU32(skeletonColor), skeletonThickness);
                                    draw->AddLine(ImVec2(leftElbow_pos.x, leftElbow_pos.y), ImVec2(leftHand_pos.x, leftHand_pos.y), ImGui::ColorConvertFloat4ToU32(skeletonColor), skeletonThickness);
                                    draw->AddLine(ImVec2(rightArm_pos.x, rightArm_pos.y), ImVec2(rightElbow_pos.x, rightElbow_pos.y), ImGui::ColorConvertFloat4ToU32(skeletonColor), skeletonThickness);
                                    draw->AddLine(ImVec2(rightElbow_pos.x, rightElbow_pos.y), ImVec2(rightHand_pos.x, rightHand_pos.y), ImGui::ColorConvertFloat4ToU32(skeletonColor), skeletonThickness);
                                    // torso to head
                                    draw->AddLine(ImVec2(torso_pos.x, torso_pos.y), ImVec2(head_pos.x, head_pos.y), ImGui::ColorConvertFloat4ToU32(skeletonColor), skeletonThickness);
                                }
                            }
                        }
                    }
                }

                if (Variables::dotesp)
                {
                    ImVec2 screen_dot_position = ImVec2(headPos.x, headPos.y);

                    ImVec4 color = ImVec4(Variables::dot_color[0], Variables::dot_color[1], Variables::dot_color[2], 1.0f);

                    float dot_radius = 8.7f; // Change dot radius to make it bigger or smaller

                    draw->AddCircleFilled(screen_dot_position, dot_radius, ImGui::ColorConvertFloat4ToU32(color), 32);
                }

                if (Variables::healthbar)
                {

                    float health = humanoid.get_health();
                    int healthPercentage = static_cast<int>((health / humanoid.get_max_health()) * 100);


                    ImVec2 barPos = ImVec2(legPos.x - width * 1.0f, legPos.y);
                    ImVec2 barSize = ImVec2(4, height * 3);

                    draw->AddRectFilled(barPos, ImVec2(barPos.x + barSize.x, barPos.y + barSize.y), ImColor(0, 0, 0, 150));

                    float healthBarHeight = (static_cast<float>(healthPercentage) / 100) * (barSize.y - 2);

                    ImVec4 healthColor;

                    if (healthPercentage <= 100)
                        healthColor = ImColor(66, 245, 164);

                    if (healthPercentage <= 90)
                        healthColor = ImColor(66, 245, 111);

                    if (healthPercentage <= 70)
                        healthColor = ImColor(239, 245, 66);

                    if (healthPercentage <= 60)
                        healthColor = ImColor(245, 215, 66);

                    if (healthPercentage <= 50)
                        healthColor = ImColor(245, 176, 66);

                    if (healthPercentage <= 40)
                        healthColor = ImColor(245, 150, 66);

                    if (healthPercentage <= 30)
                        healthColor = ImColor(245, 123, 66);

                    if (healthPercentage <= 20)
                        healthColor = ImColor(245, 102, 66);

                    if (healthPercentage <= 10)
                        healthColor = ImColor(245, 66, 66);

                    draw->AddRectFilled(barPos + ImVec2(1, 1), ImVec2(barPos.x + barSize.x - 1, barPos.y + healthBarHeight), (ImColor)healthColor);
                }

                if (Variables::threeCircle) {
                    auto character = player.modelinstance;
                    if (character.self) {
                        auto humanoidRootPart = player.hrpInstance;
                        if (humanoidRootPart.self) {
                            auto basePosition = humanoidRootPart.get_part_pos();

                            basePosition.y -= Variables::y_axis;

                            threeDCirlce(basePosition, 2.0f, 36, 1.0f);
                        }
                    }
                }

                if (Variables::esp && Variables::healthinfo)
                {
                    float health = player.humanoid.get_health();
                    int healthPercentage = static_cast<int>((health / player.humanoid.get_max_health()) * 100);

                    ImVec4 healthColor;

                    if (healthPercentage <= 100)
                        healthColor = ImColor(66, 245, 164);
                    else if (healthPercentage <= 90)
                        healthColor = ImColor(66, 245, 111);
                    else if (healthPercentage <= 70)
                        healthColor = ImColor(239, 245, 66);
                    else if (healthPercentage <= 60)
                        healthColor = ImColor(245, 215, 66);
                    else if (healthPercentage <= 50)
                        healthColor = ImColor(245, 176, 66);
                    else if (healthPercentage <= 40)
                        healthColor = ImColor(245, 150, 66);
                    else if (healthPercentage <= 30)
                        healthColor = ImColor(245, 123, 66);
                    else if (healthPercentage <= 20)
                        healthColor = ImColor(245, 102, 66);
                    else if (healthPercentage <= 10)
                        healthColor = ImColor(245, 66, 66);

                    std::string text = std::to_string(healthPercentage) + "%";

                    draw->AddText(ImVec2(headPos.x - width / 2, headPos.y + height + 2) + ImVec2(-1, -1), ImColor(0, 0, 0), text.c_str());
                    draw->AddText(ImVec2(headPos.x - width / 2, headPos.y + height + 2) + ImVec2(1, -1), ImColor(0, 0, 0), text.c_str());
                    draw->AddText(ImVec2(headPos.x - width / 2, headPos.y + height + 2) + ImVec2(-1, 1), ImColor(0, 0, 0), text.c_str());
                    draw->AddText(ImVec2(headPos.x - width / 2, headPos.y + height + 2) + ImVec2(1, 1), ImColor(0, 0, 0), text.c_str());

                    draw->AddText(ImVec2(headPos.x - width / 2, headPos.y + height + 2), (ImColor)healthColor, text.c_str());
                }

                //// chams (thanks placeid)

                //auto viewmatrix = Variables::visualengine.get_view_matrix();
                //auto dimensions = Variables::visualengine.get_dimensions();


                //if (Variables::chams) {
                //    static const std::vector<std::string> BodyParts = {
                //        "Head", "Humanoid", "UpperTorso", "LowerTorso", "HumanoidRootPart",
                //        "LeftUpperArm", "LeftLowerArm", "LeftHand",
                //        "RightUpperArm", "RightLowerArm", "RightHand",
                //        "LeftUpperLeg", "LeftLowerLeg", "LeftFoot",
                //        "RightUpperLeg", "RightLowerLeg", "RightFoot",
                //        "Torso", "Left Arm", "Right Arm",
                //        "Right Leg"
                //    };

                //    ImU32 color = ImGui::ColorConvertFloat4ToU32(ImVec4(1.f, 1.f, 1.f, 1.f)); // White color with full opacity

                //    auto draw_list = ImGui::GetBackgroundDrawList();

                //    // Obtain camera position
                //    atomic::roblox::instance_t camera = Variables::workspace.find_first_child("Camera");
                //    atomic::roblox::vector3_t CameraPosition = camera.get_camera_pos();

                //    auto vectorLength = [](const atomic::roblox::vector3_t& vec) -> float {
                //        return std::sqrt(vec.x * vec.x + vec.y * vec.y + vec.z * vec.z);
                //        };

                //    for (const auto& part : BodyParts) {
                //        auto part_ptr = atomic::roblox::sdk::Find(bodyParts, part);
                //        if (part_ptr.self) {
                //            vector3_t PartPos = part_ptr.get_part_pos();
                //            vector2_t ScreenPos = atomic::roblox::world_to_screen(PartPos, dimensions, viewmatrix);

                //            if (ScreenPos.x != -1 && ScreenPos.y != -1) {
                //                // Calculate distance from camera to part
                //                float distance = vectorLength(CameraPosition - PartPos);

                //                // Define the size of the 2D box around the body part based on distance
                //                float box_size = 320.0f / distance; // Adjust 500.0f as needed for scaling

                //                // Calculate box corners
                //                ImVec2 top_left = ImVec2(ScreenPos.x - box_size, ScreenPos.y - box_size);
                //                ImVec2 bottom_right = ImVec2(ScreenPos.x + box_size, ScreenPos.y + box_size);

                //                // Draw filled rectangle with white color
                //                draw_list->AddRect(top_left, bottom_right, color);
                //            }
                //        }
                //    }
                //}

            /*    if (Variables::skeleton)
                {
                    std::vector<std::string> body_parts = {
                        "Head",
                        "UpperTorso", "LowerTorso", "HumanoidRootPart",
                        "LeftUpperArm", "LeftLowerArm", "LeftHand",
                        "RightUpperArm", "RightLowerArm", "RightHand",
                        "LeftUpperLeg", "LeftLowerLeg", "LeftFoot",
                        "RightUpperLeg", "RightLowerLeg", "RightFoot",
                        "Torso", "Left Arm", "Right Arm",
                        "Right Leg"
                    };

                    std::unordered_map<std::string, vector3_t> part_positions;
                    for (const auto& part : body_parts) {
                        auto part_ptr = atomic::roblox::sdk::Find(bodyParts, part);
                        if (part_ptr.self) {
                            part_positions[part] = part_ptr.get_part_pos();
                        }
                    }

                    auto Head = atomic::roblox::world_to_screen(head_pos, dimensions, viewmatrix);

                    std::unordered_map<std::string, vector2_t> screen_positions;
                    for (const auto& [part_name, part_pos] : part_positions) {
                        screen_positions[part_name] = atomic::roblox::world_to_screen(part_pos, dimensions, viewmatrix);
                    }

                    ImU32 color = ImGui::ColorConvertFloat4ToU32(ImVec4(Variables::skeleton_color[0], Variables::skeleton_color[1], Variables::skeleton_color[2], 1.f));
                    float thickness = Variables::skeleton_thickness;

                    std::vector<std::pair<std::string, std::string>> skeleton_structure = {
                        {"Head", "UpperTorso"},
                        {"UpperTorso", "LeftUpperArm"},
                        {"LeftUpperArm", "LeftLowerArm"},
                        {"LeftLowerArm", "LeftHand"},
                        {"UpperTorso", "RightUpperArm"},
                        {"RightUpperArm", "RightLowerArm"},
                        {"RightLowerArm", "RightHand"},
                        {"UpperTorso", "HumanoidRootPart"},
                        {"HumanoidRootPart", "LowerTorso"},
                        {"LowerTorso", "LeftUpperLeg"},
                        {"LeftUpperLeg", "LeftLowerLeg"},
                        {"LeftLowerLeg", "LeftFoot"},
                        {"LowerTorso", "RightUpperLeg"},
                        {"RightUpperLeg", "RightLowerLeg"},
                        {"RightLowerLeg", "RightFoot"}
                    };

                    for (const auto& [part1, part2] : skeleton_structure) {
                        if (screen_positions.find(part1) != screen_positions.end() && screen_positions.find(part2) != screen_positions.end()) {
                            draw->AddLine(V2Convert(screen_positions[part1]), V2Convert(screen_positions[part2]), color, thickness);
                        }
                    }
                }*/

                if (Variables::box) {
                    if (Variables::boxtype == 0) {
                        ImVec4 boxColor = ImVec4(Variables::box_color[0], Variables::box_color[1], Variables::box_color[2], 1.0f);
                        ImU32 boxColorU32 = ImGui::GetColorU32(boxColor);
                        ImColor black_outline_colorr(0, 0, 0);

                        draw->AddRect(ImVec2(legPos.x - (width / 1.3f), legPos.y), ImVec2(player.hrpPos2d.x + width, player.hrpPos2d.y + height), ImGui::ColorConvertFloat4ToU32(boxColor));

                        //draw->AddRect(ImVec2(legPos.x - (width / 1.2f), legPos.y), ImVec2(player.hrpPos2d.x + width, player.hrpPos2d.y + height), ImGui::ColorConvertFloat4ToU32(black_outline_colorr));

                    }
                    else if (Variables::boxtype == 1) { // dynamic 2d lol


                        ImVec4 aasdwasdw = ImVec4(Variables::box_color[0], Variables::box_color[1], Variables::box_color[2], 1.0f);
                        ImU32 boxcolor = ImGui::GetColorU32(aasdwasdw);
                        atomic::roblox::vector3_t corner1 = vector_add(vector_add(look_position_3D, multiply_vector3_by(side_vector1, dynamicwidth / 2)), multiply_vector3_by({ 0.0f, -0.60f, 0.0f }, dynamicheight));
                        atomic::roblox::vector3_t corner2 = vector_add(corner1, multiply_vector3_by(side_vector2, dynamicheight));
                        atomic::roblox::vector3_t corner3 = vector_add(vector_add(look_position_3D, multiply_vector3_by(side_vector1, -dynamicwidth / 2)), multiply_vector3_by({ 0.0f, -0.60f, 0.0f }, dynamicheight));
                        atomic::roblox::vector3_t corner4 = vector_add(corner3, multiply_vector3_by(side_vector2, dynamicheight));

                        atomic::roblox::vector2_t corner1_screen = atomic::roblox::world_to_screen({ corner1.x, corner1.y, corner1.z }, dimensions, viewmatrix);
                        atomic::roblox::vector2_t corner2_screen = atomic::roblox::world_to_screen({ corner2.x, corner2.y, corner2.z }, dimensions, viewmatrix);
                        atomic::roblox::vector2_t corner3_screen = atomic::roblox::world_to_screen({ corner3.x, corner3.y, corner3.z }, dimensions, viewmatrix);
                        atomic::roblox::vector2_t corner4_screen = atomic::roblox::world_to_screen({ corner4.x, corner4.y, corner4.z }, dimensions, viewmatrix);

                        if (corner1_screen.x == -1 || corner2_screen.x == -1 || corner3_screen.x == -1 || corner4_screen.x == -1)
                            break;

                        draw->AddLine(ImVec2(corner1_screen.x, corner1_screen.y), ImVec2(corner2_screen.x, corner2_screen.y), boxcolor);
                        draw->AddLine(ImVec2(corner2_screen.x, corner2_screen.y), ImVec2(corner4_screen.x, corner4_screen.y), boxcolor);
                        draw->AddLine(ImVec2(corner4_screen.x, corner4_screen.y), ImVec2(corner3_screen.x, corner3_screen.y), boxcolor);
                        draw->AddLine(ImVec2(corner3_screen.x, corner3_screen.y), ImVec2(corner1_screen.x, corner1_screen.y), boxcolor);

                    }
                    else if (Variables::boxtype == 2) {

                        ImVec4 colorVec = ImVec4(Variables::box_color[0], Variables::box_color[1], Variables::box_color[2], 1.0f);
                        ImU32 color = ImGui::GetColorU32(colorVec);


                        std::vector<atomic::roblox::vector3_t> CubeVertices = GetCorners(vector_sub(hrp_pos, { 0, 0.5, 0 }), { 1.5, 3.25, 1.5 });

                        atomic::roblox::vector2_t CubeVertice1 = atomic::roblox::world_to_screen(CubeVertices[0], dimensions, viewmatrix);
                        atomic::roblox::vector2_t CubeVertice2 = atomic::roblox::world_to_screen(CubeVertices[1], dimensions, viewmatrix);
                        atomic::roblox::vector2_t CubeVertice3 = atomic::roblox::world_to_screen(CubeVertices[2], dimensions, viewmatrix);
                        atomic::roblox::vector2_t CubeVertice4 = atomic::roblox::world_to_screen(CubeVertices[3], dimensions, viewmatrix);

                        if (CubeVertice1.x == -1 || CubeVertice2.x == -1 || CubeVertice3.x == -1 || CubeVertice4.x == -1)
                            continue;

                        atomic::roblox::vector2_t CubeVertice5 = atomic::roblox::world_to_screen(CubeVertices[4], dimensions, viewmatrix);
                        atomic::roblox::vector2_t CubeVertice6 = atomic::roblox::world_to_screen(CubeVertices[5], dimensions, viewmatrix);
                        atomic::roblox::vector2_t CubeVertice7 = atomic::roblox::world_to_screen(CubeVertices[6], dimensions, viewmatrix);
                        atomic::roblox::vector2_t CubeVertice8 = atomic::roblox::world_to_screen(CubeVertices[7], dimensions, viewmatrix);

                        if (CubeVertice5.x == -1 || CubeVertice6.x == -1 || CubeVertice7.x == -1 || CubeVertice8.x == -1)
                            continue;

                        draw->AddLine(ImVec2(CubeVertice1.x, CubeVertice1.y), ImVec2(CubeVertice2.x, CubeVertice2.y), color);
                        draw->AddLine(ImVec2(CubeVertice2.x, CubeVertice2.y), ImVec2(CubeVertice6.x, CubeVertice6.y), color);
                        draw->AddLine(ImVec2(CubeVertice6.x, CubeVertice6.y), ImVec2(CubeVertice5.x, CubeVertice5.y), color);
                        draw->AddLine(ImVec2(CubeVertice5.x, CubeVertice5.y), ImVec2(CubeVertice1.x, CubeVertice1.y), color);

                        draw->AddLine(ImVec2(CubeVertice1.x, CubeVertice1.y), ImVec2(CubeVertice3.x, CubeVertice3.y), color);
                        draw->AddLine(ImVec2(CubeVertice2.x, CubeVertice2.y), ImVec2(CubeVertice4.x, CubeVertice4.y), color);
                        draw->AddLine(ImVec2(CubeVertice6.x, CubeVertice6.y), ImVec2(CubeVertice8.x, CubeVertice8.y), color);
                        draw->AddLine(ImVec2(CubeVertice5.x, CubeVertice5.y), ImVec2(CubeVertice7.x, CubeVertice7.y), color);

                        draw->AddLine(ImVec2(CubeVertice3.x, CubeVertice3.y), ImVec2(CubeVertice4.x, CubeVertice4.y), color);
                        draw->AddLine(ImVec2(CubeVertice4.x, CubeVertice4.y), ImVec2(CubeVertice8.x, CubeVertice8.y), color);
                        draw->AddLine(ImVec2(CubeVertice8.x, CubeVertice8.y), ImVec2(CubeVertice7.x, CubeVertice7.y), color);
                        draw->AddLine(ImVec2(CubeVertice7.x, CubeVertice7.y), ImVec2(CubeVertice3.x, CubeVertice3.y), color);
                    }



                    else if (Variables::boxtype == 3) {




                        /*ImVec4 colorVec = ImVec4(Variables::box_color[0], Variables::box_color[1], Variables::box_color[2], 1.0f);
                        ImU32 color = ImGui::GetColorU32(colorVec);

                        std::vector<atomic::roblox::vector3_t> CubeVertices = GetCorners(vector_sub(hrp_pos, { 0, 0.5, 0 }), { 2.0, 3.25, 1.5 });

                        for (int i = 0; i < 8; ++i) {
                            atomic::roblox::vector3_t relativeCorner = vector_sub(CubeVertices[i], hrp_pos);
                            atomic::roblox::vector3_t rotatedCorner = {
                                dotProduct(relativeCorner, side_vector1),
                                relativeCorner.y,
                                -dotProduct(relativeCorner, look_direction)
                            };
                            CubeVertices[i] = add_vector3(rotatedCorner, hrp_pos);
                        }

                        atomic::roblox::vector2_t CubeVertice1 = atomic::roblox::world_to_screen(CubeVertices[0], dimensions, viewmatrix);
                        atomic::roblox::vector2_t CubeVertice2 = atomic::roblox::world_to_screen(CubeVertices[1], dimensions, viewmatrix);
                        atomic::roblox::vector2_t CubeVertice3 = atomic::roblox::world_to_screen(CubeVertices[2], dimensions, viewmatrix);
                        atomic::roblox::vector2_t CubeVertice4 = atomic::roblox::world_to_screen(CubeVertices[3], dimensions, viewmatrix);

                        if (CubeVertice1.x == -1 || CubeVertice2.x == -1 || CubeVertice3.x == -1 || CubeVertice4.x == -1)
                            continue;

                        atomic::roblox::vector2_t CubeVertice5 = atomic::roblox::world_to_screen(CubeVertices[4], dimensions, viewmatrix);
                        atomic::roblox::vector2_t CubeVertice6 = atomic::roblox::world_to_screen(CubeVertices[5], dimensions, viewmatrix);
                        atomic::roblox::vector2_t CubeVertice7 = atomic::roblox::world_to_screen(CubeVertices[6], dimensions, viewmatrix);
                        atomic::roblox::vector2_t CubeVertice8 = atomic::roblox::world_to_screen(CubeVertices[7], dimensions, viewmatrix);

                        if (CubeVertice5.x == -1 || CubeVertice6.x == -1 || CubeVertice7.x == -1 || CubeVertice8.x == -1)
                            continue;

                        draw->AddLine(ImVec2(CubeVertice1.x, CubeVertice1.y), ImVec2(CubeVertice2.x, CubeVertice2.y), color);
                        draw->AddLine(ImVec2(CubeVertice2.x, CubeVertice2.y), ImVec2(CubeVertice6.x, CubeVertice6.y), color);
                        draw->AddLine(ImVec2(CubeVertice6.x, CubeVertice6.y), ImVec2(CubeVertice5.x, CubeVertice5.y), color);
                        draw->AddLine(ImVec2(CubeVertice5.x, CubeVertice5.y), ImVec2(CubeVertice1.x, CubeVertice1.y), color);

                        draw->AddLine(ImVec2(CubeVertice1.x, CubeVertice1.y), ImVec2(CubeVertice3.x, CubeVertice3.y), color);
                        draw->AddLine(ImVec2(CubeVertice2.x, CubeVertice2.y), ImVec2(CubeVertice4.x, CubeVertice4.y), color);
                        draw->AddLine(ImVec2(CubeVertice6.x, CubeVertice6.y), ImVec2(CubeVertice8.x, CubeVertice8.y), color);
                        draw->AddLine(ImVec2(CubeVertice5.x, CubeVertice5.y), ImVec2(CubeVertice7.x, CubeVertice7.y), color);

                        draw->AddLine(ImVec2(CubeVertice3.x, CubeVertice3.y), ImVec2(CubeVertice4.x, CubeVertice4.y), color);
                        draw->AddLine(ImVec2(CubeVertice4.x, CubeVertice4.y), ImVec2(CubeVertice8.x, CubeVertice8.y), color);
                        draw->AddLine(ImVec2(CubeVertice8.x, CubeVertice8.y), ImVec2(CubeVertice7.x, CubeVertice7.y), color);
                        draw->AddLine(ImVec2(CubeVertice7.x, CubeVertice7.y), ImVec2(CubeVertice3.x, CubeVertice3.y), color);*/
                    }
                    else if (Variables::boxtype == 4) {
                        DrawEsp(leg_pos.x - (width / 1.3f), leg_pos.y, headPos.x + width - leg_pos.x + (width / 1.3f), headPos.y + height - leg_pos.y);

                    }




                }
            }
        }
    }
}