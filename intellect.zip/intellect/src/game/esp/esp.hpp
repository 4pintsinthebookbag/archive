#pragma once

#define _USE_MATH_DEFINES
#include <cmath>

#define IMGUI_DEFINE_MATH_OPERATORS

namespace atomic
{
	namespace roblox
	{
		void hook_esp();
	}
}