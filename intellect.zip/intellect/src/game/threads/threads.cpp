#include "../classes/GameStructs.hpp"
#include "../Variables/Variables.hpp"
#include "../src/game/classes/playerClass/playerClass.h"
#include <iostream>
#include <thread>
#include <vector>
#include <windows.h>
#include <chrono>
#include <atomic>
#include <mutex>
#include <unordered_map>
std::atomic<bool> thread_running(false);
std::atomic<bool> heartbeat_received(false);
std::mutex heartbeat_mutex;


int findMostFrequent(const std::vector<int>& nums) {
    if (nums.empty()) return -1;
    std::unordered_map<int, int> countMap;
    int maxCount = 0, mostFrequent = nums[0];

    for (int num : nums) {
        if (++countMap[num] > maxCount) {
            maxCount = countMap[num];
            mostFrequent = num;
        }
    }
    return mostFrequent;
}

template <typename T>
void synchronizeLists(std::vector<T>& namesList1, const std::vector<T>& namesList2) {
    namesList1.erase(
        std::remove_if(
            namesList1.begin(),
            namesList1.end(),
            [&namesList2](const T& item) {
                return std::find(namesList2.begin(), namesList2.end(), item) == namesList2.end();
            }
        ),
        namesList1.end()
    );

    for (auto it = namesList2.begin(); it != namesList2.end(); ++it) {
        auto pos = std::distance(namesList2.begin(), it);
        if (pos >= namesList1.size() || *it != namesList1[pos]) {
            namesList1.insert(namesList1.begin() + pos, *it);
        }
    }
}

void updateThread() {

    int_fast64_t currentid = Variables::datamodel.get_gameid();
    Variables::ESPPlayers = Variables::datamodel.find_first_child("Players"); // defaultly ^
    if (currentid == 17625359962) {
        std::cout << "[ESPPlayers] RIVALS found" << std::endl;
        Variables::ESPPlayers = Variables::datamodel.find_first_child("Players - Client");
    }
    auto players = Variables::ESPPlayers;



    std::vector<int> playersVal;
    for (int i = 0; i < 30; i++) {
        playersVal.push_back(players.readplayers(players.self));
     //   std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    int mostfreq = findMostFrequent(playersVal);
    std::vector<Player> tempList;
    thread_running = true;
    while (thread_running) {
        std::this_thread::sleep_for(std::chrono::milliseconds(500));

        {
            std::lock_guard<std::mutex> lock(heartbeat_mutex);
            heartbeat_received = true;
        }

        if (players.readplayers(players.self) != mostfreq) continue;
    //    std::this_thread::sleep_for(std::chrono::milliseconds(1));

        tempList.clear();

        for (auto& player : players.children()) {
            Player plr;
            plr.playerInstance = player;
            plr.modelinstance = player.get_model_instance();
            plr.humanoid = plr.modelinstance.find_first_child("Humanoid");
            plr.headInstance = plr.modelinstance.find_first_child("Head");
            plr.hrpInstance = plr.modelinstance.find_first_child("HumanoidRootPart");
            plr.humanoidInstance = plr.modelinstance.find_first_child("Humanoid");
            plr.leftupperarm = plr.modelinstance.find_first_child("LeftUpperArm");
            plr.rightupperarm = plr.modelinstance.find_first_child("RightUpperArm");
            plr.leftelbow = plr.modelinstance.find_first_child("LeftLowerArm");
            plr.rightelbow = plr.modelinstance.find_first_child("RightLowerArm");
            plr.lefthand = plr.modelinstance.find_first_child("LeftHand");
            plr.righthand = plr.modelinstance.find_first_child("RightHand");
            plr.leftleg = plr.modelinstance.find_first_child("LeftLowerLeg");
            plr.rightleg = plr.modelinstance.find_first_child("RightLowerLeg");


            if (Variables::armorbar) {
                plr.armorpath = player.get_model_instance().find_first_child("BodyEffects").find_first_child("Armor");
            }

           tempList.push_back(plr);
        }

        synchronizeLists(playerList, tempList);

        for (auto& player : playerList) {
            player.modelinstance = player.playerInstance.get_model_instance();
            player.headInstance = player.modelinstance.find_first_child("Head");
            player.hrpInstance = player.modelinstance.find_first_child("HumanoidRootPart");
        }
    }
}

void monitorThread(std::thread& funcThread, HANDLE& threadHandle) {
    while (true) {
        std::this_thread::sleep_for(std::chrono::seconds(1));

        bool heartbeat_ok = false;
        {
            std::lock_guard<std::mutex> lock(heartbeat_mutex);
            heartbeat_ok = heartbeat_received;
            heartbeat_received = false;
            Variables::threadcrash = false;
        }

        if (!heartbeat_ok) {
            std::cout << "[HeartBeat] Thread Failed Retrying. . ." << std::endl;
            heartbeat_ok = true;
            Variables::threadcrash = true;
            if (funcThread.joinable()) {
                CloseHandle(threadHandle);
                TerminateThread(threadHandle, 0);
                funcThread.join();
            }


            funcThread = std::thread(updateThread);
            threadHandle = funcThread.native_handle();
            funcThread.detach();
        }
    }
}