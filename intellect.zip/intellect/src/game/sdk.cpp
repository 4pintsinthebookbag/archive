#include "sdk.h"
#include "Variables/Variables.hpp"
#include <thread>
#include <chrono>



std::vector<std::string> AvailableParts =
{
    "Head", "Humanoid", "[Revolver]", "[Double-Barrel]", "[Knife]", "[Tactical-Shotgun]", "[SMG]",
    "UpperTorso", "LowerTorso", "HumanoidRootPart",
    "LeftUpperArm", "LeftLowerArm", "LeftHand",
    "RightUpperArm", "RightLowerArm", "RightHand",
    "LeftUpperLeg", "LeftLowerLeg", "LeftFoot",
    "RightUpperLeg", "RightLowerLeg", "RightFoot"
};

// Define the Players map
std::map<atomic::roblox::PlayerObject, std::vector<atomic::roblox::PlayerObject>, atomic::roblox::PlayerObjectComparator> atomic::roblox::sdk::Players;

void atomic::roblox::sdk::Update()
{
    for (auto player : Variables::playerslocation.children())
    {


        atomic::roblox::PlayerObject playerObject;
        playerObject.inst = player;
        playerObject.Name = player.name();

        std::vector<atomic::roblox::PlayerObject> BodyParts;

        if (!player.find_first_child("Humanoid").self)
        {
            continue;
        }

        for (auto bp : player.children())
        {
            std::string bpName = bp.name();

            for (const std::string& bodyPartName : AvailableParts)
            {
                if (bodyPartName == bpName)
                {
                    atomic::roblox::PlayerObject bodyPart;
                    bodyPart.Name = bpName;
                    bodyPart.inst = bp;

                    BodyParts.push_back(bodyPart);
                    continue;
                }
            }
        }

        atomic::roblox::sdk::Players[playerObject] = BodyParts;
    }
}

atomic::roblox::instance_t atomic::roblox::sdk::Find(std::vector<atomic::roblox::PlayerObject> BodyParts, std::string Target) {
{
    for (auto bodypart : BodyParts)
    {
        std::string respectiveName = bodypart.Name;
        if (respectiveName == Target)
        
            return bodypart.inst;
        }
    }
}


void atomic::roblox::sdk::HookUpdate()
{
    while (true)
    {
        atomic::roblox::sdk::Update();
        std::this_thread::sleep_for(std::chrono::seconds(2));
    }
}
