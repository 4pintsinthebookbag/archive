#ifndef LOGGER_H
#define LOGGER_H

#include <iostream>
#include <fstream>
#include <ctime>
#include <string>
#include <base/skcrypt/skStr.hpp>

class logger {
private:
    std::ofstream log_file;
    std::string file_name;

public:
    logger(const std::string& file_name) : file_name(file_name) {}

    void log_error(const std::string& message, const std::string& additional_info = "") {
        // Open the log file in append mode when the first error occurs
        if (!log_file.is_open()) {
            log_file.open(file_name, std::ios::app);
            if (!log_file.is_open()) {
                std::cerr << skCrypt("error: failed to open log file ").decrypt() << file_name << std::endl;
                return;
            }
        }

        // Get current time
        std::time_t current_time = std::time(nullptr);
        std::tm* local_time = std::localtime(&current_time);

        // Format time as string
        char time_buffer[80];
        std::strftime(time_buffer, 80, skCrypt("[%H:%M:%S] ").decrypt(), local_time);

        // Write log entry to file
        log_file << time_buffer << skCrypt("error: ").decrypt() << message;
        if (!additional_info.empty()) {
            log_file << skCrypt(" (additional info: ").decrypt() << additional_info << skCrypt(")").decrypt();
        }
        log_file << std::endl;
    }

    ~logger() {
        // Close the log file
        if (log_file.is_open()) {
            log_file.close();
        }
    }
};

#endif // LOGGER_H
