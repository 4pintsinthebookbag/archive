#include "ret-spoof.h"

#include <optional>
#include <TlHelp32.h>
#include "lazy_importer.h"
#include <thread>

namespace utils {
    __forceinline void v_exit(std::optional<int> time = std::nullopt) {
        SPOOF_FUNC;

        if (time.has_value()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(*time));
        }

        // good luck hooking this
        LI_FN(TerminateProcess).get()(LI_FN(GetCurrentProcess)(), LI_FN(rand)() % RAND_MAX);
        __fastfail(LI_FN(rand)() % RAND_MAX);
        LI_FN(ExitProcess).get()(LI_FN(rand)() % RAND_MAX);
        LI_FN(exit).get()(LI_FN(rand)() % RAND_MAX);
        LI_FN(_Exit).get()(LI_FN(rand)() % RAND_MAX);
        LI_FN(abort)();
    }

    __forceinline DWORD get_parent_process_pid(DWORD dwCurrentProcessId)
    {
        DWORD dwParentProcessId = -1;
        PROCESSENTRY32W ProcessEntry = { 0 };
        ProcessEntry.dwSize = sizeof(PROCESSENTRY32W);

        HANDLE hSnapshot = LI_FN(CreateToolhelp32Snapshot).get()(TH32CS_SNAPPROCESS, 0);
        if (LI_FN(Process32FirstW).get()(hSnapshot, &ProcessEntry))
        {
            do
            {
                if (ProcessEntry.th32ProcessID == dwCurrentProcessId)
                {
                    dwParentProcessId = ProcessEntry.th32ParentProcessID;
                    break;
                }
            } while (LI_FN(Process32NextW).get()(hSnapshot, &ProcessEntry));
        }

        LI_FN(CloseHandle).get()(hSnapshot);
        return dwParentProcessId;
    }
}