#include "security.h"
#include "ret-spoof.h"
#include "log_system.h"
#include "ret-spoof.h"
#include "security_utils.h"

// PEB
#include <Windows.h>
#include <intrin.h>
#include <Psapi.h>
#include <TlHelp32.h>
#include <thread>
#include <winternl.h>
#include <vector>

#include <base/skcrypt/skStr.hpp>

//#include "../main_defs.h"
//#include "../utils/log_system.h"
//#include "../utils/utils.h"

security::core::runtime_security_ptr c_security = std::make_unique<security::core::runtime_security>();
namespace security::core {
	//logger logging("error_log.txt");

	__forceinline void runtime_security::detect_blacklisted_drivers() {
		SPOOF_FUNC;

		for (;;)
		{
			static const char* BlackListedDrivers[] = {
				skCrypt("Sbie"),		         // Sandboxie
				skCrypt("NPF"),	                // WireShark / WinPCAP
				skCrypt("KProcessHacker"),	   // Process Hacker
				skCrypt("TitanHide"),	      // TitanHide
				skCrypt("HttpDebuggerSdk"),  // httpdebugger
				skCrypt("dbk64"),           // Cheat Engine
				skCrypt("SharpOD_Drv"),    // SharpOD
			};

			uint16_t Length = sizeof BlackListedDrivers / sizeof(BlackListedDrivers[0]);

			void* DriverList[1024];
			DWORD Needed;

			if (LI_FN(K32EnumDeviceDrivers)(DriverList, sizeof DriverList, &Needed))
			{
				if (Needed > sizeof DriverList)
				{
					std::cout << (skCrypt("a security thread has failed, make sure programs aren't interfering with the loader.").decrypt(), skCrypt("internal failure").decrypt());
					utils::v_exit();
				}

				char	 DriverName[1024];
				uint32_t DriverCount = Needed / sizeof DriverList[0];

				for (size_t n{}; n < DriverCount; ++n)
				{
					if (LI_FN(K32GetDeviceDriverBaseNameA)(DriverList[n], DriverName, sizeof DriverName / sizeof DriverList[0]))
					{
						for (size_t j{}; j < Length; ++j)
						{
							if (strstr(DriverName, BlackListedDrivers[j])) {
							//	logging.log_error(skCrypt("blacklisted software has been detected, please uninstall any debugging/reverse-engineering programs and try again.").decrypt(), skCrypt("internal failure").decrypt());
							//	utils::v_exit();
							}
						}
					}
				}
			}

			// Don't put too much stress on the CPU.
			// NOTE: We don't have to check this often
			std::this_thread::sleep_for(std::chrono::milliseconds(250));
		}
	}

	__forceinline bool runtime_security::explorer_check()
	{
		SPOOF_FUNC;

		bool bDebugged = false;
		DWORD dwParentProcessId = utils::get_parent_process_pid(LI_FN(GetCurrentProcessId)());

		PROCESSENTRY32W ProcessEntry = { 0 };
		ProcessEntry.dwSize = sizeof(PROCESSENTRY32W);

		HANDLE hSnapshot = LI_FN(CreateToolhelp32Snapshot)(TH32CS_SNAPPROCESS, 0);
		if (LI_FN(Process32FirstW)(hSnapshot, &ProcessEntry))
		{
			do
			{
				if ((ProcessEntry.th32ProcessID == dwParentProcessId) && (wcscmp(ProcessEntry.szExeFile, skCrypt(L"explorer.exe").decrypt())))
				{
					bDebugged = true;
					break;
				}
			} while (LI_FN(Process32NextW)(hSnapshot, &ProcessEntry));
		}

		LI_FN(CloseHandle)(hSnapshot);

		return bDebugged;
	}

	__forceinline void runtime_security::detect_debuggers()
	{
		// Read the PEB from the TIB.
		// Offset for x86 is 0x30 ; mov ..., dword ptr fs:[0x30]
		// Offset for x64 is 0x60 ; mov ..., qword ptr gs:[0x60]
		PEB* ProcessEnvBlock = (PEB*)__readgsqword(0x60);

		// Being debugged, exit instantly
		if (ProcessEnvBlock->BeingDebugged)
			utils::v_exit();

		for (;;)
		{
			using WindowParams = std::pair<const char*, const char*>;
			static std::vector<WindowParams> BlackListedWindows = {
				{skCrypt("ID"),				skCrypt("Immunity")},                            // Immunity Debugger
				{skCrypt("Qt5QWindowIcon"),	skCrypt("x64dbg")},	                            // x64dbg
				{skCrypt("Qt5QWindowIcon"),	skCrypt("The Wireshark Network Analyzer")},    // Wireshark
				{skCrypt("Qt5QWindowIcon"),	skCrypt("GlassWire")},                        // Glasswire
				{skCrypt("OLLYDBG"),		skCrypt("OllyDbg")},                         // OllyDbg
				{nullptr, skCrypt("Progress Telerik Fiddler Web Debugger")},            // Telerik Fiddler
				{nullptr, skCrypt("HTTPDebuggerUI")},                                  // HTTPDebugger
				{nullptr, skCrypt("The Interactive Disassembler")},				      // IDA
				{nullptr, skCrypt("IDA")},										     // IDA
				{nullptr, skCrypt("Process Hacker")},								// ProcessHacker
				{nullptr, skCrypt("ImportREC")},						           // ImportReconstructor
				{nullptr, skCrypt("scylla")},					                  // Scylla
				{nullptr, skCrypt("windbg")},					                 // WinDBG
				{nullptr, skCrypt("dbg")},									    // Generic
				{nullptr, skCrypt("debugger")},								   // Generic
				{nullptr, skCrypt("debug")},								  // Generic
				{nullptr, skCrypt("disassembly")},							 // Generic
				{nullptr, skCrypt("disassembler")},							// Generic
				{nullptr, skCrypt("reconstructor")},					   // Generic
				{nullptr, skCrypt("dbg")},								  // Generic
				{nullptr, skCrypt("[CPU")}						         // Generic
			};

			for (auto& It : BlackListedWindows)
			{
				// NOTE: This shouldn't be written to the log, but we'll write it anyways, because the user wouldn't know what's wrong in case of a false positive
				//if (LI_FN(FindWindowA)(It.first, It.second)) {
					//logging.log_error(skCrypt("blacklisted software has been detected, please uninstall any debugging/reverse-engineering programs and try again.").decrypt(), skCrypt("internal failure").decrypt());
					//utils::v_exit();
					// always causes false positives so removed!
				//}
			}

			// Don't put too much stress on the CPU.
			std::this_thread::sleep_for(std::chrono::milliseconds(10));
		}
	}

	bool runtime_security::security_start() {
		SPOOF_FUNC;

		if (LI_FN(IsDebuggerPresent)())
			return false;

		if (runtime_security::explorer_check())
			return false;

		std::thread(&runtime_security::detect_blacklisted_drivers, this).detach();
		std::thread(&runtime_security::detect_debuggers, this).detach();
		return true;
	}
}
