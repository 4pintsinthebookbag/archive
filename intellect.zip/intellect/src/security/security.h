#ifndef SECURITY_H
#define SECURITY_H
#include <memory>

namespace security::core {
    class runtime_security {
    private:
        __forceinline void detect_blacklisted_drivers();
        __forceinline bool explorer_check();
        __forceinline void detect_debuggers();

    public:
        bool security_start();
    };
    using runtime_security_ptr = std::unique_ptr<runtime_security>;
}
extern security::core::runtime_security_ptr c_security;

#endif // SECURITY_H
