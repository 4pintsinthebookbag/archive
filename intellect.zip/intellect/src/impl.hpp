#pragma once
#include <Windows.h>

#include <iostream>

#include <string>

#include <unordered_map>

#include <functional>
#define _user ("\x1b[41m\x1b[37m#\x1b[40m\x1b[37m ")

namespace intellect {

	auto disable_scrollbar() -> VOID {

		HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

		CONSOLE_SCREEN_BUFFER_INFO csbi;

		if (!GetConsoleScreenBufferInfo(hConsole, &csbi)) {
			std::cerr << (skCrypt("failed to get console screen buffer info")) << std::endl;
			return;
		}

		COORD bufferSize;
		bufferSize.X = csbi.srWindow.Right - csbi.srWindow.Left + 1;
		bufferSize.Y = csbi.srWindow.Bottom - csbi.srWindow.Top + 1;
	}

	auto set_style() -> VOID {

		HWND hWnd = GetConsoleWindow();

		LONG_PTR style = GetWindowLongPtr(hWnd, GWL_STYLE);

		style &= ~(WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX);

		//                                       X      Y
		SetWindowPos(hWnd, NULL, (150), (100), (418), (206), SWP_NOMOVE | SWP_NOZORDER | SWP_FRAMECHANGED);

		ShowScrollBar(hWnd, SB_BOTH, FALSE);

	}

	auto address_t() -> VOID {

		std::srand(static_cast<unsigned int>(std::time(nullptr)));

		int rnd = 10 + std::rand() % 90;

		disable_scrollbar();

		set_style();

		std::string title = (("connected - " + std::to_string(rnd) + (("ms"))));

		SetConsoleTitleA((title.c_str()));

		system(skCrypt("color f"));

	}


	auto main_t() -> VOID {

		address_t();

		std::cout << _user << skCrypt("welcome back") << std::endl;

		std::this_thread::sleep_for(std::chrono::seconds(1));

		std::cout << _user << skCrypt("preparing injection") << std::endl;

		// @TODO: Add injection.

		for (;;);
	}

	std::vector< uint8_t > shellcode = {

		0x50,                               // push eax
		0xB8, 0x39, 0x05, 0x00, 0x00,       // mov eax, 1337
		0x03, 0x06,                         // add eax, dword ptr [esi]
		0x59                                // pop ecx

	};

}
