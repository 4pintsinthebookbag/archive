#include "hacks.hpp"
#include "../game/Variables/Variables.hpp"
#include <chrono>
#include <cmath>
#include <iostream>
#include <thread>
#include <game/threads/threads.hpp>
#include "game/classes/GameStructs.hpp" 
#include <base/xorstr/xorstr.hpp>

atomic::roblox::instance_t character{};
atomic::roblox::instance_t hrp{};
atomic::roblox::instance_t camera{};


std::chrono::steady_clock::time_point getTime() {
    return std::chrono::steady_clock::now();
}

auto start_time = std::chrono::high_resolution_clock::now();
std::chrono::steady_clock::time_point previousTime = getTime();

float calculateDeltaTime(std::chrono::steady_clock::time_point& previousTime) {
    auto currentTime = getTime();
    std::chrono::duration<float> delta = currentTime - previousTime;
    previousTime = currentTime;
    return delta.count();
}

void CFrameSpeed(atomic::roblox::instance_t& character) {
    atomic::roblox::vector3_t currentCFrame = character.get_part_pos();
    atomic::roblox::vector3_t currentVelocity = character.get_part_velocity();

    currentVelocity = currentVelocity * 0.0001;


    float multiplier = Variables::cframespeed;

    atomic::roblox::vector3_t moveDir = atomic::roblox::vector3_t(currentVelocity.x * multiplier, 0, currentVelocity.z * multiplier); // x, z

    atomic::roblox::vector3_t cfpos = atomic::roblox::vector3_t(currentCFrame + moveDir);

    character.set_part_pos_loop(cfpos); // set_part_cframe is buggy but you can use that
}

bool spacepressed = false;
bool controlpressed = false;
bool isLocked = false;

float lockedYPosition = 0.0f;

void checkKeyPresses() {

    if (GetAsyncKeyState(VK_SPACE) & 0x8000) {
        spacepressed = true;
    }
    else {
        spacepressed = false;
    }


    if (GetAsyncKeyState(VK_CONTROL) & 0x8000) {
        controlpressed = true;
    }
    else {
        controlpressed = false;
    }


    if (!spacepressed && !controlpressed) {
        isLocked = false;
    }
}


void spinbot(atomic::roblox::instance_t rootPart) {
        atomic::roblox::vector3_t currentCFrame = rootPart.get_part_pos();
        atomic::roblox::vector3_t currentVelocity = rootPart.get_part_velocity();

        currentCFrame = currentCFrame + currentVelocity;
        rootPart.set_part_cframe(currentCFrame);
}

void flyspeed(atomic::roblox::instance_t rootPart) {
    checkKeyPresses();

    atomic::roblox::vector3_t currentCFrame = rootPart.get_part_pos();
    atomic::roblox::vector3_t currentVelocity = rootPart.get_part_velocity();
    atomic::roblox::vector3_t moveDir = atomic::roblox::vector3_t(currentVelocity.x * Variables::flyspeed, 0, currentVelocity.z * Variables::flyspeed);


    if (spacepressed) {
        moveDir.y = Variables::flyspeed * 0.01f;
    }
    else if (controlpressed) {
        moveDir.y = -Variables::flyspeed * 0.01f;
    }
    else if (isLocked) {
        moveDir.y = lockedYPosition - currentCFrame.y;
    }

    atomic::roblox::vector3_t newPos = currentCFrame + moveDir;
    rootPart.set_part_pos_loop(newPos);
}


//void atomic::roblox::hookhacks()
//{
//    auto inst = Variables::players.get_local_player().get_model_instance();
//    character = inst;
//    hrp = character.find_first_child("HumanoidRootPart");
//    while (true)
//    {
//
//        auto inst = Variables::players.get_local_player().get_model_instance();
//        character = inst;
//        hrp = character.find_first_child("HumanoidRootPart");
//        if (inst.self) {
//            Variables::cspeedkey.update();
//            Variables::flykey.update();
//
//            if (Variables::cspeedkey.enabled && Variables::cframe) {
//                moveCharacterDirectionally(hrp);
//            }
//            else if (Variables::cspeedkey.enabled && Variables::cframedh) {
//                moveCharacterDirectionally(hrp);
//            }
//            else if (Variables::Fly and Variables::flykey.enabled) {
//                {
//                    checkKeyPresses();
//                    flyspeed(hrp);
//                }
//
//            }
//        }
//    }
//}

void atomic::roblox::hookhacks()
{
    auto inst = Variables::players.get_local_player().get_model_instance();
   //     character = inst;
   //     hrp = character.find_first_child("HumanoidRootPart");
  atomic::roblox::instance_t rootPart = Variables::players.get_local_player().get_model_instance().find_first_child(XorStr("HumanoidRootPart"));
    while (true)
    {
        if (rootPart.self) {
           // auto inst = Variables::players.get_local_player().get_model_instance();
          //  character = inst;
        //    hrp = Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart");
          //  hrp = Variables::players.get_local_player().get_model_instance().find_first_child(XorStr("HumanoidRootPart"));

            atomic::roblox::instance_t rootPart = Variables::players.get_local_player().get_model_instance().find_first_child(XorStr("HumanoidRootPart"));

            Variables::cspeedkey.update();
            Variables::flykey.update();

            if (Variables::cspeedkey.enabled && Variables::cframe) {
                CFrameSpeed(rootPart);
            }

            if (Variables::orbit)
            {
               spinbot(rootPart);
            }

            else if (Variables::cspeedkey.enabled && Variables::cframedh) {
                CFrameSpeed(rootPart);
            }
            else if (Variables::Fly and Variables::flykey.enabled) {
                {
                    checkKeyPresses();
                    flyspeed(rootPart);
                }
            }
        }
    }
}