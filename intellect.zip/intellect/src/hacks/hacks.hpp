#pragma once

#include "../game/classes/GameStructs.hpp"

namespace atomic
{
	namespace roblox
	{
		void hookhacks();
		void hookhacksdh();
		void hookhackshoodcustoms();
	}
}