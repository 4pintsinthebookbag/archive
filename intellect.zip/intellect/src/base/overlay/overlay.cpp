﻿#define IMGUI_DEFINE_MATH_OPERATORS

#include "overlay.hpp"
#include "imgui/imgui_impl_win32.h"
#include "imgui/imgui_impl_dx11.h"
#include <dwmapi.h>
#include "imgui/imgui.h"

#include "../../game/Variables/Variables.hpp"
#ifndef _MIN_MUL
#define _MIN_MUL 0.00
#define _MAX_MUL 0.50
#endif
#ifndef _MIN_DIV
#define _MIN_DIV 0.00
#define _MAX_DIV 10.00
#endif
// lua env


#include "ckeybind/keybind.hpp"
#include "../skcrypt/skStr.hpp"
#include "../xorstr/xorstr.hpp"
#include "../configs/configs.hpp"
#include "../json/json.hpp"
#include "../src/base/overlay/font.h"
#include "../src/base/overlay/custom/custom.h"
#include <filesystem>

#include <game/esp/esp.hpp>
#include <game/classes/playerClass/playerClass.h>
using namespace atomic::roblox;
static int tabs = 1;

char waypointsz[256];
char dhwaypointsz[256];
std::vector<std::pair<std::string, atomic::roblox::vector3_t>> waypoints;
std::vector<std::pair<std::string, atomic::roblox::vector3_t>> dhwaypoints;

float box_thickness = 1;
static int notify_select = 0;
const char* notify_items[2]{ "Circle", "Line" };

ID3D11Device* atomic::utils::overlay::d3d11_device = nullptr;

ID3D11DeviceContext* atomic::utils::overlay::d3d11_device_context = nullptr;

ID3D11ShaderResourceView* Logo = nullptr;

IDXGISwapChain* atomic::utils::overlay::dxgi_swap_chain = nullptr;

ID3D11RenderTargetView* atomic::utils::overlay::d3d11_render_target_view = nullptr;
ImVec2 pos;


ImFont* medium;
ImFont* bold;
ImFont* tab_icons;
ImFont* logo;
ImFont* tab_title;
ImFont* tab_title_icon;
ImFont* subtab_title;
ImFont* combo_arrow;
ImFont* SkeetFont;
ImFont* atomicFont;
DWORD picker_flags = ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaPreview;

static const char* shake_items[2] = { ("X / Y"), ("Multiplication") };

static const char* combo_items_4[5] = { ("Closest To Cursor"), ("Head"), ("UpperTorso"), ("HumanoidRootPart"), ("LowerTorso")};
static const char* combo_items_2[3] = { ("Mouse"), ("Camera"), ("Free Aim") };
static const char* box_items_3[5] = { ("2D Static"), ("2D Dynamic"), ("3D Static"), ("3D Dynamic"), ("Corner")};
static const char* tracers_type[3] = { ("Top"), ("Bottom"), ("Snaplines") };
static const char* pred_items[2] = { ("Division"), ("Multiplication") };
static const char* prediction_methods[2] = { ("X / Y"), ("Multiplication") };
static const char* smooth_typessex[5] = { ("Linear"), ("Bounce"), ("Elastic"), ("Quadratic"), ("Decay") };
static const char* cframetypes[2] = { ("Default"), ("Da Hood")};

static bool particles = true;

//menu tabs
enum tabss {
	rageaim,
	legitaim,
	antiaim,
	view,
	world,
	players,
	scripts,
	configss,
	settings
};

enum subtabs {
	globals,
	external,
	internal,
	settings2
};

tabss tabmenu = rageaim;
subtabs subtabmenu = globals;

std::vector<std::string> fetchPlayerNames() {
	std::vector<std::string> playerNames;

	auto players = Variables::players;

	for (auto& player : playerList) {
		if (!player.playerInstance.self) continue;

		auto playerName = player.playerInstance.name();
		playerNames.push_back(playerName);
	}
	return playerNames;
}

void Particles()
{
	if (!particles)
		return;

	ImVec2 screen_size = { (float)GetSystemMetrics(SM_CXSCREEN), (float)GetSystemMetrics(SM_CYSCREEN) };

	static ImVec2 partile_pos[100];
	static ImVec2 partile_target_pos[100];
	static float partile_speed[100];
	static float partile_radius[100];


	for (int i = 1; i < 50; i++)
	{
		if (partile_pos[i].x == 0 || partile_pos[i].y == 0)
		{
			partile_pos[i].x = rand() % (int)screen_size.x + 1;
			partile_pos[i].y = 15.f;
			partile_speed[i] = 1 + rand() % 25;
			partile_radius[i] = rand() % 4;

			partile_target_pos[i].x = rand() % (int)screen_size.x;
			partile_target_pos[i].y = screen_size.y * 2;
		}

		partile_pos[i] = ImLerp(partile_pos[i], partile_target_pos[i], ImGui::GetIO().DeltaTime * (partile_speed[i] / 60));

		if (partile_pos[i].y > screen_size.y)
		{
			partile_pos[i].x = 0;
			partile_pos[i].y = 0;
		}

		ImGui::GetWindowDrawList()->AddCircleFilled(partile_pos[i], partile_radius[i], ImColor(255 , 255, 255 , 155 / 2));
	}

}


void DrawInstance(atomic::roblox::instance_t& instance)
{
	auto children = instance.children();
	bool hasChildren = !children.empty();
	bool isLeaf = !hasChildren;

	bool isExpanded = !isLeaf && ImGui::TreeNodeEx(instance.name().c_str(), ImGuiTreeNodeFlags_SpanFullWidth);

	if (isExpanded) {
		for (auto& child : children) {
			DrawInstance(child);
		}
		ImGui::TreePop();
	}
	else if (isLeaf) {
		ImGui::Bullet();
		ImGui::Text("%s", instance.name().c_str());
	}
}

void OpenGameExplorer()
{
	auto datamodelObject = Variables::datamodel;
	if (datamodelObject.self) {
		ImGui::BeginChild("GameExplorer", ImVec2(450, 250), true);

		DrawInstance(const_cast<atomic::roblox::instance_t&>(datamodelObject));

		ImGui::EndChild();
	}
}

bool Keybind(CKeybind* keybind, const ImVec2& size_arg = ImVec2(0, 0), bool clicked = false, ImGuiButtonFlags flags = 0)
{
	ImGuiWindow* window = ImGui::GetCurrentWindow();
	if (window->SkipItems)
		return false;
	// SetCursorPosX(window->Size.x - 14 - size_arg.x);
	ImGuiContext& g = *GImGui;
	const ImGuiStyle& style = g.Style;
	const ImGuiID id = window->GetID(keybind->get_name().c_str());
	const ImVec2 label_size = ImGui::CalcTextSize(keybind->get_name().c_str(), NULL, true);

	ImVec2 pos = window->DC.CursorPos;
	if ((flags & ImGuiButtonFlags_AlignTextBaseLine) &&
		style.FramePadding.y <
		window->DC.CurrLineTextBaseOffset)  // Try to vertically align buttons that are smaller/have no padding so that
		// text baseline matches (bit hacky, since it shouldn't be a flag)
		pos.y += window->DC.CurrLineTextBaseOffset - style.FramePadding.y;
	ImVec2 size = ImGui::CalcItemSize(
		size_arg, label_size.x + style.FramePadding.x * 2.0f, label_size.y + style.FramePadding.y * 2.0f);

	const ImRect bb(pos, pos + size);
	ImGui::ItemSize(size, style.FramePadding.y);
	if (!ImGui::ItemAdd(bb, id))
		return false;

	if (g.CurrentItemFlags & ImGuiItemFlags_ButtonRepeat)
		flags |= ImGuiButtonFlags_Repeat;
	bool hovered, held;
	bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held, flags);

	bool value_changed = false;
	int key = keybind->key;

	auto io = ImGui::GetIO();

	std::string name = keybind->get_key_name();

	if (keybind->waiting_for_input)
		name = "Waiting";

	if (ImGui::GetIO().MouseClicked[0] && hovered)
	{
		if (g.ActiveId == id)
		{
			keybind->waiting_for_input = true;
		}
	}
	else if (ImGui::GetIO().MouseClicked[1] && hovered)
	{
		ImGui::OpenPopup(keybind->get_name().c_str());
	}
	else if (ImGui::GetIO().MouseClicked[0] && !hovered)
	{
		if (g.ActiveId == id)
			ImGui::ClearActiveID();
	}

	if (keybind->waiting_for_input)
	{
		if (ImGui::GetIO().MouseClicked[0] && !hovered)
		{
			keybind->key = VK_LBUTTON;

			ImGui::ClearActiveID();
			keybind->waiting_for_input = false;
		}
		else
		{
			if (keybind->set_key())
			{
				ImGui::ClearActiveID();
				keybind->waiting_for_input = false;
			}
		}
	}

	// Render
	ImVec4 textcolor = ImLerp(ImVec4(201 / 255.f, 204 / 255.f, 210 / 255.f, 1.f), ImVec4(1.0f, 1.0f, 1.0f, 1.f), 1.f);

	window->DrawList->AddRectFilled(bb.Min, bb.Max, ImColor(33 / 255.0f, 33 / 255.0f, 33 / 255.0f, 1.f), 2.f);
	//window->DrawList->AddRect( bb.Min, bb.Max, ImColor( 0.f, 0.f, 0.f, 1.f ) );

	window->DrawList->AddText(
		bb.Min +
		ImVec2(
			size_arg.x / 2 - ImGui::CalcTextSize(name.c_str()).x / 2,
			size_arg.y / 2 - ImGui::CalcTextSize(name.c_str()).y / 2),
		ImGui::GetColorU32(ImGui::GetStyleColorVec4(ImGuiCol_Text)),
		name.c_str());

	ImGuiWindowFlags window_flags = ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_Popup |
		ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
		ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove |
		ImGuiWindowFlags_NoScrollbar;
	//ImGui::SetNextWindowPos( pos + ImVec2( 0, size_arg.y - 1 ) );
	//ImGui::SetNextWindowSize( ImVec2( size_arg.x, 47 * 1.f ) );

	{
		if (ImGui::BeginPopup(keybind->get_name().c_str(), 0))
		{

			{
				{
					ImGui::BeginGroup();
					{
						if (ImGui::Selectable("Hold", keybind->type == CKeybind::HOLD))
							keybind->type = CKeybind::HOLD;
						if (ImGui::Selectable("Toggle", keybind->type == CKeybind::TOGGLE))
							keybind->type = CKeybind::TOGGLE;
					}
					ImGui::EndGroup();
				}
			}

			ImGui::EndPopup();
		}
	}

	return pressed;
}
 
bool atomic::utils::overlay::fullsc(HWND windowHandle)
{
	MONITORINFO monitorInfo = { sizeof(MONITORINFO) };
	if (GetMonitorInfo(MonitorFromWindow(windowHandle, MONITOR_DEFAULTTOPRIMARY), &monitorInfo))
	{
		RECT windowRect;
		if (GetWindowRect(windowHandle, &windowRect))
		{
			return windowRect.left == monitorInfo.rcMonitor.left
				&& windowRect.right == monitorInfo.rcMonitor.right
				&& windowRect.top == monitorInfo.rcMonitor.top
				&& windowRect.bottom == monitorInfo.rcMonitor.bottom;
		}
	}
}

std::string GetConfigFolderPath()
{
	std::string configFolderPath = atomic::utils::appdata_path() + "\\atomic\\configs";

	if (!std::filesystem::exists(configFolderPath))
	{
		std::filesystem::create_directory(configFolderPath);
	}

	return configFolderPath;
}

//void DisplayInstanceTree(atomic::roblox::instance_t instance)
//{
//	for (auto& child : instance.children())
//	{
//		std::string childName = child.name();
//
//		ImGui::PushID(childName.c_str());
//		bool isNodeOpen = ImGui::TreeNodeEx(childName.c_str(), ImGuiTreeNodeFlags_OpenOnArrow);
//
//		if (ImGui::IsItemHovered() && ImGui::IsMouseReleased(1))
//		{
//			ImGui::OpenPopup("Context Menu");
//		}
//
//		if (ImGui::BeginPopup("Context Menu"))
//		{
//			if (ImGui::MenuItem("Copy Text"))
//			{
//				ImGui::SetClipboardText(childName.c_str());
//			}
//			ImGui::EndPopup();
//		}
//
//		if (isNodeOpen)
//		{
//			DisplayInstanceTree(child);
//			ImGui::TreePop();
//		}
//
//		ImGui::PopID();
//	}
//}
namespace Setup
{
	ImColor Lines = ImColor(26, 26, 26);
	ImColor NeverMissText = ImColor(138, 21, 21);
	int ChildBorderj = 1;
}
static char text[999] = "";
char configname[100];

bool atomic::utils::overlay::init = false;

bool if_first = false;

bool ButtonCenteredOnLine(const char* label, float alignment = 0.5f)
{
	ImGuiStyle& style = ImGui::GetStyle();

	float size = ImGui::CalcTextSize(label).x + style.FramePadding.x * 2.0f;
	float avail = ImGui::GetContentRegionAvail().x;

	float off = (avail - size) * alignment;
	if (off > 0.0f)
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + off);

	return ImGui::Button(label);
}


ImFont* mainfont;
ImFont* smallfont;
ImFont* iconfont;
ImFont* logofont;




inline ImFont* LexendRegular;
inline ImFont* LexendLight;

template<class T, class U>
inline static T clamp(const T& in, const U& low, const U& high)
{
	if (in <= low)
		return low;

	if (in >= high)
		return high;

	return in;
}

inline void DrawBox(float X, float Y, float W, float H, const ImU32& color, int thickness)
{
	ImGui::GetForegroundDrawList()->AddRect(ImVec2(X, Y), ImVec2(X + W, Y + H), ImGui::GetColorU32(color), thickness);
}

inline bool ImGui::Renderingtab(const char* icon, bool selected)
{
	ImGuiWindow* window = ImGui::GetCurrentWindow();
	if (window->SkipItems)
		return false;

	ImGuiContext& g = *GImGui;
	const ImGuiStyle& style = g.Style;
	const ImGuiID id = window->GetID(icon);

	ImVec2 pos = window->DC.CursorPos;
	ImVec2 size = { 35, 35 };

	const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));

	ImGui::ItemSize(size, 0);

	if (!ImGui::ItemAdd(bb, id))
		return false;

	bool hovered, held;
	bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held, NULL);

	int current_tab;

	if (hovered || held)
		ImGui::SetMouseCursor(9);

	float deltatime = 1.5f * ImGui::GetIO().DeltaTime;
	static std::map<ImGuiID, float> hover_animation;
	auto it_hover = hover_animation.find(id)
		;
	if (it_hover == hover_animation.end())
	{
		hover_animation.insert({ id, 0.f });
		it_hover = hover_animation.find(id);
	}

	it_hover->second = clamp(it_hover->second + (1.15f * ImGui::GetIO().DeltaTime * (hovered ? 1.f : -1.f)), 0.0f, 0.0f);
	it_hover->second *= ImGui::GetStyle().Alpha;

	static std::map<ImGuiID, float> filled_animation;
	auto it_filled = filled_animation.find(id);

	if (it_filled == filled_animation.end())
	{
		filled_animation.insert({ id, 0.f });
		it_filled = filled_animation.find(id);
	}

	it_filled->second = clamp(it_filled->second + (2.15f * ImGui::GetIO().DeltaTime * (selected ? 1.f : -1.5f)), it_hover->second, 1.f);
	it_filled->second *= ImGui::GetStyle().Alpha;

	ImGui::GetWindowDrawList()->AddText(ImVec2(bb.Min.x + 20, bb.Min.y + 4), ImColor(64, 64, 64, int(255 * ImGui::GetStyle().Alpha)), icon);

	if (selected)
	{
		ImGui::GetWindowDrawList()->AddText(ImVec2(bb.Min.x + 20, bb.Min.y + 4), ImColor(138, 21, 21, int(255 * it_filled->second)), icon);
		ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(bb.Min.x - 11, bb.Min.y + 8.75f), ImVec2(bb.Min.x - 7 * it_filled->second, bb.Max.y - 8.75f), ImColor(173, 171, 168, int(255 * it_filled->second)), 10.f, ImDrawCornerFlags_Right);
	}

	return pressed;
}

inline bool ImGui::Renderingsubtab(const char* icon, bool selected)
{
	ImGuiWindow* window = ImGui::GetCurrentWindow();
	if (window->SkipItems)
		return false;

	ImGuiContext& g = *GImGui;
	const ImGuiStyle& style = g.Style;
	const ImGuiID id = window->GetID(std::string(icon + std::string(icon)).c_str());
	const ImVec2 label_size = ImGui::CalcTextSize(icon);

	ImVec2 pos = window->DC.CursorPos;
	ImVec2 size = { 35, 35 };

	const ImRect bb(pos, ImVec2(pos.x + 35, pos.y + 35));
	ImGui::ItemSize(size, 50);
	if (!ImGui::ItemAdd(bb, id))
		return false;

	bool hovered, held;
	bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held, NULL);

	if (hovered || held);

	float t = selected ? 1.0f : 0.0f;
	float deltatime = 1.5f * ImGui::GetIO().DeltaTime;
	static std::map<ImGuiID, float> hover_animation;
	auto it_hover = hover_animation.find(id);
	if (it_hover == hover_animation.end())
	{
		hover_animation.insert({ id, 0.f });
		it_hover = hover_animation.find(id);
	}
	it_hover->second = ImClamp(it_hover->second + (0.2f * ImGui::GetIO().DeltaTime * (hovered || ImGui::IsItemActive() ? 1.f : -1.f)), 0.0f, 0.15f);
	it_hover->second *= min(ImGui::GetStyle().Alpha * 1.2, 1.f);

	static std::map<ImGuiID, float> filled_animation;
	auto it_filled = filled_animation.find(id);
	if (it_filled == filled_animation.end())
	{
		filled_animation.insert({ id, 0.f });
		it_filled = filled_animation.find(id);
	}
	it_filled->second = ImClamp(it_filled->second + (2.55f * ImGui::GetIO().DeltaTime * (selected ? 1.f : -1.0f)), it_hover->second, 1.f);
	it_filled->second *= min(ImGui::GetStyle().Alpha * 1.2, 1.f);

	static std::map<ImGuiID, float> fill_animation;
	auto it_fill = fill_animation.find(id);
	if (it_fill == fill_animation.end())
	{
		fill_animation.insert({ id, 0.f });
		it_fill = fill_animation.find(id);
	}
	it_fill->second = ImClamp(it_filled->second + (1.75f * ImGui::GetIO().DeltaTime * (selected ? 1.f : -1.0f)), it_hover->second, 1.f);
	it_fill->second *= min(ImGui::GetStyle().Alpha * 1.2, 1.f);

	ImVec4 text = ImLerp(ImVec4{ 128 / 255.f, 128 / 255.f, 128 / 255.f, ImGui::GetStyle().Alpha }, ImVec4{ 157 / 255.f, 176 / 255.f, 242 / 255.f, ImGui::GetStyle().Alpha }, it_filled->second);
	ImVec4 text2 = ImLerp(ImVec4{ 128 / 255.f, 128 / 255.f, 128 / 255.f, ImGui::GetStyle().Alpha }, ImVec4{ 157 / 255.f, 176 / 255.f, 242 / 255.f, ImGui::GetStyle().Alpha }, it_filled->second);

	ImGui::GetForegroundDrawList()->AddRectFilled(ImVec2(bb.Min.x + 12, bb.Max.y - it_fill->second * 5), ImVec2(bb.Min.x + 35, bb.Max.y - 1), ImColor(183, 183, 183, int(255 * it_filled->second)), 3, ImDrawCornerFlags_Top);

	ImGui::GetForegroundDrawList()->AddText(ImVec2(bb.Min.x, bb.Min.y + 8), ImColor(text), icon);

	return pressed;
}

inline int MenuTab;
inline static float switch_alpha[3], open_alpha = 0;
HWND win = NULL;


bool atomic::utils::overlay::render()
{

	ImGui_ImplWin32_EnableDpiAwareness();

	WNDCLASSEX wc;
	wc.cbClsExtra = NULL;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbWndExtra = NULL;
	wc.hbrBackground = (HBRUSH)CreateSolidBrush(RGB(0, 0, 0));
	wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
	wc.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
	wc.hIconSm = LoadIcon(nullptr, IDI_APPLICATION);
	wc.hInstance = GetModuleHandle(nullptr);
	wc.lpfnWndProc = window_proc;
	wc.lpszClassName = TEXT("atomic");
	wc.lpszMenuName = nullptr;
	wc.style = CS_VREDRAW | CS_HREDRAW;

	RegisterClassEx(&wc);
	const HWND hw = CreateWindowEx(WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE, wc.lpszClassName, TEXT("atomick"),
		WS_POPUP, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), nullptr, nullptr, wc.hInstance, nullptr); //no topmost??? 

	SetLayeredWindowAttributes(hw, 0, 255, LWA_ALPHA);
	const MARGINS margin = { -1 };
	DwmExtendFrameIntoClientArea(hw, &margin); //fps killer

	if (!create_device_d3d(hw))
	{
		cleanup_device_d3d();
		UnregisterClass(wc.lpszClassName, wc.hInstance);
		return false;
	}

	ShowWindow(hw, SW_SHOW);
	UpdateWindow(hw);

	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO(); (void)io;
	io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
	io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;

	static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };
	ImFontConfig icons_config;

	ImFontConfig CustomFont;
	CustomFont.FontDataOwnedByAtlas = false;

	icons_config.MergeMode = true;
	icons_config.PixelSnapH = true;
	icons_config.OversampleH = 2.5;
	icons_config.OversampleV = 2.5;
	ImFontConfig font_config;
	font_config.OversampleH = 1;
	font_config.OversampleV = 1;
	font_config.PixelSnapH = 1;


	static const ImWchar ranges[] =
	{
		0x0020, 0x00FF,
		0x0400, 0x044F,
		0,
	};

	ImFontConfig iconfontcfg;
	iconfontcfg.MergeMode = true;
	iconfontcfg.GlyphMaxAdvanceX = 13.0f;
	static const ImWchar icon_ranges[] = { 0xe900, 0xe909, 0 };

	medium = io.Fonts->AddFontFromMemoryTTF(PTRootUIMedium, sizeof(PTRootUIMedium), 17.0f, &font_config, ranges);  //shit ah font
	bold = io.Fonts->AddFontFromMemoryTTF(PTRootUIBold, sizeof(PTRootUIBold), 21.0f, &font_config, ranges);

	tab_icons = io.Fonts->AddFontFromMemoryTTF(clarityfont, sizeof(clarityfont), 15.0f, &font_config, ranges);
	logo = io.Fonts->AddFontFromMemoryTTF(clarityfont, sizeof(clarityfont), 21.0f, &font_config, ranges);

	tab_title = io.Fonts->AddFontFromMemoryTTF(PTRootUIBold, sizeof(PTRootUIBold), 19.0f, &font_config, ranges);
	tab_title_icon = io.Fonts->AddFontFromMemoryTTF(clarityfont, sizeof(clarityfont), 18.0f, &font_config, ranges);

	subtab_title = io.Fonts->AddFontFromMemoryTTF(PTRootUIBold, sizeof(PTRootUIBold), 15.0f, &font_config, ranges);

	combo_arrow = io.Fonts->AddFontFromMemoryTTF(combo, sizeof(combo), 9.0f, &font_config, ranges);

	SkeetFont = io.Fonts->AddFontFromMemoryTTF(ProggyCleanSkeet, sizeof(ProggyCleanSkeet), 13.5f, &font_config, ranges); //this is NOT skeet
	atomicFont = io.Fonts->AddFontFromMemoryTTF(RobotoReg, sizeof(RobotoReg), 13.5f, &font_config, ranges); //this is NOT skeet
	mainfont = io.Fonts->AddFontFromMemoryTTF(lexend, sizeof(lexend), 16.0f);
	smallfont = io.Fonts->AddFontFromMemoryTTF(lexend, sizeof(lexend), 13.0f);
	iconfont = io.Fonts->AddFontFromMemoryTTF(iconfontmem, sizeof(iconfontmem), 17.0f, &iconfontcfg, icon_ranges);
	logofont = io.Fonts->AddFontFromMemoryTTF(lexendsb, sizeof(lexendsb), 31.0f);

;

	ImGui::StyleColorsDark();
	ImGui::GetIO().IniFilename = nullptr;

	ImGui_ImplWin32_Init(hw);
	ImGui_ImplDX11_Init(d3d11_device, d3d11_device_context);

	const ImVec4 clear_color = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
	init = true;

	bool draw = true;
	bool done = false;
	int tab = 0;
	// lua env - mogus



	while (!done)
	{
		MSG msg;
		while (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
			if (msg.message == WM_QUIT)
			{
				done = true;
			}
		}

		if (done)
			break;

		move_window(hw);

		if (GetAsyncKeyState(VK_INSERT) & 1)
			draw = !draw;
		static int MenuTabs;
		ImGui_ImplDX11_NewFrame();
		ImGui_ImplWin32_NewFrame();
		ImGui::NewFrame();
		{
			if (GetForegroundWindow() == FindWindowA(0, XorStr("Roblox")) || GetForegroundWindow() == hw)
			{

				ImGui::Begin(XorStr("overlay"), nullptr, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoDecoration);
				{
					atomic::roblox::hook_esp();
					ImGui::End();
				}

				static int selected = 0;
				static int sub_selected = 0;
				if (draw) {




					ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 15.0f);
					ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
					ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f);
					ImGui::SetNextWindowSize(ImVec2(650, 450));

					ImGui::Begin("MainWindow", nullptr, ImGuiWindowFlags_NoDecoration); {

				//	auto draw = ImGui::GetWindowDrawList();
					ImVec2 pos2 = ImGui::GetWindowPos();
					ImRect win(ImVec4(pos2.x, pos2.y, pos2.x + 650, pos2.y + 450));
					
				  //  ImVec2 pos = ImGui::GetWindowPos();
					ImVec2 size = ImGui::GetWindowSize();

					//ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Once);
					//ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize, ImGuiCond_Once);

					//ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.09f, 0.09f, 0.09f, 0.40f / 1.f * 2.f));
					//static const auto flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoMove;
					//ImGui::Begin(skCrypt("##background"), nullptr, flags);
					//ImGui::End();
					//ImGui::PopStyleColor(); // ethic shit
					
						// main frame
						ImGui::GetWindowDrawList()->AddRectFilled(win.Min, win.Max, ImColor(20, 20, 20), 18.0f, NULL);
						ImGui::GetWindowDrawList()->AddRectFilled(pos2, pos2 + ImVec2(150, 450), ImColor(34, 34, 34), 15.0f, ImDrawFlags_RoundCornersLeft);
						Particles();
						ImGui::GetWindowDrawList()->AddRect(win.Min, win.Max, ImColor(65, 65, 65), 15.0f, NULL, 1.4f);
						ImGui::GetWindowDrawList()->AddLine(pos2 + ImVec2(150, 0), pos2 + ImVec2(150, 450), ImColor(65, 65, 65), 1.0f);

						//draw->AddRectFilled(win.Min + ImVec2(160, 10), win.Min + ImVec2(520, 50), ImColor(30, 30, 30), 10.0f);
						//draw->AddRect(win.Min + ImVec2(160, 10), win.Min + ImVec2(520, 50), ImColor(65, 65, 65), 10.0f);
						ImGui::SetCursorPos(ImVec2(0, 50));

						//draw->AddRectFilled(win.Min + ImVec2(530, 10), win.Min + ImVec2(640, 50), ImColor(30, 30, 30), 10.0f);
						//draw->AddRect(win.Min + ImVec2(530, 10), win.Min + ImVec2(640, 50), ImColor(65, 65, 65), 10.0f);

						//draw->AddCircle(win.Min + ImVec2(550, 30), 16.0f, ImColor(65, 65, 65), 100);
						//draw->AddCircleFilled(win.Min + ImVec2(550, 30), 16.0f, ImColor(15, 15, 15), 100);

						//draw->AddText(win.Min + ImVec2(570, 15), ImColor(155, 155, 155), "skit");
						//ImGui::PushFont(smallfont);
						//draw->AddText(win.Min + ImVec2(570, 30), ImColor(105, 105, 105), "To: Lifetime");
						//ImGui::PopFont();

						ImGui::PushFont(logofont);
						ImGui::GetWindowDrawList()->AddText(win.Min + ImVec2(20, 10), ImColor(254, 71, 165), "Intellect");
						ImGui::PopFont();

						ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(5, 0));
						ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(5, 5));
						ImGui::BeginChild("tabmenu", ImVec2(150, 400));
						{
							custom::tabchild("Aimbot", ImVec2(150, 125)); {
								if (custom::tab("General", ImVec2(135, 30), NULL, (char*)u8"\ue909", tabmenu == rageaim)) { tabmenu = rageaim; }
								if (custom::tab("Trigger", ImVec2(135, 30), NULL, (char*)u8"\ue908", tabmenu == legitaim)) { tabmenu = legitaim; }
								if (custom::tab("Flick", ImVec2(135, 30), NULL, (char*)u8"\ue907", tabmenu == antiaim)) { tabmenu = antiaim; }
							} ImGui::EndChild();
							custom::tabchild("Globals", ImVec2(150, 125)); {
								if (custom::tab("View", ImVec2(135, 30), NULL, (char*)u8"\ue906", tabmenu == view)) { tabmenu = view; }
								if (custom::tab("World", ImVec2(135, 30), NULL, (char*)u8"\ue905", tabmenu == world)) { tabmenu = world; }
								if (custom::tab("Players", ImVec2(135, 30), NULL, (char*)u8"\ue904", tabmenu == players)) { tabmenu = players; }
							} ImGui::EndChild();
							custom::tabchild("Miscellaneous", ImVec2(150, 125)); {
								if (custom::tab("Scripts", ImVec2(135, 30), NULL, (char*)u8"\ue902", tabmenu == scripts)) { tabmenu = scripts; }
								if (custom::tab("Configs", ImVec2(135, 30), NULL, (char*)u8"\ue901", tabmenu == configss)) { tabmenu = configss; }
								if (custom::tab("Settings", ImVec2(135, 30), NULL, (char*)u8"\ue900", tabmenu == settings)) { tabmenu = settings; }
							} ImGui::EndChild();

						} ImGui::EndChild();
						ImGui::PopStyleVar(2);

						/*						ImGui::SetCursorPos(ImVec2(160, 10));
												ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(15, 5));
												ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(10, 50));
												ImGui::BeginChild("subtabmenu", ImVec2(420, 40)); {

													if (custom::subtab("atomicBALS", ImVec2(75, 30), NULL, subtabmenu == atomicbals)) { subtabmenu = atomicbals; }
													if (custom::subtab("INTERNAL", ImVec2(75, 30), NULL, subtabmenu == internal)) { subtabmenu = internal; }
													if (custom::subtab("EXTERNAL", ImVec2(75, 30), NULL, subtabmenu == external)) { subtabmenu = external; }
													if (custom::subtab("SETTINGS", ImVec2(75, 30), NULL, subtabmenu == settings2)) { subtabmenu = settings2; }

												} ImGui::EndChild();
												ImGui::PopStyleVar(2)*/;

												ImGuiStyle& style = ImGui::GetStyle();
												ImVec4 originalButtonColor = style.Colors[ImGuiCol_Button];
												style.Colors[ImGuiCol_Button] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);

												ImGui::SetCursorPos(ImVec2(160, 10));
												ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(5, 5));
												ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(15, 15));
												ImGui::BeginChild("Main", ImVec2(480, 387)); {

													switch (tabmenu) {

													case rageaim: {

														switch (subtabmenu)
													case globals: {

															custom::MenuChild("Main", ImVec2(220, 375)); {

																ImGui::Checkbox(("Aimbot"), &Variables::aimbot);
																if (Variables::aimbot) {
																	ImGui::SameLine();	Keybind(&Variables::aimbotkey, ImVec2(28, 20));

																}
																ImGui::Checkbox("Deadzone", &Variables::deadzone);
																ImGui::Checkbox("Stickyaim", &Variables::sticky_aim);
																//	ImGui::Checkbox("Resolver", &Variables::resolver);
																ImGui::Checkbox(("Smoothness"), &Variables::smoothness);
																ImGui::Checkbox(("Prediction"), &Variables::prediction);

																ImGui::Checkbox(("Shake"), &Variables::shake);
																ImGui::Checkbox("Disable Out FOV", &Variables::disable_outside_fov);



															} ImGui::EndChild();
															ImGui::SetCursorPos(ImVec2(240, 5));
															custom::MenuChild("Misc", ImVec2(220, 187)); {
																double _pred_min = Variables::prediction_method == 0 ? _MIN_DIV : _MIN_MUL;
																double _pred_max = Variables::prediction_method == 0 ? _MAX_DIV : _MAX_MUL;
																if (Variables::prediction_method == 0) {
																	if (Variables::main_prediction < _MIN_DIV)
																		Variables::main_prediction = Variables::main_close_prediction = Variables::main_mid_prediction = Variables::main_far_prediction = _MIN_DIV;

																	if (Variables::prediction_x < _MIN_DIV)
																		Variables::prediction_x = Variables::close_prediction_x = Variables::mid_prediction_x = Variables::far_prediction_x = _MIN_DIV;

																	if (Variables::prediction_y < _MIN_DIV)
																		Variables::prediction_y = Variables::close_prediction_y = Variables::mid_prediction_y = Variables::far_prediction_y = _MIN_DIV;
																}
																else {
																	if (Variables::main_prediction > _MAX_MUL)
																		Variables::main_prediction = Variables::main_close_prediction = Variables::main_mid_prediction = Variables::main_far_prediction = _MAX_MUL;

																	if (Variables::prediction_x > _MAX_MUL)
																		Variables::prediction_x = Variables::close_prediction_x = Variables::mid_prediction_x = Variables::far_prediction_x = _MAX_MUL;

																	if (Variables::prediction_y > _MAX_MUL)
																		Variables::prediction_y = Variables::close_prediction_y = Variables::mid_prediction_y = Variables::far_prediction_y = _MAX_MUL;
																}

																ImGui::SliderInt("FOV", &Variables::fov, 0, 360);
																if (Variables::deadzone) {
																	ImGui::SliderInt("Deadzone", &Variables::deadzone_value, 1, 1000, "%d%%");

																}
																if (Variables::distpred) {
																	ImGui::SliderFloat("Close Distance", &Variables::CloseDistance, 1.00f, 100.00f, "%.1f");

																	if (Variables::separate_predictions) {
																		ImGui::SliderFloat("Close Prediction X", &Variables::close_prediction_x, _pred_min, _pred_max, "%.0005f");
																		ImGui::SliderFloat("Close Prediction Y", &Variables::close_prediction_y, _pred_min, _pred_max, "%.0005f");
																	}
																	else {
																		ImGui::SliderFloat("Close Prediction", &Variables::main_close_prediction, _pred_min, _pred_max, "%.0005f");
																	}

																	ImGui::Separator();
																	ImGui::SliderFloat("Mid Distance", &Variables::MidDistance, 1.00f, 100.00f, "%.1f");

																	if (Variables::separate_predictions) {
																		ImGui::SliderFloat("Mid Prediction X", &Variables::mid_prediction_x, _pred_min, _pred_max, "%.0005f");
																		ImGui::SliderFloat("Mid Prediction Y", &Variables::mid_prediction_y, _pred_min, _pred_max, "%.0005f");
																	}
																	else {
																		ImGui::SliderFloat("Mid Prediction", &Variables::main_mid_prediction, _pred_min, _pred_max, "%.0005f");
																	}


																	if (Variables::separate_predictions) {
																		ImGui::SliderFloat("Far Prediction X", &Variables::far_prediction_x, _pred_min, _pred_max, "%.0005f");
																		ImGui::SliderFloat("Far Prediction Y", &Variables::far_prediction_y, _pred_min, _pred_max, "%.0005f");
																	}
																	else {
																		ImGui::SliderFloat("Far Prediction", &Variables::main_far_prediction, _pred_min, _pred_max, "%.0005f");
																	}
																}
																else {
																	ImGui::SliderFloat("Smoothness X", &Variables::smoothness_x, 1.0, 100, "%.1f");
																	ImGui::SliderFloat("Smoothness Y", &Variables::smoothness_y, 1.0, 30.0, "%.1f");
																	//	Variables::smoothness_y = Variables::smoothness_x;
																}
																if (Variables::smoothness) {
																	if (Variables::smooth_type == 1) {
																		ImGui::SetCursorPosX({ 15 });
																		ImGui::SliderFloat("Frequency", &Variables::bounce_frequency, 0.01, 30.0, "%.1f");
																		ImGui::SetCursorPosX({ 15 });
																		ImGui::SliderFloat("Decay", &Variables::bounce_decay, 0.01, 10.0, "%.1f");
																	}
																	if (Variables::smooth_type == 2) {
																		ImGui::SliderFloat("Frequency", &Variables::elactic_frequency, 0.01, 30.0, "%.1f");
																		ImGui::SliderFloat("Decay", &Variables::elactic_decay, 0.01, 10.0, "%.1f");
																	}
																	if (Variables::smooth_type == 4) {
																		ImGui::SliderFloat("Decay", &Variables::decay, 0.01, 10.0, "%.1f");
																	}
																}

																if (Variables::prediction) {
																	ImGui::SliderFloat(XorStr("Prediction X"), &Variables::prediction_x, 1, 10);
																	ImGui::SliderFloat(XorStr("Prediction Y"), &Variables::prediction_y, 1, 10);
																}


															}



														} ImGui::EndChild();
														ImGui::SetCursorPos(ImVec2(240, 215));
														custom::MenuChild("Misc 2", ImVec2(220, 190)); {
															ImGui::Combo("Aim Method", &Variables::aimtype, combo_items_2, IM_ARRAYSIZE(combo_items_2)); \
																ImGui::Combo("Aim Part", &Variables::aimpart, combo_items_4, IM_ARRAYSIZE(combo_items_4)); \
															// looks like santo paste	ImGui::Combo("Smooth", &Variables::smooth_type, smooth_typessex, IM_ARRAYSIZE(smooth_typessex), 5);
															ImGui::Combo("Prediction", &Variables::prediction_method, prediction_methods, IM_ARRAYSIZE(prediction_methods), 5);



														} ImGui::EndChild();

													}
																break;

													case legitaim:
													{
														custom::MenuChild("TriggerBot", ImVec2(220, 190)); {
															ImGui::Checkbox(XorStr("Enable Triggerbot"), &Variables::triggerbot);
															ImGui::SameLine();
															Keybind(&Variables::triggerbotkey, ImVec2(35, 25));
															ImGui::SliderInt(XorStr("Triggerbot Delay"), &Variables::triggerbot_delay_ms, 100, 500);

														}
													} ImGui::EndChild();
													break;

													case view:
													{
														//ImGui::SetCursorPos(ImVec2(160, 10));
														custom::MenuChild("Main", ImVec2(220, 375)); {

															ImGui::Checkbox("Master Switch", &Variables::esp);
															if (Variables::esp) {
																ImGui::Checkbox("Enable Box", &Variables::box);
															//	ImGui::Checkbox("Enable Armor Info", &Variables::armorbar);
															//	ImGui::Checkbox("Enable Chams", &Variables::chams);
																ImGui::Checkbox("Enable Dot", &Variables::dotesp);
																ImGui::Checkbox("Enable Head Dot", &Variables::head_dot);
																ImGui::Checkbox("Enable Skeleton", &Variables::skeleton);
														//		ImGui::Checkbox("Enable Distance", &Variables::distance_esp);
																ImGui::Checkbox("Enable Tracers", &Variables::tracers);
																ImGui::Checkbox("Enable Filled", &Variables::filledbox);
																ImGui::Checkbox("Enable Outline", &Variables::outline);
																ImGui::Checkbox("Enable HealthBar", &Variables::healthbar);
																ImGui::Checkbox("Enable Radar", &Variables::radar);
																//ImGui::Checkbox("Enable Floor Circle", &Variables::threeCircle);
																ImGui::Checkbox("Draw FOV", &Variables::fov_on);

															}

														} ImGui::EndChild();

														ImGui::SetCursorPos(ImVec2(230, 10));
														custom::MenuChild("Misc", ImVec2(220, 187)); {
															ImGui::Combo("Box Type", &Variables::boxtype, box_items_3, IM_ARRAYSIZE(box_items_3), 5);
													//		ImGui::Combo("Box Type", &Variables::fovtype, box_items_3, IM_ARRAYSIZE(box_items_3), 5);

														} ImGui::EndChild();

														ImGui::SetCursorPos(ImVec2(240, 215));
														custom::MenuChild("Colors", ImVec2(220, 190)); {
															ImGui::ColorEdit4("Box Color", Variables::box_color, ImGuiColorEditFlags_NoInputs);
															ImGui::Separator();
															//	ImGui::ColorEdit4("Name Color", Variables::name_color, ImGuiColorEditFlags_NoInputs);
															ImGui::ColorEdit4("Tracers Color", Variables::tracers_color, ImGuiColorEditFlags_NoInputs);
															ImGui::Separator();
															ImGui::ColorEdit4("FOV Color", Variables::fov_color, ImGuiColorEditFlags_NoInputs);


														} ImGui::EndChild();
														break;

													case world:
													{
														custom::MenuChild("Modifiers", ImVec2(220, 350)); {
													//		ImGui::Checkbox("Spinbot", &Variables::orbit);
														/*	ImGui::PushFont(SkeetFont);

															ImGui::Text("Shiftlock while using.");

															ImGui::PopFont();*/

														//	ImGui::Combo("CSpeed Type", &Variables::cframetype, cframetypes, IM_ARRAYSIZE(cframetypes), 2);
															ImGui::Checkbox(("SpinBot Wip"), &Variables::orbit);
															if (Variables::cframetype == 0) {
																ImGui::Checkbox("CFrame WalkSpeed", &Variables::cframe);

																ImGui::SameLine();
																Keybind(&Variables::cspeedkey, ImVec2(25, 20));

																if (Variables::cframedh && Variables::cframetype == 0)
																{
																	Variables::cframedh = false;
																	Variables::cframe = true;
																}
															}


															if (Variables::cframetype == 1)
															{
																ImGui::Checkbox("CFrame WalkSpeed", &Variables::cframedh);
																ImGui::SameLine();
																Keybind(&Variables::cspeedkey, ImVec2(25, 20));
																// pro check
																if (Variables::cframe && Variables::cframetype == 1)
																{
																	Variables::cframe = false;
																	Variables::cframedh = true;
																}
															}
															ImGui::Checkbox("CFly", &Variables::Fly);
															ImGui::SameLine();
															Keybind(&Variables::flykey, ImVec2(23, 20));
															static bool setfov;

															ImGui::Checkbox("Set CamFov", &setfov);

															ImGui::SliderFloat("CFrame Speed Value", &Variables::cframespeed, 1, 60);
															ImGui::SliderFloat("CFlySpeed Value", &Variables::flyspeed, 1, 60);
															ImGui::SliderFloat("Camera FOV", &Variables::camerafov, 1, 120);
															if (setfov)
															{
																atomic::roblox::instance_t instance = {};
																instance.set_humanoid_fov(Variables::camerafov);
																Sleep(800);
																setfov = false;
															}
															static bool resetfov;
															if (resetfov) {
																atomic::roblox::instance_t instance = {};
																instance.set_humanoid_fov(70);
																Sleep(1000);
																resetfov = false;
															}


														} ImGui::EndChild();

														ImGui::SetCursorPos(ImVec2(240, 5));
														custom::MenuChild("WayPoints", ImVec2(220, 240)); {
															if (ImGui::Button("Downhill Guns")) {
																atomic::roblox::vector3_t downhillPos = { -557.931f, 7.99787f, -736.214f };
																Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").set_part_pos(downhillPos);
															}

															if (ImGui::Button("Downhill Armor")) {
																atomic::roblox::vector3_t downhillarmorPos = { -601.934f, 10.3477f, -799.352f };
																Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").set_part_pos(downhillarmorPos);
															}

															if (ImGui::Button("Playground")) {
																atomic::roblox::vector3_t playground = { -281.674f, 21.753f, -792.597f };
																Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").set_part_pos(playground);
															}

															if (ImGui::Button("DB")) {
																atomic::roblox::vector3_t doublebarrel = { -1043.85f, 21.748f, -267.5f };
																Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").set_part_pos(doublebarrel);
															}

															if (ImGui::Button("Fitness")) {
																atomic::roblox::vector3_t hoodfitness = { -75.6585f, 21.753f, -591.347f };
																Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").set_part_pos(hoodfitness);
															}

															if (ImGui::Button("MilBase")) {
																atomic::roblox::vector3_t military = { 33.7677f, 25.253f, -878.813f };
																Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").set_part_pos(military);
															}

															if (ImGui::Button("Rev")) {
																atomic::roblox::vector3_t revovler = { -639.346f, 21.748f, -128.717f };
																Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").set_part_pos(revovler);
															}

															if (ImGui::Button("Uphill Guns")) {
																atomic::roblox::vector3_t uphillguns = { 482.954f, 48.003f, -593.807f };
																Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").set_part_pos(uphillguns);
															}

															if (ImGui::Button("Taco")) {
																atomic::roblox::vector3_t taco = { 553.737f, 51.0594f, -491.687f };
																Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").set_part_pos(taco);
															}

															if (ImGui::Button("Uphill Armor")) {
																atomic::roblox::vector3_t uphillarmor = { 534.519f, 50.3112f, -631.324f };
																Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").set_part_pos(uphillarmor);
															}

															if (ImGui::Button("Shop")) {
																atomic::roblox::vector3_t shop = { -356.475f, 21.6913f, -298.119f };
																Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").set_part_pos(shop);
															}

															if (ImGui::Button("Bank")) {
																atomic::roblox::vector3_t bank = { -405.635f, 21.748f, -285.138f };
																Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").set_part_pos(bank);
															}

															if (ImGui::Button("Uphill Armor WareHouse")) {
																atomic::roblox::vector3_t uphillarmor2 = { 410.595f, 48.025f, -47.4474f };
																Variables::players.get_local_player().get_model_instance().find_first_child("HumanoidRootPart").set_part_pos(uphillarmor2);
															}
														}
													} ImGui::EndChild();

													/*	ImGui::SetCursorPos(ImVec2(1, 215));
														custom::MenuChild("Da Hood Modifiers", ImVec2(230, 187)); {

													ImGui::Checkbox("CFrame WalkSpeed DH", &Variables::cframedh);

													} ImGui::EndChild();*/
													break;


													case players:
													{

														ImGui::Separator();


														//auto Players = Variables::workspace.children();
														auto Players = Variables::playerslocation.children();
														for (auto& player : Players)
														{ 
															std::string playerName = player.name();

															if (player.name() == "Camera")
																continue;

															if (player.name() == "Terrain")
																continue;

															if (player.name() == "Baseplate")
																continue;

															if (player.name() == "Cage")
																continue;

															if (player.name() == "Spawns")
																continue;

															if (ImGui::Button(playerName.c_str()))
															{
																Variables::selectedplayer = playerName;
															}
														}

														ImGui::Separator();

														std::string spectatestr = "Spectate " + Variables::selectedplayer; // player name here

														if (ImGui::Button(spectatestr.c_str()))
														{
															atomic::roblox::instance_t instance;
															instance.Spectate(Variables::selectedplayer);
														}

														if (ImGui::Button("Unspectate")) {
															atomic::roblox::instance_t instance = {};
															instance.UnSpectate();
														}
														//OpenGameExplorer();
													}
													break;
													}

													case configss:
													{
														custom::MenuChild("Configuration", ImVec2(275, 375)); {
															std::vector<std::string> configFiles;
															std::string configFolderPath = atomic::utils::appdata_path() + "\\intellect\\configs";
															for (auto file : std::filesystem::directory_iterator(configFolderPath)) {
																std::filesystem::path filePath = file;
																std::string extension = filePath.extension().string();

																if (extension == ".cfg") {
																	if (!std::filesystem::is_directory(file.path())) {
																		auto path2 = file.path().string().substr(configFolderPath.length() + 1);
																		configFiles.push_back(path2.c_str());
																	}
																}
															}

															static std::string current_item = configFiles.empty() ? "" : configFiles[0];

															for (int n = 0; n < configFiles.size(); n++) {
																if (configFiles[n] == "")
																	continue;

																bool is_selected = (current_item == configFiles[n]);
																if (ImGui::Selectable(configFiles[n].c_str(), is_selected)) {
																	current_item = configFiles[n];

																	size_t extensionPos = current_item.find(".cfg");
																	if (extensionPos != std::string::npos) {
																		current_item.erase(extensionPos);
																	}

																	strncpy(configname, current_item.c_str(), IM_ARRAYSIZE(configname));
																}
															}

															ImGui::InputText(XorStr("Config Name"), configname, IM_ARRAYSIZE(configname));
															if (ImGui::Button(XorStr("Load"))) {
																atomic::utils::configs::load(configname);
															}

															ImGui::SameLine();

															if (ImGui::Button(XorStr("Save"))) {
																atomic::utils::configs::save(configname);
															}

															ImGui::SameLine();

															if (ImGui::Button(XorStr("Open Folder Location")))
															{
																ShellExecute(NULL, "open", "explorer.exe", (atomic::utils::appdata_path() + "\\intellect\\configs").c_str(), NULL, SW_SHOWNORMAL);
															}
														}
														break;

													case settings:
													{
														custom::MenuChild("Settings", ImVec2(275, 375)); {
															ImGui::Checkbox("V-Sync", &Variables::vsync);
															if (ImGui::Button("Exit")) {
																exit(0);
															}
															if (ImGui::Button("Show Console")) {
																ShowWindow(GetConsoleWindow(), SW_SHOW);
															}
															if (ImGui::Button("Hide Console")) {
																ShowWindow(GetConsoleWindow(), SW_HIDE);
															}

														}
													}
													}
													}



												} ImGui::EndChild();
												ImGui::PopStyleVar(2);

												ImGui::PopStyleVar(3);
					} ImGui::End();
					// Menu End
				}
						
}
				if (Variables::streamproof)
				{
					SetWindowDisplayAffinity(hw, WDA_EXCLUDEFROMCAPTURE);
				}
				else
				{
					SetWindowDisplayAffinity(hw, WDA_NONE);
				}

				if (draw)
				{
					SetWindowLong(hw, GWL_EXSTYLE, WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW);
				}
				else
				{
					SetWindowLong(hw, GWL_EXSTYLE, WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_TOOLWINDOW);
				}

				ImGui::EndFrame();
				ImGui::Render();

				const float clear_color_with_alpha[4] = { clear_color.x * clear_color.w, clear_color.y * clear_color.w, clear_color.z * clear_color.w, clear_color.w };
				d3d11_device_context->OMSetRenderTargets(1, &d3d11_render_target_view, nullptr);
				d3d11_device_context->ClearRenderTargetView(d3d11_render_target_view, clear_color_with_alpha);
				ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

				if (Variables::vsync)
				{
					dxgi_swap_chain->Present(1, 0);
				}
				else
				{
					dxgi_swap_chain->Present(0, 0);

				}
		}
		}
	

	init = false;

	ImGui_ImplDX11_Shutdown();
	ImGui_ImplWin32_Shutdown();
	ImGui::DestroyContext();

	cleanup_device_d3d();
	DestroyWindow(hw);
	UnregisterClass(wc.lpszClassName, wc.hInstance);
}


void atomic::utils::overlay::move_window(HWND hw)
{

	HWND target = FindWindowA(0, XorStr("Roblox"));
	HWND foregroundWindow = GetForegroundWindow();
	if (target != foregroundWindow && hw != foregroundWindow)
	{
		MoveWindow(hw, 0, 0, 0, 0, true);
	}
	else
	{
		RECT rect;
		GetWindowRect(target, &rect);

		int rsize_x = rect.right - rect.left;
		int rsize_y = rect.bottom - rect.top;

		if (fullsc(target))
		{
			rsize_x += 16;
			rsize_y -= 24;
		}
		else
		{
			rsize_y -= 63;
			rect.left += 8;
			rect.top += 31;
		}

		MoveWindow(hw, rect.left, rect.top, rsize_x, rsize_y, TRUE);
	}
}

bool atomic::utils::overlay::create_device_d3d(HWND hw)
{
	DXGI_SWAP_CHAIN_DESC sd;
	ZeroMemory(&sd, sizeof(sd));
	sd.BufferCount = 2;
	sd.BufferDesc.Width = 0;
	sd.BufferDesc.Height = 0;
	sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	sd.BufferDesc.RefreshRate.Numerator = 60;
	sd.BufferDesc.RefreshRate.Denominator = 1;
	sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
	sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	sd.OutputWindow = hw;
	sd.SampleDesc.Count = 1;
	sd.SampleDesc.Quality = 0;
	sd.Windowed = TRUE;
	sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

	const UINT create_device_flags = 0;
	D3D_FEATURE_LEVEL d3d_feature_level;
	const D3D_FEATURE_LEVEL feature_level_arr[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
	HRESULT res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, create_device_flags, feature_level_arr, 2, D3D11_SDK_VERSION, &sd, &dxgi_swap_chain, &d3d11_device, &d3d_feature_level, &d3d11_device_context);
	if (res == DXGI_ERROR_UNSUPPORTED)
		res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, create_device_flags, feature_level_arr, 2, D3D11_SDK_VERSION, &sd, &dxgi_swap_chain, &d3d11_device, &d3d_feature_level, &d3d11_device_context);
	if (res != S_OK)
		return false;

	create_render_target();
	return true;
}

void atomic::utils::overlay::cleanup_device_d3d()
{
	cleanup_render_target();

	if (dxgi_swap_chain)
	{
		dxgi_swap_chain->Release();
		dxgi_swap_chain = nullptr;
	}

	if (d3d11_device_context)
	{
		d3d11_device_context->Release();
		d3d11_device_context = nullptr;
	}

	if (d3d11_device)
	{
		d3d11_device->Release();
		d3d11_device = nullptr;
	}
}

void atomic::utils::overlay::create_render_target()
{
	ID3D11Texture2D* d3d11_back_buffer;
	dxgi_swap_chain->GetBuffer(0, IID_PPV_ARGS(&d3d11_back_buffer));
	if (d3d11_back_buffer != nullptr)
	{
		d3d11_device->CreateRenderTargetView(d3d11_back_buffer, nullptr, &d3d11_render_target_view);
		d3d11_back_buffer->Release();
	}
}

void atomic::utils::overlay::cleanup_render_target()
{
	if (d3d11_render_target_view)
	{
		d3d11_render_target_view->Release();
		d3d11_render_target_view = nullptr;
	}
}

LRESULT __stdcall atomic::utils::overlay::window_proc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
		return true;

	switch (msg)
	{
	case WM_SIZE:
		if (d3d11_device != nullptr && wParam != SIZE_MINIMIZED)
		{
			cleanup_render_target();
			dxgi_swap_chain->ResizeBuffers(0, (UINT)LOWORD(lParam), (UINT)HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0);
			create_render_target();
		}
		return 0;

	case WM_SYSCOMMAND:
		if ((wParam & 0xfff0) == SC_KEYMENU)
			return 0;
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;

	default:
		break;
	}
	return DefWindowProc(hWnd, msg, wParam, lParam);
}
