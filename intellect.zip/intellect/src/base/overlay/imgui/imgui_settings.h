#include "imgui.h"

namespace c
{

    inline ImVec4 accent = ImColor(161, 210, 255);

    namespace bg
    {
        inline ImVec4 background = ImColor(0, 0, 0, 123);
        inline ImVec4 lines = ImColor(34, 37, 47, 255);
        inline ImVec2 size = ImVec2(960, 750);
        inline float rounding = 16.f;
    }

    namespace child
    {
        inline ImVec4 background = ImColor(0, 0, 0, 50);
        inline ImVec4 lines = ImColor(34, 37, 47, 255);
        inline float rounding = 8.f;
    }

    namespace checkbox
    {
        inline ImVec4 background = ImColor(0, 0, 0, 50);
        inline ImVec4 outline = ImColor(34, 37, 47, 255);
        inline ImVec4 circle = ImColor(34, 37, 47, 255);
    }

    namespace button
    {
        inline ImVec4 background = ImColor(0, 0, 0, 50);
        inline ImVec4 outline = ImColor(34, 37, 47, 255);
        inline float rounding = 3.f;
    }

    namespace slider
    {
        inline ImVec4 background = ImColor(52, 58, 69, 255);
        inline float rounding = 3.f;
    }

    namespace input
    {
        inline ImVec4 background = ImColor(0, 0, 0, 50);
        inline ImVec4 outline = ImColor(34, 37, 47, 255);
        inline float rounding = 3.f;
    }

    namespace combo
    {
        inline ImVec4 background = ImColor(0, 0, 0, 50);
        inline ImVec4 outline = ImColor(34, 37, 47, 255);
        inline ImVec4 list = ImColor(15, 16, 17, 225);
        inline float rounding = 3.f;
    }

    namespace keybind
    {
        inline ImVec4 background = ImColor(0, 0, 0, 50);
        inline ImVec4 outline = ImColor(34, 37, 47, 255);
        inline float rounding = 3.f;
    }

    namespace picker
    {
        inline ImVec4 background = ImColor(0, 0, 0, 200);
        inline ImVec4 outline = ImColor(34, 37, 47, 255);
        inline float rounding = 3.f;
    }

    namespace tab
    {
        inline float rounding = 6.f;
    }

    namespace text
    {
        inline ImVec4 text_active = ImColor(255, 255, 255, 255);
        inline ImVec4 text_hov = ImColor(96, 105, 122, 255);
        inline ImVec4 text = ImColor(120, 128, 145, 255); // Increased RGB values


    }

}