#pragma once
#include <Windows.h>
#include <iostream>
#include <vector>
#include <TlHelp32.h>
#include <stdio.h>
#include <string_view>
#include <chrono>
#include <wtypes.h>
#include <dwmapi.h>
#include <cstdint>
#include <thread>
#include "json.hpp"
#include <random>
#include "protection/encryption/string/xor.h"
using namespace KeyAuth;




auto name = _("mov, rax"); // Application Name
auto ownerid = _("SWhiNSeijg"); // Owner ID
auto secret = _("1bcdd9a0330f42e3aea8f8151b48ac0d0402190b7810195908d70643245f403c"); // Application Secret
auto version = _("1.1"); // Application Version
auto url = _("https://keyauth.win/api/1.2/"); // change if you're self-hosting

api KeyAuthApp(name, ownerid, secret, version, url);
using json = nlohmann::json;
std::string tempFolderPath = std::getenv(_("TEMP"));
std::string tm_to_readable_time(tm ctx) {
    char buffer[80];

    strftime(buffer, sizeof(buffer), _("%a %m/%d/%y %H:%M:%S %Z"), &ctx);

    return std::string(buffer);
}
std::string Random(size_t length)
{
    std::string result;
    static const std::string chars = _("ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmopqrstuvxyz123456890");
    srand((unsigned)time(0));

    for (size_t i = 0; i < length; i++)
        result += chars[rand() % chars.length()];

    return result;
}
auto RandomName() -> void
{
    std::string NAME = (std::string)(Random(15));
    SetConsoleTitleA(NAME.c_str());
}
auto ChangeName(LPVOID in) -> DWORD
{
    while (true)
    {
        RandomName();
    }
}
static std::time_t string_to_timet(std::string timestamp) {
    auto cv = strtol(timestamp.c_str(), NULL, 10); // long

    return (time_t)cv;
}

static std::tm timet_to_tm(time_t timestamp) {
    std::tm context;

    localtime_s(&context, &timestamp);

    return context;
}




void ClearTempFolder()
{
    WIN32_FIND_DATAA findData;
    HANDLE hFind = FindFirstFileA((tempFolderPath + _("\\*")).c_str(), &findData);

    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            if (!(findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
                std::string filePath = tempFolderPath + _("\\") + findData.cFileName;
                if (DeleteFileA(filePath.c_str())) {
                    //std::cout << "Deleted file: " << filePath << std::endl;
                }
                else {
                    //std::cout << "Failed to delete file: " << filePath << std::endl;
                }
            }
        } while (FindNextFileA(hFind, &findData));
        FindClose(hFind);
    }
}


std::string generateRandomSymbols(int length) {
    std::string symbols = _("abcdefghijklmnopqrstuvwxyz0123456789");
    std::random_device rd;
    std::mt19937 generator(rd());
    std::uniform_int_distribution<int> distribution(0, symbols.size() - 1);

    std::string randomString;
    for (int i = 0; i < length; ++i) {
        randomString += symbols[distribution(generator)];
    }

    return randomString;
}

auto get_folder() -> std::string
{
    char* pbuf = nullptr;
    size_t len = 0;
    if (!_dupenv_s(&pbuf, &len, _("appdata")) && pbuf && strnlen_s(pbuf, MAX_PATH))
    {
        std::string settings_path;
        settings_path.append(pbuf);
        settings_path.append(_("\\Atomic\\"));
        CreateDirectory(settings_path.c_str(), 0);
        settings_path.append(_("\\Public"));
        CreateDirectory(settings_path.c_str(), 0);
        free(pbuf);
        return settings_path;
    }
}
auto get_key() -> std::string {
    return get_folder() + _("\\key.json");
}
std::string key;
std::string username;
std::string password;
auto auth() -> void
{

    KeyAuthApp.init();
    if (!KeyAuthApp.data.success)
    {
        std::cout << _("\n Status: ") << KeyAuthApp.data.message;
        Sleep(1500);
        exit(0);
    }

    if (std::filesystem::exists(get_key()))
    {
        if (!CheckIfJsonKeyExists(get_key(), _("username")))
        {
            key = ReadFromJson(get_key(), _("license"));
            KeyAuthApp.license(key);
            if (!KeyAuthApp.data.success)
            {
                std::remove(get_key().c_str());
                std::cout << _("\n Status: ") << KeyAuthApp.data.message;
                Sleep(1500);
                exit(0);
            }
            std::cout << _("\n\n Successfully Automatically Logged In\n");
        }
        else
        {
            username = ReadFromJson(get_key(), _("username"));
            password = ReadFromJson(get_key(), _("password"));
            KeyAuthApp.login(username, password);
            if (!KeyAuthApp.data.success)
            {
                std::remove(get_key().c_str());
                std::cout << _("\n Status: ") << KeyAuthApp.data.message;
                Sleep(1500);
                exit(0);
            }
            std::string message = _("logged in at ") + tm_to_readable_time(timet_to_tm(string_to_timet(KeyAuthApp.data.lastlogin))) + _("\nHWID: ") + KeyAuthApp.data.hwid + _("\n");
            KeyAuthApp.log(message);
            //KeyAuthApp.webhook("sQYPwBV8Y0", "burmalda");
            std::cout << _("\n\n Successfully Automatically Logged In\n");
        }
    }
    else
    {
        std::cout << _("\n\n [1] Login\n [2] Register\n [3] License key only\n\n Choose option: ");

        int option;
        std::string username;
        std::string password;
        std::string key;

        std::cin >> option;
        switch (option)
        {
        case 1:
            std::cout << _("\n\n Enter username: ");
            std::cin >> username;
            std::cout << _("\n Enter password: ");
            std::cin >> password;
            KeyAuthApp.login(username, password);
            break;
        case 2:
            std::cout << _("\n\n Enter username: ");
            std::cin >> username;
            std::cout << _("\n Enter password: ");
            std::cin >> password;
            std::cout << _("\n Enter license: ");
            std::cin >> key;
            KeyAuthApp.regstr(username, password, key);
            break;
        case 3:
            std::cout << _("\n Enter license: ");
            std::cin >> key;
            KeyAuthApp.license(key);
            break;
        default:
            std::cout << _("\n\n Status: Failure: Invalid Selection");
            Sleep(3000);
            exit(0);
        }

        if (!KeyAuthApp.data.success)
        {
            std::cout << _("\n Status: ") << KeyAuthApp.data.message;
            Sleep(1500);
            exit(0);
        }
        if (username.empty() || password.empty())
        {
            WriteToJson(get_key(), _("license"), key, false, _(""), _(""));
            std::cout << _("\n Successfully Created File For Auto Login\n");
        }
        else
        {
            WriteToJson(get_key(), _("username"), username, true, _("password"), password);
            std::cout << _("\n Successfully Created File For Auto Login\n");
        }
        std::string message = _("logged in at ") + tm_to_readable_time(timet_to_tm(string_to_timet(KeyAuthApp.data.lastlogin))) + _("\nHWID: ") + KeyAuthApp.data.hwid + _("\n");
        // KeyAuthApp.webhook("sQYPwBV8Y0", "burmalda");
        KeyAuthApp.log(message);

    }
    Sleep(2000);



}

auto newname = generateRandomSymbols(10);

