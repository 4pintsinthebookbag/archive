#pragma once

#include <windows.h>
#include <tlhelp32.h>
#include <iostream>

namespace atomic
{
    int rblxprocid();
}
