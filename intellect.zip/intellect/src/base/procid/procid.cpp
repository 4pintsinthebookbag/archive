#include "procid.hpp"

int atomic::rblxprocid() {
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        return -1;
    }

    PROCESSENTRY32 processEntry;
    processEntry.dwSize = sizeof(PROCESSENTRY32);

    const wchar_t targetProcessName[] = L"RobloxPlayerBeta.exe";

    if (Process32First(hSnapshot, &processEntry)) {
        do {
            wchar_t processNameWide[MAX_PATH];
            MultiByteToWideChar(CP_ACP, 0, processEntry.szExeFile, -1, processNameWide, MAX_PATH);

            if (wcscmp(processNameWide, targetProcessName) == 0) {
                int pid = processEntry.th32ProcessID;
                CloseHandle(hSnapshot);
                return pid;
            }
        } while (Process32Next(hSnapshot, &processEntry));
    }

    CloseHandle(hSnapshot);
    return -1;
}