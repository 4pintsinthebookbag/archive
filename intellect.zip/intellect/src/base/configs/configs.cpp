#include "configs.hpp"
#include <iostream>
#include <fstream>
#include "../../game/Variables/Variables.hpp"
// #include "../json/json.hpp"
#include <ShlObj.h>
#include <sstream> // 4 stringstream

//using namespace nlohmann;

void saveFile(const std::string& filePath, const std::string& data) {
    std::ofstream outFile(filePath);
    if (outFile.is_open()) {
        outFile << data;
        outFile.close();
    }
}

void loadFile(const std::string& filePath, std::string& data) {
    std::ifstream inFile(filePath);
    if (inFile.is_open()) {
        std::string line;
        while (std::getline(inFile, line)) {
            data += line + "\n";
        }
        inFile.close();
    }
}

void atomic::utils::configs::save(const char* name) {
    std::string config;

    config += "aimbot-enabled = \"" + std::to_string(Variables::aimbot) + "\";\n";
    config += "trigger-enabled = \"" + std::to_string(Variables::triggerbot) + "\";\n";
    config += "aimbot-smoothing_x = \"" + std::to_string(Variables::smoothness_x) + "\";\n";
    config += "aimbot-smoothing_Y = \"" + std::to_string(Variables::smoothness_y) + "\";\n";
    config += "trigger-delay = \"" + std::to_string(Variables::triggerbot_delay_ms) + "\";\n";
    config += "aimbot-sensitivity = \"" + std::to_string(Variables::sensitivity) + "\";\n";
    config += "aimbot-bind = \"" + std::to_string(Variables::aimbotkey.key) + "\";\n";
    config += "trigger-bind = \"" + std::to_string(Variables::triggerbotkey.key) + "\";\n";
    config += "aimbot-bind-mode = \"" + std::to_string(Variables::aimbotkey.type) + "\";\n";
    config += "trigger-bind-mode = \"" + std::to_string(Variables::triggerbotkey.type) + "\";\n";
    config += "aimbot-part = \"" + std::to_string(Variables::aimpart) + "\";\n";
    config += "streamproof = \"" + std::to_string(Variables::streamproof) + "\";\n";
    config += "v-sync = \"" + std::to_string(Variables::vsync) + "\";\n";
    config += "show_name = \"" + std::to_string(Variables::name_esp) + "\";\n";
    config += "show_boxes = \"" + std::to_string(Variables::box) + "\";\n";
    config += "show_fov = \"" + std::to_string(Variables::fov_on) + "\";\n";
    config += "show_tracers = \"" + std::to_string(Variables::tracers) + "\";\n";
    config += "prediction = \"" + std::to_string(Variables::prediction) + "\";\n";
    config += "smoothness_enabled = \"" + std::to_string(Variables::smoothness) + "\";\n";
    config += "stickyaim = \"" + std::to_string(Variables::sticky_aim) + "\";\n";
    config += "cframe = \"" + std::to_string(Variables::cframe) + "\";\n";
    config += "cframedh = \"" + std::to_string(Variables::cframedh) + "\";\n";
    config += "teamcheck = \"" + std::to_string(Variables::team_check) + "\";\n";
    config += "knockcheck = \"" + std::to_string(Variables::knock_check) + "\";\n";
    config += "aimbot-fov = \"" + std::to_string(Variables::fov) + "\";\n";
    config += "aimbot-type = \"" + std::to_string(Variables::aimtype) + "\";\n";
    config += "pred_x = \"" + std::to_string(Variables::prediction_x) + "\";\n";
    config += "pred_y = \"" + std::to_string(Variables::prediction_y) + "\";\n";

    saveFile(appdata_path() + "\\intellect\\configs\\" + static_cast<std::string>(name) + ".cfg", config);
}

void atomic::utils::configs::load(const char* name) {
    std::string configData;
    loadFile(appdata_path() + "\\intellect\\configs\\" + static_cast<std::string>(name) + ".cfg", configData);

    if (configData.empty()) return;

    std::stringstream configStream(configData);
    std::string line;
    while (std::getline(configStream, line)) {
        std::size_t delimiterPos = line.find(" = \"");
        if (delimiterPos == std::string::npos) continue;

        std::string key = line.substr(0, delimiterPos);
        std::string value = line.substr(delimiterPos + 4, line.length() - delimiterPos - 5);

        if (key == "aimbot-enabled") Variables::aimbot = std::stoi(value);
        else if (key == "trigger-enabled") Variables::triggerbot = std::stoi(value);
        else if (key == "aimbot-smoothing_x") Variables::smoothness_x = std::stof(value);
        else if (key == "aimbot-smoothing_y") Variables::smoothness_y = std::stof(value);
        else if (key == "trigger-delay") Variables::triggerbot_delay_ms = std::stof(value);
        else if (key == "aimbot-sensitivity") Variables::sensitivity = std::stof(value);
        else if (key == "aimbot-bind") Variables::aimbotkey.key = std::stoi(value);
        else if (key == "trigger-bind") Variables::triggerbotkey.key = std::stoi(value);
        else if (key == "aimbot-bind-mode") Variables::aimbotkey.type = static_cast<CKeybind::c_keybind_type>(std::stoi(value));
        else if (key == "trigger-bind-mode") Variables::triggerbotkey.type = static_cast<CKeybind::c_keybind_type>(std::stoi(value));
        else if (key == "aimbot-part") Variables::aimpart = std::stoi(value);
        else if (key == "streamproof") Variables::streamproof = std::stoi(value);
        else if (key == "v-sync") Variables::vsync = std::stoi(value);
        else if (key == "show_name") Variables::name_esp = std::stoi(value);
        else if (key == "show_boxes") Variables::box = std::stoi(value);
        else if (key == "show_fov") Variables::fov_on = std::stoi(value);
        else if (key == "show_tracers") Variables::tracers = std::stoi(value);
        else if (key == "prediction") Variables::prediction = std::stoi(value);
        else if (key == "smoothness_enabled") Variables::smoothness = std::stoi(value);
        else if (key == "stickyaim") Variables::sticky_aim = std::stoi(value);
        else if (key == "cframe") Variables::cframe = std::stoi(value);
        else if (key == "cframedh") Variables::cframedh = std::stoi(value);
        else if (key == "teamcheck") Variables::team_check = std::stoi(value);
        else if (key == "knockcheck") Variables::knock_check = std::stoi(value);
        else if (key == "aimbot-fov") Variables::fov = std::stoi(value);
        else if (key == "aimbot-type") Variables::aimtype = std::stoi(value);
        else if (key == "pred_x") Variables::prediction_x = std::stof(value);
        else if (key == "pred_y") Variables::prediction_y = std::stof(value);
    }
}