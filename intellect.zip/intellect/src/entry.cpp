#include <filesystem>
#include <iostream>
#include <thread>
#include <string>

#include "security/security.h"
#include "security/log_system.h"
#include "security/security_utils.h"
#include <base/configs/configs.hpp>
#include <game/classes/GameStructs.hpp>
#include <base/json/json.hpp>

#include <impl.hpp>



//std::string init_hash_check_str = skCrypt("cd4d5503ff8979af67e3271c328f4623956c34347c365fa636cb90f7dc5ec5a7").decrypt();
//
//std::string license_login_hash_check_str = skCrypt("8932d2ab42dafd1a59da465359237338709429e9aeb0c55cdbdc3ec8055cbaf9").decrypt();

logger logging("error_log.txt");

std::string read_from_json(std::string path, std::string section)
{
    if (!std::filesystem::exists(path))
        return skCrypt("license file not found").decrypt();

    std::ifstream file(path);
    nlohmann::json data = nlohmann::json::parse(file);
    return data[section];
}


bool write_to_json(std::string path, std::string name, std::string value, bool userpass, std::string name2, std::string value2)
{
    nlohmann::json file;
    if (!userpass)
    {
        file[name] = value;
    }
    else
    {
        file[name] = value;
        file[name2] = value2;
    }

    std::ofstream jsonfile(path, std::ios::out);
    jsonfile << file;
    jsonfile.close();
    if (!std::filesystem::exists(path))
        return false;

    return true;
}


void resizeConsole(int width, int height) {
    HWND console = GetConsoleWindow();
    RECT rect;
    GetWindowRect(console, &rect);
    MoveWindow(console, rect.left, rect.top, width, height, TRUE);
}
int main()
{

    //if (!c_security->security_start()) {
    //    init_hash_check_str.clear();
    //    license_login_hash_check_str.clear();

    //    std::cout << (skCrypt("[0x8] security module could not be initialized, please restart your computer and try again, if the error persists, contact staff.").decrypt(), skCrypt("internal failure").decrypt());
    //    utils::v_exit();
    //}

    intellect::address_t();

    //// //Load the auth module
    //HMODULE auth_module_handle = nullptr;

    //// //Get a pointer to the auth module init function
    //typedef bool(*ep_auth_init_func)(std::string);
    //ep_auth_init_func ep_auth_init = nullptr;

    //// Get a pointer to the auth module login function
    //typedef bool(*ep_license_login_func)(std::string, std::string);
    //ep_license_login_func ep_license_login = nullptr;

    //auth_module_handle = LI_FN(LoadLibraryA).get()(skCrypt("backend.dll").decrypt());
    //if (auth_module_handle == nullptr) {
    //     //Failed to load auth-loader-module.dll
    //    init_hash_check_str.clear();
    //    license_login_hash_check_str.clear();

    //    std::cout << (skCrypt("[0x13] failed to load a module, report this to staff.").decrypt(), skCrypt("internal failure").decrypt());
    //    throw std::runtime_error(skCrypt("[0x13] failed to load a module, report this to staff.").decrypt());

    //    utils::v_exit(2500);
    //}

    //ep_auth_init = reinterpret_cast<ep_auth_init_func>(LI_FN(GetProcAddress).get()(auth_module_handle, skCrypt("ep_auth_init").decrypt()));
    //if (ep_auth_init == nullptr) {
    //     //Failed to get the address of the auth init function
    //    init_hash_check_str.clear();
    //    license_login_hash_check_str.clear();

    //    std::cout << (skCrypt("[0x1] auth failure, report this to staff.").decrypt(), skCrypt("internal failure").decrypt());
    //    throw std::runtime_error(skCrypt("[0x1] auth failure, report this to staff.").decrypt());

    //    utils::v_exit(2500);
    //}

    // //Call the init function from the auth module
    //if (!ep_auth_init(init_hash_check_str)) {
    //     //Failed to initialize the auth system
    //    init_hash_check_str.clear();
    //    license_login_hash_check_str.clear();

    //    std::cout << (skCrypt("[0x2] auth failure, report this to staff.").decrypt(), skCrypt("internal failure").decrypt());
    //    throw std::runtime_error(skCrypt("[0x2] auth failure, report this to staff.").decrypt());

    //    utils::v_exit(2500);
    //}

    //ep_license_login = reinterpret_cast<ep_license_login_func>(LI_FN(GetProcAddress).get()(auth_module_handle, skCrypt("ep_login_license").decrypt()));
    //if (ep_license_login == nullptr) {
    //    // Failed to get the address of the auth login function
    //    init_hash_check_str.clear();
    //    license_login_hash_check_str.clear();

    //    std::cout << (skCrypt("[0x3] auth failure, report this to staff.").decrypt(), skCrypt("internal failure").decrypt());
    //    throw std::runtime_error(skCrypt("[0x3] auth failure, report this to staff.").decrypt());

    //    utils::v_exit(2500);
    //}

    //std::string license_key;

    //if (std::filesystem::exists(skCrypt("intellect.json").decrypt()))
    //{
    //    std::cout << skCrypt("\x1b[41m\x1b[37m#\x1b[40m\x1b[37m attempting to login").decrypt();

    //    license_key = read_from_json(skCrypt("intellect.json").decrypt(), skCrypt("license").decrypt());
    //    if (!ep_license_login(license_key, license_login_hash_check_str)) {
    //        init_hash_check_str.clear();
    //        license_login_hash_check_str.clear();

    //        std::cerr << skCrypt("\x1b[41m\x1b[37m#\x1b[40m\x1b[37m invalid key\n").decrypt();
    //        utils::v_exit(2500);
    //    }
    //}
    //else {
    //    std::cout << skCrypt("\x1b[41m\x1b[37m#\x1b[40m\x1b[37m input your license key: ").decrypt();

    //     //Grab the key from the console user input
    //    std::getline(std::cin, license_key);

    //    if (!ep_license_login(license_key, license_login_hash_check_str)) {
    //        init_hash_check_str.clear();
    //        license_login_hash_check_str.clear();

    //        std::cerr << skCrypt("\x1b[41m\x1b[37m#\x1b[40m\x1b[37m invalid key\n").decrypt();
    //        std::filesystem::remove(skCrypt("intellect.json").decrypt());
    //        utils::v_exit(2500);
    //    }

    //    init_hash_check_str.clear();
    //    license_login_hash_check_str.clear();
    //    std::cout << skCrypt("\x1b[41m\x1b[37m#\x1b[40m\x1b[37m logged in\n").decrypt();

    //    write_to_json(skCrypt("intellect.json").decrypt(), skCrypt("license").decrypt(), license_key, false, skCrypt("").decrypt(), skCrypt("").decrypt());
    //}

 ////    Unload the DLL
    ////  LI_FN(FreeLibrary).get()(auth_module_handle);

   ////// Ensure that the pointers get zero'ed in memory
   // auth_module_handle = nullptr;
   // ep_auth_init = nullptr;
   // ep_license_login = nullptr;

    system("cls");
    std::string appdata = atomic::utils::appdata_path();
    if (!std::filesystem::exists(appdata + skCrypt("\\intellect").decrypt()))
    {
        std::filesystem::create_directory(appdata + skCrypt("\\intellect").decrypt());
    }

    if (!std::filesystem::exists(appdata + skCrypt("\\intellect\\CONFIGS").decrypt()))
    {
        std::filesystem::create_directory(appdata + skCrypt("\\intellect\\CONFIGS").decrypt());

    }

    atomic::roblox::init();

    std::cout << skCrypt("\x1b[41m\x1b[37m#\x1b[40m\x1b[37m error, restart pc") << std::endl;
    std::cin.get();

}