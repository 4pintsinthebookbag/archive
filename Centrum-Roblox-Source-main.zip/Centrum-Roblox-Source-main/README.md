# Centrum-Roblox-Source

Much love to @43cs on discord for sending me the source! 
I presume its safe but do proceed with caution when compiling and running this 

# his github
[@rupo77](https://github.com/rupo77)

# proof
<img width="861" height="279" alt="5H6WgAFibJ" src="https://github.com/user-attachments/assets/abc50538-67da-426a-9463-df5234a61ca2" />


# offsets
https://offsets.ntgetwritewatch.workers.dev/offsets.hpp 
