#pragma once
#include "../../../../../util/classes/classes.h"


namespace autostuff {
	void kill(roblox::player entity);
	void autokill(std::string name);
	void bring(roblox::player entity);
}